-- MariaDB dump 10.19  Distrib 10.4.27-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.4.27-MariaDB-1:10.4.27+maria~ubu2004-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `addresses` (
  `id` int(11) NOT NULL,
  `ownerId` int(11) DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_nnqdmozasusmjmtoxjlwgaujbgrcxqlrkgfg` (`ownerId`),
  CONSTRAINT `fk_ksrfispuspsizgowomrrbgoobgpzzyodwrmn` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nnqdmozasusmjmtoxjlwgaujbgrcxqlrkgfg` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announcements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `pluginId` int(11) DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT 1,
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_aufofrjzxjkcnxuxosrtnefrbfncpzlbdokb` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_dfnallsqfypntixgbiuqbyxlxabhjgdnwmna` (`dateRead`),
  KEY `fk_lboluktuwjzjykmbzgmcztljohdxujwhnqln` (`pluginId`),
  CONSTRAINT `fk_hlcdtmjrnkczbfcvwokoasmxzqmeefoyolod` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lboluktuwjzjykmbzgmcztljohdxujwhnqln` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assetindexdata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sessionId` int(11) NOT NULL,
  `volumeId` int(11) NOT NULL,
  `uri` text DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT 0,
  `recordId` int(11) DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT 0,
  `inProgress` tinyint(1) DEFAULT 0,
  `completed` tinyint(1) DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_zsxvkggfawohfppoostauvzpbnznsbwooadb` (`sessionId`,`volumeId`),
  KEY `idx_lhjvvnlvuffkdvxuckntwqjsioiauxykdumb` (`volumeId`),
  CONSTRAINT `fk_bfsgjrnnvqrytuwmjonmtqhhgmxvhcmbyjsc` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yqdrxrwsoburffeieysahwhacyfxyzntujwg` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexdata`
--

LOCK TABLES `assetindexdata` WRITE;
/*!40000 ALTER TABLE `assetindexdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assetindexingsessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text DEFAULT NULL,
  `totalEntries` int(11) DEFAULT NULL,
  `processedEntries` int(11) NOT NULL DEFAULT 0,
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `isCli` tinyint(1) DEFAULT 0,
  `actionRequired` tinyint(1) DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assets` (
  `id` int(11) NOT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `folderId` int(11) NOT NULL,
  `uploaderId` int(11) DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text DEFAULT NULL,
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `size` bigint(20) unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_aadbzovvcsfpapyuxzrudsvwaswawmalrcss` (`filename`,`folderId`),
  KEY `idx_grhcajlnithheijwtnowspqfjmewyfzwdxsp` (`folderId`),
  KEY `idx_csfswyonaemyvrzibvyhohcresugtqjjpzqq` (`volumeId`),
  KEY `fk_vhovhrpluvmvpfugmwofpegnyajqlwppgess` (`uploaderId`),
  CONSTRAINT `fk_khhuflhnbjcjtauwuvfqliotxpnjfuhaeymn` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nfglkworhmwcvcbgnnticomurwjoinlljutq` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rickdanbvqttzatycfjfmjulcgzevrkrxfbv` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vhovhrpluvmvpfugmwofpegnyajqlwppgess` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blitz_hints`
--

DROP TABLE IF EXISTS `blitz_hints`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blitz_hints` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `template` varchar(255) NOT NULL,
  `routeVariable` varchar(255) NOT NULL,
  `line` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_eucdqnxqjumhvlnqooxinrpyornrikvfgpbq` (`fieldId`,`template`,`routeVariable`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blitz_hints`
--

LOCK TABLES `blitz_hints` WRITE;
/*!40000 ALTER TABLE `blitz_hints` DISABLE KEYS */;
INSERT INTO `blitz_hints` VALUES (1,18,'index.twig','entry',14,'2023-05-04 22:28:03','2023-05-04 22:28:03','e6a4e3f9-446a-458f-aff2-ef2fecb8af2f');
/*!40000 ALTER TABLE `blitz_hints` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_kydgqkprmxenznxejvozleafpgxmuzwnafce` (`groupId`),
  KEY `fk_eknvzvgpxxtwsdlqkgdhswajcmlcldhxkemi` (`parentId`),
  CONSTRAINT `fk_cdvlzupgozmtctvbezhdhwbmoijukiotqfta` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_eknvzvgpxxtwsdlqkgdhswajcmlcldhxkemi` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_xjnnmfjehypcmhadadcxetabxecxrvgusmri` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wcphcmhctmdncphmtviltfqzzuyewskdvdbb` (`name`),
  KEY `idx_nqhiktpscfnrcqzmbfkaroszyjrptjnocdiu` (`handle`),
  KEY `idx_vcgflzsuygprvzzmasumbdcirbkjsimlphwr` (`structureId`),
  KEY `idx_ptuwammtsxwemvkinjhqgqismnmswrebosty` (`fieldLayoutId`),
  KEY `idx_ltvxutjnonceqzbkpxcusxwsyqxienxvzuck` (`dateDeleted`),
  CONSTRAINT `fk_bmqdbtrnppmbprqyjolttaqukvawbhjkgclt` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jtemgdfrdvneazsyqjtyterptdratlejetxc` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
INSERT INTO `categorygroups` VALUES (1,1,2,'Building Type','buildingType','end','2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,'90132f11-3bdb-456a-a01e-18653a2c7371');
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorygroups_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT 1,
  `uriFormat` text DEFAULT NULL,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_sjbwhaobepekmwayqvdaqmfwxzqghxzsqozn` (`groupId`,`siteId`),
  KEY `idx_rpjfrbauveasfbqjbpoiuuhsvwnlyjmcagvz` (`siteId`),
  CONSTRAINT `fk_mujautjzuhhwhotbgtkvuqhdelzhgyxmsoru` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_suijwumyvnuccrgnoynkvvdmihjiihnzkmjg` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
INSERT INTO `categorygroups_sites` VALUES (1,1,1,0,NULL,NULL,'2023-05-04 22:27:55','2023-05-04 22:27:55','29be2fd1-564b-42ea-8331-2cde1fac0ddd');
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changedattributes` (
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_qnyindowuycdrnqiqzwghvryldixlpqwdirq` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_fpvroalkypynwbfrutmcanewcczpmfznpijk` (`siteId`),
  KEY `fk_aohotsulzyqujveplhjwprtavbnmyswbdrhl` (`userId`),
  CONSTRAINT `fk_aohotsulzyqujveplhjwprtavbnmyswbdrhl` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_dcehsenmlcjqvwuitnmpvgzwevnvcfjaiqlq` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_fpvroalkypynwbfrutmcanewcczpmfznpijk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `changedfields` (
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`),
  KEY `idx_symsmpryhiirwrdrlsugvlhsbxskzmogsael` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_szdyfubpzwnjnjsknchzpanejmqtwvubjkbc` (`siteId`),
  KEY `fk_mmsvubanayzxwcthcpbneryqmcctnthrepxi` (`fieldId`),
  KEY `fk_uklxraepyfiizihresqzuhegimkuhuqhmyka` (`userId`),
  CONSTRAINT `fk_mmsvubanayzxwcthcpbneryqmcctnthrepxi` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_rxbnudxjeyakxcyoyxlypachfobqonvebzpx` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_szdyfubpzwnjnjsknchzpanejmqtwvubjkbc` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_uklxraepyfiizihresqzuhegimkuhuqhmyka` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `content`
--

DROP TABLE IF EXISTS `content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_businessAddress_umdvtzcr` text DEFAULT NULL,
  `field_referenceProject_khhktnju` tinyint(1) DEFAULT NULL,
  `field_businessDetails_ipwofvgv` text DEFAULT NULL,
  `field_projectDetails_zqsmmabq` text DEFAULT NULL,
  `field_businessContact_eyxrfojc` text DEFAULT NULL,
  `field_actuelleProjectText_goanvaoh` text DEFAULT NULL,
  `field_projectNumber_bczznfzn` int(10) DEFAULT NULL,
  `field_pageText_xdbaxwyo` text DEFAULT NULL,
  `field_projectTextContent_rgnrudxv` text DEFAULT NULL,
  `field_projectArchitekt_pgchnaiv` text DEFAULT NULL,
  `field_projectZeitdauer_gnmzlvwh` text DEFAULT NULL,
  `field_projectBauherrschaft_mnehzyjd` text DEFAULT NULL,
  `field_actuelleProject_zdyxjjfg` tinyint(1) DEFAULT NULL,
  `field_marqueeText_exofsswa` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_wxatgmzbktsncenytjosoxingtgacatinzxu` (`elementId`,`siteId`),
  KEY `idx_wwgwdcfmvvgjifwuokjimlevhqszuwnifobz` (`siteId`),
  KEY `idx_ozwpmnjqttwtqrqxnanqqtwjixrvqikzvxje` (`title`),
  CONSTRAINT `fk_bxkriaxlmlzeqacgfhtnjtzakaxhkzzdhawv` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tpphmewedmsdoelbazfrkgxkqswbddjjltix` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `content`
--

LOCK TABLES `content` WRITE;
/*!40000 ALTER TABLE `content` DISABLE KEYS */;
INSERT INTO `content` VALUES (1,1,1,'Archiv','2023-05-04 22:27:55','2023-05-04 23:26:17','543d4c26-74f2-4a2b-9b58-5f8fef731c91',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,2,1,'Archiv','2023-05-04 22:27:55','2023-05-04 22:27:55','019ab9d1-5b9d-479b-b633-89ec8910dc07',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(3,3,1,'Archiv','2023-05-04 22:27:55','2023-05-04 22:27:55','d09f2e45-0b9a-4eb1-b1b3-b23099c1e18c',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(4,4,1,'Uber Uns','2023-05-04 22:27:55','2023-05-04 23:26:17','e2fc24f8-a0ed-4354-b0b8-cada09cad287',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(5,5,1,'Uber Uns','2023-05-04 22:27:55','2023-05-04 22:27:55','2b282362-ce3b-4c26-afb3-d721f018bbc5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(6,6,1,'Uber Uns','2023-05-04 22:27:55','2023-05-04 22:27:55','2f2f34d2-1096-4470-9947-f85df29ef651',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(7,7,1,'Home','2023-05-04 22:27:55','2023-05-04 23:26:17','11330661-0062-47cb-bea3-c3d5bf3b5339',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(8,8,1,'Home','2023-05-04 22:27:55','2023-05-04 22:27:55','a643ae8e-b2da-473c-871e-edfbcc8194af',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(9,9,1,'Home','2023-05-04 22:27:55','2023-05-04 22:27:55','b742e6e1-36e1-48cc-955d-5ecbaae57e77',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(10,10,1,'Referenzen','2023-05-04 22:27:55','2023-05-04 23:26:17','9181ca47-5248-4535-a07d-c3c3ec773b0b',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(11,11,1,'Referenzen','2023-05-04 22:27:55','2023-05-04 22:27:55','5223c4d2-7d91-4ece-8e9c-e160781594d5',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(12,12,1,'Referenzen','2023-05-04 22:27:55','2023-05-04 22:27:55','4025d6e1-94c1-4949-a8ce-3ae59c93af37',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(13,13,1,'Archiv','2023-05-04 22:27:56','2023-05-04 22:27:56','8b1cb1a9-30d4-420f-931d-e32fd0b903c7',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,14,1,'Archiv','2023-05-04 22:27:56','2023-05-04 22:27:56','a67fdf20-c6db-4da9-aae5-435d4fa3cf8c',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(15,15,1,'Uber Uns','2023-05-04 22:27:56','2023-05-04 22:27:56','fbbb7f2e-4900-4538-b016-4345a2bd344e',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(16,16,1,'Uber Uns','2023-05-04 22:27:56','2023-05-04 22:27:56','13a0249f-dde5-4b59-8fb5-b00d87eee0b1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(17,17,1,'Home','2023-05-04 22:27:56','2023-05-04 22:27:56','90df79a2-49c9-4ef1-89a0-9219c78ee10d',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(18,18,1,'Home','2023-05-04 22:27:56','2023-05-04 22:27:56','0ccebc9e-4960-4325-9598-8d9935c5ac73',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(19,19,1,'Referenzen','2023-05-04 22:27:56','2023-05-04 22:27:56','d7ec9d72-ecd8-4010-b378-0461d5f3a1c1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(20,20,1,'Referenzen','2023-05-04 22:27:56','2023-05-04 22:27:56','e4565b4d-d191-4d54-90c5-e74cfee8598d',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(21,21,1,NULL,'2023-05-04 22:27:56','2023-05-04 22:27:56','cb080f38-147a-4bd2-902b-3589fa1e914e',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(22,22,1,'Archiv','2023-05-04 23:26:17','2023-05-04 23:26:17','82f3ea33-71e0-40e6-b908-8a4305203fde',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(23,23,1,'Archiv','2023-05-04 23:26:17','2023-05-04 23:26:17','b76078ab-b4a3-4e2d-ae7f-10bda9c07918',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(24,24,1,'Uber Uns','2023-05-04 23:26:17','2023-05-04 23:26:17','a0b4f769-38fd-4c56-b876-1d36fa10759f',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(25,25,1,'Uber Uns','2023-05-04 23:26:17','2023-05-04 23:26:17','f71ea0a7-d61a-4d0f-8812-0dde6673ed2d',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(26,26,1,'Home','2023-05-04 23:26:17','2023-05-04 23:26:17','e69bbe69-915b-4f48-b81f-5b452f26868e',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(27,27,1,'Home','2023-05-04 23:26:17','2023-05-04 23:26:17','7d20bb92-bf3b-45e3-8954-afc637e342fa',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(28,28,1,'Referenzen','2023-05-04 23:26:17','2023-05-04 23:26:17','d048e7fa-1bc8-4466-a83e-c6b984d6f5b6',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(29,29,1,'Referenzen','2023-05-04 23:26:17','2023-05-04 23:26:17','85e25b67-8152-4635-8572-8eae1fe3a190',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(30,30,1,'Uber Uns','2023-05-04 23:26:17','2023-05-04 23:26:17','b3e20848-81b1-48b7-93b7-e737b4a35890',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(31,31,1,'Uber Uns','2023-05-04 23:26:17','2023-05-04 23:26:17','0dc124dc-eb5a-45f4-80b2-09c6bd516e40',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(32,32,1,'Home','2023-05-04 23:26:17','2023-05-04 23:26:17','02af3f8f-c314-4152-90d4-275813857f8a',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(33,33,1,'Home','2023-05-04 23:26:17','2023-05-04 23:26:17','53b9ee1f-b5b3-42ef-b970-68fc0d7a85aa',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(34,34,1,'Referenzen','2023-05-04 23:26:17','2023-05-04 23:26:17','4d9dc0f4-c9b7-41d4-a8c4-23d4aa345d38',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),(35,35,1,'Referenzen','2023-05-04 23:26:17','2023-05-04 23:26:17','4c91acf6-3cb0-498e-a400-743e68cbef61',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `craftidtokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_sbvmesptnyyiwmbftpcfsysvojoovizromav` (`userId`),
  CONSTRAINT `fk_sbvmesptnyyiwmbftpcfsysvojoovizromav` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deprecationerrors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint(6) unsigned DEFAULT NULL,
  `message` text DEFAULT NULL,
  `traces` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_wjpjcpihyuutlpsbpzahqioalnfaxzopyods` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drafts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `canonicalId` int(11) DEFAULT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `notes` text DEFAULT NULL,
  `trackChanges` tinyint(1) NOT NULL DEFAULT 0,
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `idx_nnmwwinvezqabmbtzxuczznskuinwaznjqbe` (`creatorId`,`provisional`),
  KEY `idx_rfyjkcjmsdcwkfuzeblnwtfpxawowpgqgxzq` (`saved`),
  KEY `fk_zqpvejmugxqacrleucvxoohjimkysijbdauh` (`canonicalId`),
  CONSTRAINT `fk_dhzovytxvezrpzdqyfwjtfhunbsesomwvcan` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_zqpvejmugxqacrleucvxoohjimkysijbdauh` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `canonicalId` int(11) DEFAULT NULL,
  `draftId` int(11) DEFAULT NULL,
  `revisionId` int(11) DEFAULT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `archived` tinyint(1) NOT NULL DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_mmonbciputiqfjltozkpvyolayfhgvblmpsd` (`dateDeleted`),
  KEY `idx_kfhghvdcjhmphoaprfxwqacomgmbzywlcaln` (`fieldLayoutId`),
  KEY `idx_yzwkshyxdtgaowkufjwozppntfcatequynkc` (`type`),
  KEY `idx_hrlclojqbcatjblplnjuplxdmvcuqossfntb` (`enabled`),
  KEY `idx_xlidxgkrawippjpmcdeptjvbcmtlkhqqzkzs` (`archived`,`dateCreated`),
  KEY `idx_nboswqdyigdzumpciitqityoqotzswrrcelr` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_bmkcreurnnqhvphncjbtpcltuunmzrhagaox` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_tjbqalwpiijhtgybruolwuvojollxkklhalj` (`canonicalId`),
  KEY `fk_orkucgvxxusmziuvpawicsxuwblfvmprmhtv` (`draftId`),
  KEY `fk_lregigpjsmbtvgwvjtvonkdmeuavrizxyhcv` (`revisionId`),
  CONSTRAINT `fk_hptyzhispluqjddeksbshfzyzgqujecgzchx` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_lregigpjsmbtvgwvjtvonkdmeuavrizxyhcv` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_orkucgvxxusmziuvpawicsxuwblfvmprmhtv` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tjbqalwpiijhtgybruolwuvojollxkklhalj` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,4,'craft\\elements\\Entry',1,0,'2023-05-04 22:27:55','2023-05-04 23:26:17',NULL,NULL,'a9814968-030a-4578-9545-2c6c6c2c8ae9'),(2,1,NULL,1,4,'craft\\elements\\Entry',1,0,'2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,NULL,'86f37916-0892-4c95-8d04-c182b40eadad'),(3,1,NULL,2,4,'craft\\elements\\Entry',1,0,'2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,NULL,'3b1225be-91ba-410d-8826-6def3f9ffbc2'),(4,NULL,NULL,NULL,5,'craft\\elements\\Entry',1,0,'2023-05-04 22:27:55','2023-05-04 23:26:17',NULL,NULL,'826ab31d-10b9-4b19-b186-d395c20fa5e1'),(5,4,NULL,3,5,'craft\\elements\\Entry',1,0,'2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,NULL,'18154eb3-7190-4c3d-aae5-3732297fadb3'),(6,4,NULL,4,5,'craft\\elements\\Entry',1,0,'2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,NULL,'3fde197f-ae92-4e71-ada0-d135270c5c21'),(7,NULL,NULL,NULL,6,'craft\\elements\\Entry',1,0,'2023-05-04 22:27:55','2023-05-04 23:26:17',NULL,NULL,'b0e4bf66-3efa-4f2c-aa50-56d1f716e77d'),(8,7,NULL,5,6,'craft\\elements\\Entry',1,0,'2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,NULL,'67e4d2c7-f16c-4c87-9228-08cbf5fc2d82'),(9,7,NULL,6,6,'craft\\elements\\Entry',1,0,'2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,NULL,'734299f1-5d2a-430a-af96-57ee817ffc47'),(10,NULL,NULL,NULL,7,'craft\\elements\\Entry',1,0,'2023-05-04 22:27:55','2023-05-04 23:26:17',NULL,NULL,'7947b6a3-6806-434e-a35f-d7ca8607941b'),(11,10,NULL,7,7,'craft\\elements\\Entry',1,0,'2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,NULL,'6e1a3a96-1825-4f61-87bb-de9eb3a31403'),(12,10,NULL,8,7,'craft\\elements\\Entry',1,0,'2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,NULL,'471cb3b5-201c-46a3-a048-a7d49e4b064d'),(13,1,NULL,9,4,'craft\\elements\\Entry',1,0,'2023-05-04 22:27:56','2023-05-04 22:27:56',NULL,NULL,'553441bd-98fa-43cf-aa87-adf550b4daa0'),(14,1,NULL,10,4,'craft\\elements\\Entry',1,0,'2023-05-04 22:27:56','2023-05-04 22:27:56',NULL,NULL,'87329da1-3448-412b-8d57-b086b09d582d'),(15,4,NULL,11,5,'craft\\elements\\Entry',1,0,'2023-05-04 22:27:56','2023-05-04 22:27:56',NULL,NULL,'90b2456e-2a66-41b1-b0a1-49d43f011b90'),(16,4,NULL,12,5,'craft\\elements\\Entry',1,0,'2023-05-04 22:27:56','2023-05-04 22:27:56',NULL,NULL,'954a4061-cc89-4f25-a870-78112a74171f'),(17,7,NULL,13,6,'craft\\elements\\Entry',1,0,'2023-05-04 22:27:56','2023-05-04 22:27:56',NULL,NULL,'3fa79121-3b4c-498d-9bbc-dc134cb81629'),(18,7,NULL,14,6,'craft\\elements\\Entry',1,0,'2023-05-04 22:27:56','2023-05-04 22:27:56',NULL,NULL,'902a7cf6-798b-4cac-b66a-d36963cb861b'),(19,10,NULL,15,7,'craft\\elements\\Entry',1,0,'2023-05-04 22:27:56','2023-05-04 22:27:56',NULL,NULL,'d0a3a0bf-c333-4b56-9aac-bac3df06a186'),(20,10,NULL,16,7,'craft\\elements\\Entry',1,0,'2023-05-04 22:27:56','2023-05-04 22:27:56',NULL,NULL,'faf2acdd-1856-4500-9bfb-9118351e714f'),(21,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2023-05-04 22:27:56','2023-05-04 22:27:56',NULL,NULL,'92921d9f-4543-4368-8251-ab0d31cda484'),(22,1,NULL,17,4,'craft\\elements\\Entry',1,0,'2023-05-04 23:26:17','2023-05-04 23:26:17',NULL,NULL,'ceef18be-d417-4741-9698-47fef7dd3ddc'),(23,1,NULL,18,4,'craft\\elements\\Entry',1,0,'2023-05-04 23:26:17','2023-05-04 23:26:17',NULL,NULL,'7fe2c416-274d-4a99-a7b5-76052ed33d6c'),(24,4,NULL,19,5,'craft\\elements\\Entry',1,0,'2023-05-04 23:26:17','2023-05-04 23:26:17',NULL,NULL,'b94800d9-615c-4fc6-86c7-d6e9e19c85d6'),(25,4,NULL,20,5,'craft\\elements\\Entry',1,0,'2023-05-04 23:26:17','2023-05-04 23:26:17',NULL,NULL,'e77e9dca-1374-4781-9ef5-e60754196151'),(26,7,NULL,21,6,'craft\\elements\\Entry',1,0,'2023-05-04 23:26:17','2023-05-04 23:26:17',NULL,NULL,'c432ca26-bf1a-4ee2-b7b9-29f775a38e78'),(27,7,NULL,22,6,'craft\\elements\\Entry',1,0,'2023-05-04 23:26:17','2023-05-04 23:26:17',NULL,NULL,'f27cf51a-3ca8-460f-8c60-da8d64c9d1ec'),(28,10,NULL,23,7,'craft\\elements\\Entry',1,0,'2023-05-04 23:26:17','2023-05-04 23:26:17',NULL,NULL,'792fec0d-6f1c-4a6e-b814-31036920f23c'),(29,10,NULL,24,7,'craft\\elements\\Entry',1,0,'2023-05-04 23:26:17','2023-05-04 23:26:17',NULL,NULL,'a5b33b47-7853-4f94-acc0-c44a64b06ebb'),(30,4,NULL,25,5,'craft\\elements\\Entry',1,0,'2023-05-04 23:26:17','2023-05-04 23:26:17',NULL,NULL,'f20c2924-67d1-4af7-8317-01883b11cc5a'),(31,4,NULL,26,5,'craft\\elements\\Entry',1,0,'2023-05-04 23:26:17','2023-05-04 23:26:17',NULL,NULL,'e6b0d9cb-1fa4-4f0f-b958-736aa0dcc088'),(32,7,NULL,27,6,'craft\\elements\\Entry',1,0,'2023-05-04 23:26:17','2023-05-04 23:26:17',NULL,NULL,'39caaa6f-a2fc-4f64-9176-06220b9e6b46'),(33,7,NULL,28,6,'craft\\elements\\Entry',1,0,'2023-05-04 23:26:17','2023-05-04 23:26:17',NULL,NULL,'1866b42c-2275-4dd0-ba2a-31e217f47935'),(34,10,NULL,29,7,'craft\\elements\\Entry',1,0,'2023-05-04 23:26:17','2023-05-04 23:26:17',NULL,NULL,'24746c3f-16b1-4e6c-a670-470784ad3e9b'),(35,10,NULL,30,7,'craft\\elements\\Entry',1,0,'2023-05-04 23:26:17','2023-05-04 23:26:17',NULL,NULL,'1830d574-12c2-42b0-b23f-295b37384316');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `elements_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_pqglcnirwpvxxpchbdzaecmjcnjvmwkgzkls` (`elementId`,`siteId`),
  KEY `idx_soaczetaiiduzcjphxhythbsmygvrblgorqb` (`siteId`),
  KEY `idx_wkglyfqmjwdzzlkncawfnugljuevjtrkdobc` (`slug`,`siteId`),
  KEY `idx_ldzmjzwqbfbptagbwukrqanrifnzyxwgupsg` (`enabled`),
  KEY `idx_wfezfhrkvfsestphxjhaoenknhcgoppxaiag` (`uri`,`siteId`),
  CONSTRAINT `fk_bjqnsepxqtnxmwcdlyirrdeymnusxjxumxtv` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_urrkziqrrjgugzaehrwfsncflmicfkciarin` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
INSERT INTO `elements_sites` VALUES (1,1,1,'archiv','archiv',1,'2023-05-04 22:27:55','2023-05-04 22:27:55','8e361d93-5fc3-41a5-b5b9-959479393321'),(2,2,1,'archiv','archiv',1,'2023-05-04 22:27:55','2023-05-04 22:27:55','26f82657-c5a5-438f-9df0-828c97c4f5ad'),(3,3,1,'archiv','archiv',1,'2023-05-04 22:27:55','2023-05-04 22:27:55','08c1d2de-3704-410b-a784-7b4dbf790d10'),(4,4,1,'uber-uns','uber-uns',1,'2023-05-04 22:27:55','2023-05-04 22:27:55','cb3e21b8-6c4d-4ee7-8f99-441433fa462a'),(5,5,1,'uber-uns','uber-uns',1,'2023-05-04 22:27:55','2023-05-04 22:27:55','fa1ecaf3-d89b-47ae-960a-91b651ca5b13'),(6,6,1,'uber-uns','uber-uns',1,'2023-05-04 22:27:55','2023-05-04 22:27:55','94ff909d-ce35-439b-84cf-39e50184a92a'),(7,7,1,'home','__home__',1,'2023-05-04 22:27:55','2023-05-04 22:27:55','98c81abf-4c8a-4c7c-ad2e-14ec93747bc2'),(8,8,1,'home','__home__',1,'2023-05-04 22:27:55','2023-05-04 22:27:55','b6c3ea83-83fd-43b4-8b41-023ec05f49b9'),(9,9,1,'home','__home__',1,'2023-05-04 22:27:55','2023-05-04 22:27:55','f86a9e28-63ea-4160-b49d-f8f6e24ed0a7'),(10,10,1,'referenzen','referenzen',1,'2023-05-04 22:27:55','2023-05-04 22:27:55','2c1c93c9-11bd-4502-8cfe-b26b73015403'),(11,11,1,'referenzen','referenzen',1,'2023-05-04 22:27:55','2023-05-04 22:27:55','5eee57b4-8d68-4d75-b5ae-3872b4899f2b'),(12,12,1,'referenzen','referenzen',1,'2023-05-04 22:27:55','2023-05-04 22:27:55','4d5d986c-35e4-4f6c-87b4-a7968fac54d1'),(13,13,1,'archiv','archiv',1,'2023-05-04 22:27:56','2023-05-04 22:27:56','cbac47d1-12c3-4ab5-a341-e157d512717f'),(14,14,1,'archiv','archiv',1,'2023-05-04 22:27:56','2023-05-04 22:27:56','5574555b-62fa-4474-a43b-1c95e05bdee9'),(15,15,1,'uber-uns','uber-uns',1,'2023-05-04 22:27:56','2023-05-04 22:27:56','7e8f0212-40be-4fbf-8991-9dcefef1d692'),(16,16,1,'uber-uns','uber-uns',1,'2023-05-04 22:27:56','2023-05-04 22:27:56','452550f7-c49e-4ff4-bf8e-f16bba97f382'),(17,17,1,'home','__home__',1,'2023-05-04 22:27:56','2023-05-04 22:27:56','88aa9d33-1628-421d-8d74-564a35b9131d'),(18,18,1,'home','__home__',1,'2023-05-04 22:27:56','2023-05-04 22:27:56','34269a0d-bab9-4bd8-aaea-2c4027941dc3'),(19,19,1,'referenzen','referenzen',1,'2023-05-04 22:27:56','2023-05-04 22:27:56','25804f2e-3dc4-445d-b0ca-e2328e3b5e88'),(20,20,1,'referenzen','referenzen',1,'2023-05-04 22:27:56','2023-05-04 22:27:56','3dd90991-77b6-4f08-9f03-6d5a00aa1b55'),(21,21,1,NULL,NULL,1,'2023-05-04 22:27:56','2023-05-04 22:27:56','d5626186-d322-4350-bb77-c05977bd08ed'),(22,22,1,'archiv','archiv',1,'2023-05-04 23:26:17','2023-05-04 23:26:17','84a65db4-bf93-4234-850c-ca36501cb56b'),(23,23,1,'archiv','archiv',1,'2023-05-04 23:26:17','2023-05-04 23:26:17','497f0021-73c7-4289-850d-8f536c94db51'),(24,24,1,'uber-uns','uber-uns',1,'2023-05-04 23:26:17','2023-05-04 23:26:17','39f0294c-d16c-469d-91a2-5067085145ea'),(25,25,1,'uber-uns','uber-uns',1,'2023-05-04 23:26:17','2023-05-04 23:26:17','fec26b4a-deb0-4057-973c-7f55a3baffea'),(26,26,1,'home','__home__',1,'2023-05-04 23:26:17','2023-05-04 23:26:17','d4ddb9d0-474c-4585-9158-d843e35804c2'),(27,27,1,'home','__home__',1,'2023-05-04 23:26:17','2023-05-04 23:26:17','db00c204-b635-43d4-bfe5-1369aacd0204'),(28,28,1,'referenzen','referenzen',1,'2023-05-04 23:26:17','2023-05-04 23:26:17','eceb55e7-768d-47fd-b233-83e790bc3ab1'),(29,29,1,'referenzen','referenzen',1,'2023-05-04 23:26:17','2023-05-04 23:26:17','8ae85c67-cfaa-4b1c-b62c-9ef42ab5a670'),(30,30,1,'uber-uns','uber-uns',1,'2023-05-04 23:26:17','2023-05-04 23:26:17','90ec2e48-168b-436d-845e-2e45c89a2258'),(31,31,1,'uber-uns','uber-uns',1,'2023-05-04 23:26:17','2023-05-04 23:26:17','2957aa8f-549d-482e-8b4e-c38fbe0910af'),(32,32,1,'home','__home__',1,'2023-05-04 23:26:17','2023-05-04 23:26:17','7d7b58e0-1560-462e-9571-7f80954e31c0'),(33,33,1,'home','__home__',1,'2023-05-04 23:26:17','2023-05-04 23:26:17','d558c44f-ea93-4335-8a28-6b9225dc5c50'),(34,34,1,'referenzen','referenzen',1,'2023-05-04 23:26:17','2023-05-04 23:26:17','1ce6daa2-a27f-418a-a05c-379654279e86'),(35,35,1,'referenzen','referenzen',1,'2023-05-04 23:26:17','2023-05-04 23:26:17','f97f0e2b-d065-4035-b60b-3494bab9cfd8');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entries` (
  `id` int(11) NOT NULL,
  `sectionId` int(11) NOT NULL,
  `parentId` int(11) DEFAULT NULL,
  `typeId` int(11) NOT NULL,
  `authorId` int(11) DEFAULT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_shmrgppidpyidaxynkswzyruxgwdfceponhw` (`postDate`),
  KEY `idx_asqhevjzozhewupiwcbvskiezrxpikracejy` (`expiryDate`),
  KEY `idx_iczlibjrtfvjfctktynlwhvgnwnicnxqigqh` (`authorId`),
  KEY `idx_uludgmddmzjwswgsqfnwosexcqyysqqawwpd` (`sectionId`),
  KEY `idx_edxttshpwezovccdaxbycdqltxmupnqfprrr` (`typeId`),
  KEY `fk_jueuayrtzkduuytauqxybamkmxnjzlgypfry` (`parentId`),
  CONSTRAINT `fk_jueuayrtzkduuytauqxybamkmxnjzlgypfry` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ktgxiddgxanmqcknwavtzmwpwnmldkuqzzlf` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mwkinprbnpqljupirehaldsnfyccwuaanbzb` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vigynxnqzloyzordqyugxgoohhgzjmqxegpc` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xzpjbefkegavmpvykwobhhhcvwqqwqjqgfnh` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
INSERT INTO `entries` VALUES (1,1,NULL,2,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 22:27:55','2023-05-04 22:27:55'),(2,1,NULL,2,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 22:27:55','2023-05-04 22:27:55'),(3,1,NULL,2,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 22:27:55','2023-05-04 22:27:55'),(4,4,NULL,3,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 22:27:55','2023-05-04 22:27:55'),(5,4,NULL,3,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 22:27:55','2023-05-04 22:27:55'),(6,4,NULL,3,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 22:27:55','2023-05-04 22:27:55'),(7,2,NULL,4,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 22:27:55','2023-05-04 22:27:55'),(8,2,NULL,4,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 22:27:55','2023-05-04 22:27:55'),(9,2,NULL,4,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 22:27:55','2023-05-04 22:27:55'),(10,3,NULL,5,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 22:27:55','2023-05-04 22:27:55'),(11,3,NULL,5,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 22:27:55','2023-05-04 22:27:55'),(12,3,NULL,5,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 22:27:55','2023-05-04 22:27:55'),(13,1,NULL,2,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 22:27:56','2023-05-04 22:27:56'),(14,1,NULL,2,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 22:27:56','2023-05-04 22:27:56'),(15,4,NULL,3,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 22:27:56','2023-05-04 22:27:56'),(16,4,NULL,3,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 22:27:56','2023-05-04 22:27:56'),(17,2,NULL,4,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 22:27:56','2023-05-04 22:27:56'),(18,2,NULL,4,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 22:27:56','2023-05-04 22:27:56'),(19,3,NULL,5,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 22:27:56','2023-05-04 22:27:56'),(20,3,NULL,5,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 22:27:56','2023-05-04 22:27:56'),(22,1,NULL,2,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 23:26:17','2023-05-04 23:26:17'),(23,1,NULL,2,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 23:26:17','2023-05-04 23:26:17'),(24,4,NULL,3,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 23:26:17','2023-05-04 23:26:17'),(25,4,NULL,3,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 23:26:17','2023-05-04 23:26:17'),(26,2,NULL,4,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 23:26:17','2023-05-04 23:26:17'),(27,2,NULL,4,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 23:26:17','2023-05-04 23:26:17'),(28,3,NULL,5,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 23:26:17','2023-05-04 23:26:17'),(29,3,NULL,5,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 23:26:17','2023-05-04 23:26:17'),(30,4,NULL,3,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 23:26:17','2023-05-04 23:26:17'),(31,4,NULL,3,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 23:26:17','2023-05-04 23:26:17'),(32,2,NULL,4,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 23:26:17','2023-05-04 23:26:17'),(33,2,NULL,4,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 23:26:17','2023-05-04 23:26:17'),(34,3,NULL,5,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 23:26:17','2023-05-04 23:26:17'),(35,3,NULL,5,NULL,'2023-05-04 22:27:00',NULL,NULL,'2023-05-04 23:26:17','2023-05-04 23:26:17');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entrytypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT 1,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text DEFAULT NULL,
  `titleFormat` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_epxmziogvqntspcrjxwbpmyznqjaatjubtps` (`name`,`sectionId`),
  KEY `idx_ochfdakldvgcwkjoqxvjsfspyokgnjyrcunq` (`handle`,`sectionId`),
  KEY `idx_tvaubeabdetkqrtoeehbfoxwqjtqlkbcetau` (`sectionId`),
  KEY `idx_ddceqkzzdxcakwdsilxedsedyydpetjhgylm` (`fieldLayoutId`),
  KEY `idx_uawxrfoermyelsuvexarljvmiclwcupnvrys` (`dateDeleted`),
  CONSTRAINT `fk_cqjeeugynhabpqsqetdkcmwlsirbbzxcdodq` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ekwxsuktsijbwdemyxaidwtqpulfyfjjsqly` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
INSERT INTO `entrytypes` VALUES (1,5,1,'Default','default',1,'site',NULL,NULL,1,'2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,'a8ebc45c-68de-46be-b5d2-c648a0a99aac'),(2,1,4,'Archiv','archiv',0,'site',NULL,'{section.name|raw}',1,'2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,'272d5a67-670b-4bfd-ba65-bbd133766256'),(3,4,5,'Uber Uns','uberuns',0,'site',NULL,'{section.name|raw}',1,'2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,'f39bc8ac-e071-427f-a24c-643bf9ecaa71'),(4,2,6,'Home','home',0,'site',NULL,'{section.name|raw}',1,'2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,'73166065-2347-470c-829f-bccaa41283d6'),(5,3,7,'Referenzen','referenzen',0,'site',NULL,'{section.name|raw}',1,'2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,'ba6a7105-5890-449d-90b3-9ca3a98f7da4');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedme_feeds`
--

DROP TABLE IF EXISTS `feedme_feeds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feedme_feeds` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `feedUrl` text NOT NULL,
  `feedType` varchar(255) DEFAULT NULL,
  `primaryElement` varchar(255) DEFAULT NULL,
  `elementType` varchar(255) NOT NULL,
  `elementGroup` text DEFAULT NULL,
  `siteId` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `singleton` tinyint(1) NOT NULL DEFAULT 0,
  `duplicateHandle` text DEFAULT NULL,
  `updateSearchIndexes` tinyint(1) NOT NULL DEFAULT 1,
  `paginationNode` text DEFAULT NULL,
  `fieldMapping` text DEFAULT NULL,
  `fieldUnique` text DEFAULT NULL,
  `passkey` varchar(255) NOT NULL,
  `backup` tinyint(1) NOT NULL DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedme_feeds`
--

LOCK TABLES `feedme_feeds` WRITE;
/*!40000 ALTER TABLE `feedme_feeds` DISABLE KEYS */;
/*!40000 ALTER TABLE `feedme_feeds` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldgroups`
--

DROP TABLE IF EXISTS `fieldgroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldgroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_gvogzfsnehtbkbwafbtzydtzzuqeiewjmbhk` (`name`),
  KEY `idx_twiigapafbjnsbncaqwxsaotbimdxjrqatqz` (`dateDeleted`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldgroups`
--

LOCK TABLES `fieldgroups` WRITE;
/*!40000 ALTER TABLE `fieldgroups` DISABLE KEYS */;
INSERT INTO `fieldgroups` VALUES (1,'Project Fields','2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,'0404121f-3b43-4edf-8f91-484cf9e22e05'),(2,'Team Fields','2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,'70fb5bd9-06ba-44bc-ac8e-4d97f1340d05'),(3,'Home Page','2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,'1ae40c53-c8eb-45dc-8e4d-9ed6f3ea6d28'),(4,'Archiv Fields','2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,'c01637ae-da9f-438b-b94f-9eb66079f9b5'),(5,'Common','2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,'23dde92c-c4a7-41f2-ac8c-edec5fb2c991');
/*!40000 ALTER TABLE `fieldgroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayoutfields`
--

DROP TABLE IF EXISTS `fieldlayoutfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayoutfields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `tabId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT 0,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_stowqfzewsnysntmtwqfsnopauzyouajvzog` (`layoutId`,`fieldId`),
  KEY `idx_yvxhdwtlogdlbkycqdwpfugpasmjjyowefix` (`sortOrder`),
  KEY `idx_luuttaljmydydqlrwyftipontckokdrwbroa` (`tabId`),
  KEY `idx_gyrdlawkaxedtbctgjplgmzclyscilginvmw` (`fieldId`),
  CONSTRAINT `fk_ajypmnxnznywfdxnirhachgbzzywafdmchlz` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_jqcfmirycpntluasklareuqouavbnpyalbbj` FOREIGN KEY (`tabId`) REFERENCES `fieldlayouttabs` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yvzvemwoppjejxqqyjltjksvbexllkymxytc` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=193 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayoutfields`
--

LOCK TABLES `fieldlayoutfields` WRITE;
/*!40000 ALTER TABLE `fieldlayoutfields` DISABLE KEYS */;
INSERT INTO `fieldlayoutfields` VALUES (149,3,62,19,1,0,'2023-05-04 23:26:17','2023-05-04 23:26:17','27342761-24c7-4d84-b685-3a5352c48e66'),(150,3,62,20,1,1,'2023-05-04 23:26:17','2023-05-04 23:26:17','e369e24a-3e7e-4051-afa1-ac0ebae4095c'),(153,4,64,10,0,1,'2023-05-04 23:26:17','2023-05-04 23:26:17','746ea0c6-2151-47c9-9194-39f5f59a86e7'),(154,4,64,8,0,2,'2023-05-04 23:26:17','2023-05-04 23:26:17','76d08980-1db4-40e8-b28c-f5d17576e064'),(160,5,66,10,0,1,'2023-05-04 23:26:17','2023-05-04 23:26:17','34a38a19-c9d4-4f67-a4c8-7e14c1aa6581'),(161,5,66,5,0,3,'2023-05-04 23:26:17','2023-05-04 23:26:17','3c2b324d-0906-47c6-863a-819ab4597c0a'),(162,5,66,4,0,5,'2023-05-04 23:26:17','2023-05-04 23:26:17','77acc84b-0e2a-49ac-bd31-e1f69c616352'),(163,5,66,1,0,6,'2023-05-04 23:26:17','2023-05-04 23:26:17','8664fb8b-c0f8-418d-b34d-360c7853f17f'),(164,5,66,7,0,7,'2023-05-04 23:26:17','2023-05-04 23:26:17','ee30bf69-5cfa-49b2-8fa1-df47e183a40f'),(168,6,68,17,0,1,'2023-05-04 23:26:17','2023-05-04 23:26:17','dbaf6290-8b62-4e3b-8d00-8bb6ffd23e2f'),(169,6,68,10,0,2,'2023-05-04 23:26:17','2023-05-04 23:26:17','fdea484f-34f6-4942-8544-db10165aab8f'),(170,6,68,18,0,4,'2023-05-04 23:26:17','2023-05-04 23:26:17','f4cfd541-af3c-46b8-bc77-fef97887d936'),(181,1,70,9,1,2,'2023-05-04 23:26:17','2023-05-04 23:26:17','51810a3c-3048-4ae0-8257-c36490d36d00'),(182,1,70,3,0,3,'2023-05-04 23:26:17','2023-05-04 23:26:17','ef0820ba-e522-4ef0-a0bb-dff6b8ae7812'),(183,1,70,16,0,4,'2023-05-04 23:26:17','2023-05-04 23:26:17','03142f7b-ca3e-4486-9e47-9c4cedfd2c19'),(184,1,70,2,0,6,'2023-05-04 23:26:17','2023-05-04 23:26:17','16475814-4360-47d0-8cac-fd9ca31130e2'),(185,1,70,13,1,7,'2023-05-04 23:26:17','2023-05-04 23:26:17','02226ffe-7a9c-45a0-8bee-f184140d0472'),(186,1,70,15,1,8,'2023-05-04 23:26:17','2023-05-04 23:26:17','cf263f52-c913-4fed-b4b3-8f3a4cc87131'),(187,1,70,14,1,9,'2023-05-04 23:26:17','2023-05-04 23:26:17','a67667ce-ecec-4478-ad41-d2bb5559e0fe'),(188,1,70,11,1,11,'2023-05-04 23:26:17','2023-05-04 23:26:17','7164b1fd-2e78-47da-926e-901663c2ff8c'),(189,1,70,6,1,13,'2023-05-04 23:26:17','2023-05-04 23:26:17','33008c3b-9f77-44d2-9074-38e7f47cd7d5'),(190,1,70,12,0,14,'2023-05-04 23:26:17','2023-05-04 23:26:17','59423482-6f3b-4926-9a5d-44697e2c22ec'),(192,7,72,10,0,1,'2023-05-04 23:26:17','2023-05-04 23:26:17','117b258d-2a61-4d61-a496-e127c378c9ee');
/*!40000 ALTER TABLE `fieldlayoutfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayouts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_pkawqolarqyunncryhdnmhwvmeaxhtibrrln` (`dateDeleted`),
  KEY `idx_rpkcqfrccxfqwfejyxsjqikxzsltvkioashq` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\Entry','2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,'d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89'),(2,'craft\\elements\\Category','2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,'a83364aa-6864-4cf7-a460-ebb621d1723a'),(3,'verbb\\supertable\\elements\\SuperTableBlockElement','2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,'4544de17-529c-4494-920d-9609dd4b8888'),(4,'craft\\elements\\Entry','2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,'2aac7003-4ca0-4dae-89b8-45996b2c15b8'),(5,'craft\\elements\\Entry','2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,'ff6bfcc2-1c6c-421a-819d-4e8a98f311a8'),(6,'craft\\elements\\Entry','2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,'97500b3a-619a-4d4f-af86-29050380fc7a'),(7,'craft\\elements\\Entry','2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,'585e3ff0-b259-4bd3-a484-771c24d9a1ac'),(8,'craft\\elements\\Asset','2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,'b16c2f9d-8812-49b4-a121-9f07ef7432dd'),(9,'craft\\elements\\Asset','2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,'e04a4836-39e5-469f-8904-a212522fb3b9');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouttabs`
--

DROP TABLE IF EXISTS `fieldlayouttabs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fieldlayouttabs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `layoutId` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `settings` text DEFAULT NULL,
  `elements` text DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_gjqghuwgqvfknzgodsueaeadlrxsksoutpgk` (`sortOrder`),
  KEY `idx_xhhanllynttxskkblsymjozxcdqllatfrffb` (`layoutId`),
  CONSTRAINT `fk_qjcpkspusijqgbjyesbkosjdkvialkbttjqc` FOREIGN KEY (`layoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouttabs`
--

LOCK TABLES `fieldlayouttabs` WRITE;
/*!40000 ALTER TABLE `fieldlayouttabs` DISABLE KEYS */;
INSERT INTO `fieldlayouttabs` VALUES (60,2,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\TitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"5f0d708d-554f-44e4-a7b6-37b1092793f0\",\"userCondition\":null,\"elementCondition\":null}]',1,'2023-05-04 23:26:17','2023-05-04 23:26:17','c37d153c-5b46-4edb-86c5-0b5d4bdb2a04'),(62,3,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"c3fa8902-0b9c-480e-9b47-c6c555c74e1f\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"c899eea5-625d-430a-af64-94c6c79c05dc\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"09cf0238-6bd9-4f7b-bc7a-792c59dd6f14\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"e92950dd-e385-4421-905f-63fab21d1afc\"}]',1,'2023-05-04 23:26:17','2023-05-04 23:26:17','fe2ac5db-ea5c-461a-ac11-7c900d56cedb'),(64,4,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"70562311-a4e1-453d-aa41-608f6017aabe\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":50,\"uid\":\"829f8297-732f-482d-96c7-9f9ae47cf6b4\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"27ec8eb2-b037-4427-b5de-ca356fb40a0e\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":50,\"uid\":\"2f47a457-3144-4cc3-ba1d-aa76a7094847\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"f0424f7b-3a3f-41b4-ba50-141dbb749a8e\"}]',1,'2023-05-04 23:26:17','2023-05-04 23:26:17','bc3443e1-748d-41d2-9b32-b085552cb440'),(66,5,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"27703a8d-54f0-4c5d-a62f-b533abaf64ce\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"1ce724fe-b599-479a-8d32-a12b2b1a1118\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"27ec8eb2-b037-4427-b5de-ca356fb40a0e\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\HorizontalRule\",\"uid\":\"32a3237d-d6ef-4087-b582-2ab6d808c237\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"e24b86f1-1538-4af6-9ca2-534c84649c72\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"8228b035-fb8e-4491-9498-eaa57ee42747\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\HorizontalRule\",\"uid\":\"822bbc0c-2280-41a4-b450-5a3f97755f3e\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":75,\"uid\":\"9f6212ba-897b-4f16-b10a-cf3f1af423c6\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"57640f4c-484c-49c4-a3f4-ec8694c65d42\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":75,\"uid\":\"56860896-c2eb-47fd-9f69-5613fd50e0cf\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"c7d8a886-679a-4d74-bf86-5cc1593c54b1\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":75,\"uid\":\"f4eca14b-8cb2-40ca-97bb-1c680d0a7ac9\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"ad9cc240-0c67-4bf1-ad59-183dacc2169f\"}]',1,'2023-05-04 23:26:17','2023-05-04 23:26:17','c3babd3c-ae64-40ab-9c19-3fc1ce1bb16e'),(68,6,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"5b25ff50-7547-4fb0-ae39-d98f60cfd71f\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"6a3416e6-0690-45d1-9842-c24edcaebed5\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"086259da-3672-47af-a708-cf80ee82c01e\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"f4ac93f6-026c-4b15-b4fc-105bf53db005\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"27ec8eb2-b037-4427-b5de-ca356fb40a0e\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\Heading\",\"heading\":\"Featured Projects\",\"uid\":\"229da3bd-1eea-4dcf-8a82-a69ccc4d7341\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"533fa4f7-0a44-4cbe-950a-2eceacd17c15\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"24f1ca91-8849-41c2-b4d9-f7e335886226\"}]',1,'2023-05-04 23:26:17','2023-05-04 23:26:17','7b1df43c-1bba-435b-8d56-1b4260d2efb9'),(70,1,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\Heading\",\"heading\":\"Page Details\",\"uid\":\"5551721a-1bec-43ef-841a-c760afad9d78\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":75,\"uid\":\"b19f08b2-8a4b-461a-a934-462a9e84d874\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":25,\"uid\":\"8fc32df9-5b6a-4601-9f63-6faaa280bc1d\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"ec4cd1bd-750d-47d2-b69d-59faca0bd560\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":50,\"uid\":\"88ebddad-8a2b-4424-9ed0-5fb7f45ef0ab\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"fdee1828-1284-4336-bb56-c20cfc35bcb2\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":50,\"uid\":\"e5bfaaf4-3fd8-46e0-9906-626fbaa9fe3c\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"3fdbbee9-c12e-40a5-b535-ea81e8c9a194\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\HorizontalRule\",\"uid\":\"877394a3-aecb-463d-a6a3-744563db1d18\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":25,\"uid\":\"63aa172a-e6ad-4cff-854e-ab3495e2420d\",\"userCondition\":null,\"elementCondition\":{\"elementType\":\"craft\\\\elements\\\\Entry\",\"fieldContext\":\"global\",\"class\":\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\",\"conditionRules\":[{\"class\":\"craft\\\\fields\\\\conditions\\\\LightswitchFieldConditionRule\",\"uid\":\"01d30094-fb26-420a-a613-1358da28d539\",\"value\":true,\"fieldUid\":\"fdee1828-1284-4336-bb56-c20cfc35bcb2\"}]},\"fieldUid\":\"dd481797-f29b-408b-8b8d-500817d78742\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":25,\"uid\":\"e8c44410-e834-48dd-8320-d2e71fa4ded5\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"c808777b-1863-4f28-b9ba-658f7420314c\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":25,\"uid\":\"4b252659-95b2-4d43-825e-d47c617a5c63\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"91633e6e-a0ba-4081-9b36-a6abc77465b9\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":25,\"uid\":\"39774ed1-3ccb-466e-9f91-b50fe844ad3f\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"1e72ce05-01c8-4865-b077-e1f0e99627b9\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\Heading\",\"heading\":\"Gallery\",\"uid\":\"ef1bd697-7654-4bc9-9389-caecab954496\",\"userCondition\":null,\"elementCondition\":{\"elementType\":\"craft\\\\elements\\\\Entry\",\"fieldContext\":\"global\",\"class\":\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\",\"conditionRules\":[{\"class\":\"craft\\\\fields\\\\conditions\\\\LightswitchFieldConditionRule\",\"uid\":\"e36416f0-87e0-4b75-aaea-939b6c1b8a19\",\"value\":true,\"fieldUid\":\"fdee1828-1284-4336-bb56-c20cfc35bcb2\"}]}},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":100,\"uid\":\"b2c126d1-ae43-4110-a35f-ce70a8e67921\",\"userCondition\":null,\"elementCondition\":{\"elementType\":\"craft\\\\elements\\\\Entry\",\"fieldContext\":\"global\",\"class\":\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\",\"conditionRules\":[{\"class\":\"craft\\\\fields\\\\conditions\\\\LightswitchFieldConditionRule\",\"uid\":\"6a01dfe1-fdac-4818-ace4-f5f8edd550c2\",\"value\":true,\"fieldUid\":\"fdee1828-1284-4336-bb56-c20cfc35bcb2\"}]},\"fieldUid\":\"7fdab846-07ae-4e4a-92b5-b9f6e827f4d6\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\Heading\",\"heading\":\"Page Content\",\"uid\":\"c974e290-c38a-4023-8add-1ce72ca4e5f4\",\"userCondition\":null,\"elementCondition\":{\"elementType\":\"craft\\\\elements\\\\Entry\",\"fieldContext\":\"global\",\"class\":\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\",\"conditionRules\":[{\"class\":\"craft\\\\fields\\\\conditions\\\\LightswitchFieldConditionRule\",\"uid\":\"37e25f02-1bb2-4894-9033-5e9ccc75abff\",\"value\":true,\"fieldUid\":\"fdee1828-1284-4336-bb56-c20cfc35bcb2\"}]}},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":true,\"width\":50,\"uid\":\"ca004975-21fa-41c1-aa4e-ad28bbe1fbdb\",\"userCondition\":null,\"elementCondition\":{\"elementType\":\"craft\\\\elements\\\\Entry\",\"fieldContext\":\"global\",\"class\":\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\",\"conditionRules\":[{\"class\":\"craft\\\\fields\\\\conditions\\\\LightswitchFieldConditionRule\",\"uid\":\"971a2998-c48a-49ed-ba99-ea3ea06140e5\",\"value\":true,\"fieldUid\":\"fdee1828-1284-4336-bb56-c20cfc35bcb2\"}]},\"fieldUid\":\"4bf00f78-4885-4b6b-a6a1-dd68fb6436a7\"},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":50,\"uid\":\"f6891dda-2328-4be1-b3ea-623036237ad1\",\"userCondition\":null,\"elementCondition\":{\"elementType\":\"craft\\\\elements\\\\Entry\",\"fieldContext\":\"global\",\"class\":\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\",\"conditionRules\":[{\"class\":\"craft\\\\fields\\\\conditions\\\\LightswitchFieldConditionRule\",\"uid\":\"440d248c-cf97-492f-b2f8-6f0d7f8c0325\",\"value\":true,\"fieldUid\":\"fdee1828-1284-4336-bb56-c20cfc35bcb2\"}]},\"fieldUid\":\"54a7cbee-951b-4828-8c0e-8c767689e521\"}]',1,'2023-05-04 23:26:17','2023-05-04 23:26:17','c9e2d2cf-c3c2-4078-ac7e-f7a628a6eea0'),(72,7,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"cc8bf54d-6a68-4395-9720-94b967c23338\",\"userCondition\":null,\"elementCondition\":null},{\"type\":\"craft\\\\fieldlayoutelements\\\\CustomField\",\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"required\":false,\"width\":100,\"uid\":\"3d74770c-ee96-443a-92f8-33f2d58828f1\",\"userCondition\":null,\"elementCondition\":null,\"fieldUid\":\"27ec8eb2-b037-4427-b5de-ca356fb40a0e\"}]',1,'2023-05-04 23:26:17','2023-05-04 23:26:17','27d94266-965f-4feb-9507-56282b8c732b'),(74,8,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"f99b1855-414d-435e-b0f8-89c78e6a3f7e\",\"userCondition\":null,\"elementCondition\":null}]',1,'2023-05-04 23:26:17','2023-05-04 23:26:17','9878f43e-8adb-4d60-80a0-df41f3c34fd9'),(76,9,'Content','{\"userCondition\":null,\"elementCondition\":null}','[{\"type\":\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\",\"autocomplete\":false,\"class\":null,\"size\":null,\"name\":null,\"autocorrect\":true,\"autocapitalize\":true,\"disabled\":false,\"readonly\":false,\"title\":null,\"placeholder\":null,\"step\":null,\"min\":null,\"max\":null,\"requirable\":false,\"id\":null,\"containerAttributes\":[],\"inputContainerAttributes\":[],\"labelAttributes\":[],\"orientation\":null,\"label\":null,\"instructions\":null,\"tip\":null,\"warning\":null,\"width\":100,\"uid\":\"392a6dd3-93e5-425b-9f38-05f37ba4dee0\",\"userCondition\":null,\"elementCondition\":null}]',1,'2023-05-04 23:26:17','2023-05-04 23:26:17','b7a88148-999f-4771-af54-0674ea240304');
/*!40000 ALTER TABLE `fieldlayouttabs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text DEFAULT NULL,
  `searchable` tinyint(1) NOT NULL DEFAULT 1,
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `settings` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_eeakgpfjrpcuzsfarwrcsstpkmvedpuzzrpb` (`handle`,`context`),
  KEY `idx_qshyqmvfyudrxznsjttbbfjwnkvrjtaazuvh` (`groupId`),
  KEY `idx_ebhxnuoqfccqhlwxokilkjildsllgrzfmlzl` (`context`),
  CONSTRAINT `fk_xkbmxtkgdrytmtywqynopchyarufxcnqyxiq` FOREIGN KEY (`groupId`) REFERENCES `fieldgroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
INSERT INTO `fields` VALUES (1,2,'Business Address','businessAddress','global','umdvtzcr','Seestrasse 96	\r\n8700 Küsnacht',0,'none',NULL,'craft\\redactor\\Field','{\"availableTransforms\":\"*\",\"availableVolumes\":\"*\",\"columnType\":\"text\",\"configSelectionMode\":\"choose\",\"defaultTransform\":\"\",\"manualConfig\":\"\",\"purifierConfig\":null,\"purifyHtml\":true,\"redactorConfig\":\"Simple.json\",\"removeEmptyTags\":false,\"removeInlineStyles\":false,\"removeNbsp\":false,\"showHtmlButtonForNonAdmins\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"uiMode\":\"enlarged\"}','2023-05-04 22:27:55','2023-05-04 22:27:55','c7d8a886-679a-4d74-bf86-5cc1593c54b1'),(2,1,'Project Building Type','projectBuildingType','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Categories','{\"allowLimit\":false,\"allowMultipleSources\":false,\"allowSelfRelations\":false,\"branchLimit\":1,\"localizeRelations\":false,\"maxRelations\":null,\"minRelations\":null,\"selectionLabel\":null,\"showSiteMenu\":false,\"source\":\"group:90132f11-3bdb-456a-a01e-18653a2c7371\",\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":null}','2023-05-04 22:27:55','2023-05-04 22:27:55','dd481797-f29b-408b-8b8d-500817d78742'),(3,1,'Reference Project','referenceProject','global','khhktnju',NULL,0,'none',NULL,'craft\\fields\\Lightswitch','{\"default\":false,\"offLabel\":\"Hidden\",\"onLabel\":\"Shown\"}','2023-05-04 22:27:55','2023-05-04 22:27:55','fdee1828-1284-4336-bb56-c20cfc35bcb2'),(4,2,'Business Details','businessDetails','global','ipwofvgv','Caretta + Gitz AG			\r\nBaumanagement 				\r\nGesamtplanung',0,'none',NULL,'craft\\redactor\\Field','{\"availableTransforms\":\"*\",\"availableVolumes\":\"*\",\"columnType\":\"text\",\"configSelectionMode\":\"choose\",\"defaultTransform\":\"\",\"manualConfig\":\"\",\"purifierConfig\":null,\"purifyHtml\":true,\"redactorConfig\":\"Simple.json\",\"removeEmptyTags\":false,\"removeInlineStyles\":false,\"removeNbsp\":false,\"showHtmlButtonForNonAdmins\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"uiMode\":\"enlarged\"}','2023-05-04 22:27:55','2023-05-04 22:27:55','57640f4c-484c-49c4-a3f4-ec8694c65d42'),(5,2,'Team Members','teamMembers','global',NULL,NULL,0,'site',NULL,'verbb\\supertable\\fields\\SuperTableField','{\"blockTypeFields\":0,\"changedFieldIndicator\":285505308,\"columns\":{\"c899eea5-625d-430a-af64-94c6c79c05dc\":{\"width\":\"49%\"},\"e92950dd-e385-4421-905f-63fab21d1afc\":{\"width\":\"49%\"}},\"contentTable\":\"{{%stc_teammembers}}\",\"fieldLayout\":\"matrix\",\"maxRows\":null,\"minRows\":null,\"propagationKeyFormat\":null,\"propagationMethod\":\"all\",\"selectionLabel\":null,\"staticField\":null}','2023-05-04 22:27:55','2023-05-04 22:27:55','8228b035-fb8e-4491-9498-eaa57ee42747'),(6,1,'Project Details','projectDetails','global','zqsmmabq','Bauherrschaft, Erstellungszeit, etc',0,'none',NULL,'craft\\redactor\\Field','{\"availableTransforms\":\"*\",\"availableVolumes\":\"*\",\"columnType\":\"text\",\"configSelectionMode\":\"choose\",\"defaultTransform\":\"\",\"manualConfig\":\"\",\"purifierConfig\":null,\"purifyHtml\":true,\"redactorConfig\":\"Simple.json\",\"removeEmptyTags\":false,\"removeInlineStyles\":false,\"removeNbsp\":false,\"showHtmlButtonForNonAdmins\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"uiMode\":\"enlarged\"}','2023-05-04 22:27:55','2023-05-04 22:27:55','4bf00f78-4885-4b6b-a6a1-dd68fb6436a7'),(7,2,'Business Contact','businessContact','global','eyxrfojc','Telefon: 043 222 31 80\r\nTelefax: 043 222 31 81\r\ninfo@caretta-gitz.ch',0,'none',NULL,'craft\\redactor\\Field','{\"availableTransforms\":\"*\",\"availableVolumes\":\"*\",\"columnType\":\"text\",\"configSelectionMode\":\"choose\",\"defaultTransform\":\"\",\"manualConfig\":\"\",\"purifierConfig\":null,\"purifyHtml\":true,\"redactorConfig\":\"Simple.json\",\"removeEmptyTags\":false,\"removeInlineStyles\":false,\"removeNbsp\":false,\"showHtmlButtonForNonAdmins\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"uiMode\":\"enlarged\"}','2023-05-04 22:27:55','2023-05-04 22:27:55','ad9cc240-0c67-4bf1-ad59-183dacc2169f'),(8,4,'Actuelle Project Text','actuelleProjectText','global','goanvaoh','This text goes before the actuelle project section on the archiv page',0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":true,\"placeholder\":null,\"uiMode\":\"normal\"}','2023-05-04 22:27:55','2023-05-04 22:27:55','f0424f7b-3a3f-41b4-ba50-141dbb749a8e'),(9,1,'Project Number','projectNumber','global','bczznfzn','ex: 2105 - the # will be added automatically',0,'none',NULL,'craft\\fields\\Number','{\"decimals\":0,\"defaultValue\":null,\"max\":null,\"min\":0,\"prefix\":null,\"previewCurrency\":null,\"previewFormat\":\"none\",\"size\":null,\"suffix\":null}','2023-05-04 22:27:55','2023-05-04 22:27:55','ec4cd1bd-750d-47d2-b69d-59faca0bd560'),(10,5,'Page Text','pageText','global','xdbaxwyo','This is the large text shown on the top of the page.',0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":true,\"placeholder\":null,\"uiMode\":\"normal\"}','2023-05-04 22:27:55','2023-05-04 22:27:55','27ec8eb2-b037-4427-b5de-ca356fb40a0e'),(11,1,'Project Gallery','projectGallery','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":null,\"defaultUploadLocationSource\":\"volume:8427f64a-7a41-4982-9210-df04b8400923\",\"defaultUploadLocationSubpath\":null,\"localizeRelations\":false,\"maxRelations\":null,\"minRelations\":0,\"previewMode\":\"full\",\"restrictFiles\":false,\"restrictLocation\":true,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:8427f64a-7a41-4982-9210-df04b8400923\",\"restrictedLocationSubpath\":null,\"selectionCondition\":{\"elementType\":\"craft\\\\elements\\\\Asset\",\"fieldContext\":\"global\",\"class\":\"craft\\\\elements\\\\conditions\\\\assets\\\\AssetCondition\"},\"selectionLabel\":\"Add Image\",\"showSiteMenu\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"source\":null,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2023-05-04 22:27:55','2023-05-04 22:27:55','7fdab846-07ae-4e4a-92b5-b9f6e827f4d6'),(12,1,'Project Text Content','projectTextContent','global','rgnrudxv','This is where the project description will be put',0,'none',NULL,'craft\\redactor\\Field','{\"availableTransforms\":\"*\",\"availableVolumes\":\"*\",\"columnType\":\"text\",\"configSelectionMode\":\"choose\",\"defaultTransform\":\"\",\"manualConfig\":\"\",\"purifierConfig\":null,\"purifyHtml\":true,\"redactorConfig\":\"Simple.json\",\"removeEmptyTags\":false,\"removeInlineStyles\":false,\"removeNbsp\":false,\"showHtmlButtonForNonAdmins\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"uiMode\":\"normal\"}','2023-05-04 22:27:55','2023-05-04 22:27:55','54a7cbee-951b-4828-8c0e-8c767689e521'),(13,1,'Project Architekt','projectArchitekt','global','pgchnaiv',NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2023-05-04 22:27:55','2023-05-04 22:27:55','c808777b-1863-4f28-b9ba-658f7420314c'),(14,1,'Project Zeitdauer','projectZeitdauer','global','gnmzlvwh',NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2023-05-04 22:27:55','2023-05-04 22:27:55','1e72ce05-01c8-4865-b077-e1f0e99627b9'),(15,1,'Project Bauherrschaft','projectBauherrschaft','global','mnehzyjd',NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2023-05-04 22:27:55','2023-05-04 22:27:55','91633e6e-a0ba-4081-9b36-a6abc77465b9'),(16,1,'Actuelle Project','actuelleProject','global','zdyxjjfg',NULL,0,'none',NULL,'craft\\fields\\Lightswitch','{\"default\":false,\"offLabel\":null,\"onLabel\":null}','2023-05-04 22:27:55','2023-05-04 22:27:55','3fdbbee9-c12e-40a5-b535-ea81e8c9a194'),(17,5,'Marquee Text','marqueeText','global','exofsswa','This is shown in the green marquee on the top of the Home page',0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2023-05-04 22:27:55','2023-05-04 22:27:55','086259da-3672-47af-a708-cf80ee82c01e'),(18,3,'Featured Projects','featuredProjects','global',NULL,'Select Projects to be shown on home page',0,'site',NULL,'craft\\fields\\Entries','{\"allowSelfRelations\":false,\"localizeRelations\":false,\"maxRelations\":null,\"minRelations\":null,\"selectionCondition\":{\"elementType\":\"craft\\\\elements\\\\Entry\",\"fieldContext\":\"global\",\"class\":\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\",\"conditionRules\":[{\"class\":\"craft\\\\fields\\\\conditions\\\\RelationalFieldConditionRule\",\"uid\":\"2549b14b-4420-49f1-802b-09bebfdd841b\",\"operator\":\"notempty\",\"fieldUid\":\"7fdab846-07ae-4e4a-92b5-b9f6e827f4d6\"}]},\"selectionLabel\":null,\"showSiteMenu\":false,\"source\":null,\"sources\":[\"section:30b9b0ce-bf0d-4512-af8e-7bbe939a1a01\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":null}','2023-05-04 22:27:55','2023-05-04 22:27:55','24f1ca91-8849-41c2-b4d9-f7e335886226'),(19,NULL,'Name','teamName','superTableBlockType:82bed934-484a-4648-9a87-d49db048f5ae',NULL,NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"columnType\":null,\"initialRows\":4,\"multiline\":false,\"placeholder\":null,\"uiMode\":\"normal\"}','2023-05-04 22:27:55','2023-05-04 22:27:55','c899eea5-625d-430a-af64-94c6c79c05dc'),(20,NULL,'Photo','photo','superTableBlockType:82bed934-484a-4648-9a87-d49db048f5ae',NULL,NULL,0,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":null,\"defaultUploadLocationSource\":\"volume:0e2e66d1-935a-4b1e-8360-06dcda59a613\",\"defaultUploadLocationSubpath\":null,\"localizeRelations\":false,\"maxRelations\":1,\"minRelations\":1,\"previewMode\":\"full\",\"restrictFiles\":false,\"restrictLocation\":true,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:0e2e66d1-935a-4b1e-8360-06dcda59a613\",\"restrictedLocationSubpath\":null,\"selectionCondition\":{\"elementType\":\"craft\\\\elements\\\\Asset\",\"fieldContext\":\"global\",\"class\":\"craft\\\\elements\\\\conditions\\\\assets\\\\AssetCondition\"},\"selectionLabel\":null,\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"source\":null,\"sources\":\"*\",\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2023-05-04 22:27:55','2023-05-04 22:27:55','e92950dd-e385-4421-905f-63fab21d1afc');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `globalsets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_nkbwnlvsicvgcvbvrxmenigtpnnzjckqtmxu` (`name`),
  KEY `idx_hssvpheqttzlngtztglgzcjnakudxcwpiqbp` (`handle`),
  KEY `idx_cqnreqszeuosczlanquefvtrkslmutowhely` (`fieldLayoutId`),
  KEY `idx_bxdmlbqhoxhveisgxcqkrtexoedfnbcghgfe` (`sortOrder`),
  CONSTRAINT `fk_dgytsycmcfimonvtgdwsokeaunpmouwsibpd` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hspfqwivpighqzlyeosoxenqhpuqdhfkmhfj` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gqlschemas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` text DEFAULT NULL,
  `isPublic` tinyint(1) NOT NULL DEFAULT 0,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gqltokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xzhvpdcmrplelnnetudlguutqwkeixhgjezn` (`accessToken`),
  UNIQUE KEY `idx_rtdrivueyerkblglqvlfcddvjbjgxfgfkewh` (`name`),
  KEY `fk_tshawcqnxbprdbbzkbztwxczitrmllgcnfse` (`schemaId`),
  CONSTRAINT `fk_tshawcqnxbprdbbzkbztwxczitrmllgcnfse` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `imagetransformindex` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `assetId` int(11) NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT 0,
  `inProgress` tinyint(1) NOT NULL DEFAULT 0,
  `error` tinyint(1) NOT NULL DEFAULT 0,
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_yzqirhmmbiicqisqbrrxbgcfvwsigqxznbvp` (`assetId`,`transformString`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransformindex`
--

LOCK TABLES `imagetransformindex` WRITE;
/*!40000 ALTER TABLE `imagetransformindex` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransformindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `imagetransforms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int(11) unsigned DEFAULT NULL,
  `height` int(11) unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int(11) DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qnrrgdrdeyvsuezqqornxcbyhhoqqdjrueis` (`name`),
  KEY `idx_srvusgwyhktqeisvgaawwchnxazsoxnpellk` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
INSERT INTO `imagetransforms` VALUES (1,'Home Images','homeImages','crop','center-center',NULL,1400,NULL,NULL,'none','2023-05-04 22:27:56','2023-05-04 22:27:56','2023-05-04 22:27:56','6d028446-8fb7-40aa-b8c9-2262ba95b3c0'),(2,'About Us','aboutUs','crop','center-center',NULL,1000,NULL,82,'none','2023-05-04 22:27:56','2023-05-04 22:27:56','2023-05-04 22:27:56','30e76fa4-2995-473a-8120-166aafcb7e43'),(3,'LowRes','lowres','crop','center-center',NULL,100,NULL,30,'none','2023-05-04 22:27:56','2023-05-04 22:27:56','2023-05-04 22:27:56','3aa103e0-9c7a-4938-9e99-b2cc95c894f6'),(4,'Reference Images','referenceImages','crop','center-center',NULL,800,NULL,NULL,'none','2023-05-04 22:27:56','2023-05-04 22:27:56','2023-05-04 22:27:56','8e658642-a4e5-484c-920d-25db92a50da4'),(5,'Home Low Res','homeLowRes','crop','center-center',NULL,1400,NULL,10,'none','2023-05-04 22:27:56','2023-05-04 22:27:56','2023-05-04 22:27:56','09ae9717-2b1a-45ee-aff1-34710fa649c1');
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT 0,
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
INSERT INTO `info` VALUES (1,'4.3.6.1','4.0.0.9',0,'bkqqthffwusk','3@sspaijsoic','2023-05-04 22:27:54','2023-05-04 23:26:18','781ba11a-900a-4b50-99fc-228e7acad385');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lenz_linkfield`
--

DROP TABLE IF EXISTS `lenz_linkfield`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lenz_linkfield` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `type` varchar(63) DEFAULT NULL,
  `linkedUrl` text DEFAULT NULL,
  `linkedId` int(11) DEFAULT NULL,
  `linkedSiteId` int(11) DEFAULT NULL,
  `linkedTitle` varchar(255) DEFAULT NULL,
  `payload` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_pzifnxhtvspmjtebdtwnmdvwgnqnznlitqqk` (`elementId`,`siteId`,`fieldId`),
  KEY `idx_duztopvokaomknafpxlhehowjjlwroxfvrbx` (`fieldId`),
  KEY `idx_lvcpasjwyxqwqnfirerpevueyjecqkbslsup` (`siteId`),
  KEY `fk_qsmnpcwwgtjtzhmujejnexkdbfchfharcxpe` (`linkedId`),
  KEY `fk_hktifcgssfgeobtrtopsgxuppncatsevmrmz` (`linkedSiteId`),
  CONSTRAINT `fk_dctwqchyyefvsvoounphqkmsdnwumspcubuu` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_hktifcgssfgeobtrtopsgxuppncatsevmrmz` FOREIGN KEY (`linkedSiteId`) REFERENCES `sites` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `fk_qsmnpcwwgtjtzhmujejnexkdbfchfharcxpe` FOREIGN KEY (`linkedId`) REFERENCES `elements` (`id`) ON DELETE SET NULL ON UPDATE SET NULL,
  CONSTRAINT `fk_turcdpmhjmdajvssnssnjnjxnolcwodnwdlg` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lenz_linkfield`
--

LOCK TABLES `lenz_linkfield` WRITE;
/*!40000 ALTER TABLE `lenz_linkfield` DISABLE KEYS */;
/*!40000 ALTER TABLE `lenz_linkfield` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixblocks`
--

DROP TABLE IF EXISTS `matrixblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixblocks` (
  `id` int(11) NOT NULL,
  `primaryOwnerId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_jlfsjmmeiphwtggopdkeaqntgxjlxtcmlrqg` (`primaryOwnerId`),
  KEY `idx_yhbsnenxegnrozdfwcmypmgpzcwivlhvvsmv` (`fieldId`),
  KEY `idx_jjofltqbxfnzbwptjljvgkinbuljzjvhhlmu` (`typeId`),
  CONSTRAINT `fk_bfjqqfkuqfqtmicnfubmufukoppsgkmwfjoy` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xcvyouuqkuscpcbovojyzzmyyqrbtdqqhjri` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yhlddknxdxgsdphfogcdlfmtyqzjhponqumw` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zpfrekfpuczmqxhblunkefkeqbtdvdmjpyyl` FOREIGN KEY (`typeId`) REFERENCES `matrixblocktypes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixblocks`
--

LOCK TABLES `matrixblocks` WRITE;
/*!40000 ALTER TABLE `matrixblocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `matrixblocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixblocks_owners`
--

DROP TABLE IF EXISTS `matrixblocks_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixblocks_owners` (
  `blockId` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned NOT NULL,
  PRIMARY KEY (`blockId`,`ownerId`),
  KEY `fk_ufdqptyvjmmhasakmrefylwkuivlcavkiwtm` (`ownerId`),
  CONSTRAINT `fk_qzqxoyeqncbwvophwdsargcaxnogkhzjixio` FOREIGN KEY (`blockId`) REFERENCES `matrixblocks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ufdqptyvjmmhasakmrefylwkuivlcavkiwtm` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixblocks_owners`
--

LOCK TABLES `matrixblocks_owners` WRITE;
/*!40000 ALTER TABLE `matrixblocks_owners` DISABLE KEYS */;
/*!40000 ALTER TABLE `matrixblocks_owners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `matrixblocktypes`
--

DROP TABLE IF EXISTS `matrixblocktypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `matrixblocktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bsgmaljvcgvqtxpwxqgfwzvkblxxjctbxmuc` (`name`,`fieldId`),
  KEY `idx_wemteirmxyjhvutkirnxixwmjyujaqcfgslh` (`handle`,`fieldId`),
  KEY `idx_ktvmjgrxvzmoocaksgpjsxcovebulcbnlggd` (`fieldId`),
  KEY `idx_arisvdcrqxauwyjcparpjtnqgnrmhqtupmsm` (`fieldLayoutId`),
  CONSTRAINT `fk_kklrodihjfembvzmtbjwhhirsonrtcdnzuqo` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vvdhoxakhcdrwrcttiamtgtuiicptgpbevnr` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matrixblocktypes`
--

LOCK TABLES `matrixblocktypes` WRITE;
/*!40000 ALTER TABLE `matrixblocktypes` DISABLE KEYS */;
/*!40000 ALTER TABLE `matrixblocktypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ktpwodeqotuwzemgzwmgwedrjbntigokpfvs` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'plugin:blitz-recommendations','Install','2023-05-04 22:27:54','2023-05-04 22:27:54','2023-05-04 22:27:54','bb745ae1-454e-431f-a3df-45b7bbeafa5d'),(2,'plugin:blitz-recommendations','m220512_120000_reinstall','2023-05-04 22:27:54','2023-05-04 22:27:54','2023-05-04 22:27:54','8d1528c9-ba73-4c14-bf3d-89869262af88'),(3,'plugin:feed-me','Install','2023-05-04 22:27:55','2023-05-04 22:27:55','2023-05-04 22:27:55','f3866d0b-7907-4a7e-a5ed-27d5f90b5394'),(4,'plugin:redactor','m180430_204710_remove_old_plugins','2023-05-04 22:27:55','2023-05-04 22:27:55','2023-05-04 22:27:55','9ebd5d35-1a54-471e-90bf-e1f31b21c9d4'),(5,'plugin:redactor','Install','2023-05-04 22:27:55','2023-05-04 22:27:55','2023-05-04 22:27:55','47cee66d-3b38-4a74-a2de-664ee59b18d2'),(6,'plugin:redactor','m190225_003922_split_cleanup_html_settings','2023-05-04 22:27:55','2023-05-04 22:27:55','2023-05-04 22:27:55','bae4990c-5985-4303-bc9a-eb154d935aff'),(7,'plugin:super-table','Install','2023-05-04 22:27:55','2023-05-04 22:27:55','2023-05-04 22:27:55','0f9d51ea-72ea-4486-9124-f7a316618920'),(8,'plugin:super-table','m220308_000000_remove_superfluous_uids','2023-05-04 22:27:55','2023-05-04 22:27:55','2023-05-04 22:27:55','fd4b4a3a-c134-41e3-ac46-e43f7425ae93'),(9,'plugin:super-table','m220308_100000_owners_table','2023-05-04 22:27:55','2023-05-04 22:27:55','2023-05-04 22:27:55','5b671c65-e66a-4290-b7d5-656cccd298d2'),(10,'plugin:typedlinkfield','Install','2023-05-04 22:27:55','2023-05-04 22:27:55','2023-05-04 22:27:55','835d8e99-21f8-4b0e-88c2-bbefd68e877b'),(11,'plugin:typedlinkfield','m190417_202153_migrateDataToTable','2023-05-04 22:27:55','2023-05-04 22:27:55','2023-05-04 22:27:55','59ca3ecc-55f4-4fcf-a33e-bf835abcc65b'),(12,'craft','Install','2023-05-04 22:27:56','2023-05-04 22:27:56','2023-05-04 22:27:56','7bf5cb67-465e-4514-83fc-010af7183a8a'),(13,'craft','m210121_145800_asset_indexing_changes','2023-05-04 22:27:56','2023-05-04 22:27:56','2023-05-04 22:27:56','7a319c6a-36cb-47c3-8e01-f17fbddda946'),(14,'craft','m210624_222934_drop_deprecated_tables','2023-05-04 22:27:56','2023-05-04 22:27:56','2023-05-04 22:27:56','6e4ac810-eae7-414d-b140-bb4682ab3bbe'),(15,'craft','m210724_180756_rename_source_cols','2023-05-04 22:27:56','2023-05-04 22:27:56','2023-05-04 22:27:56','4de3c557-dd2d-42a8-a6eb-e27168a5ee83'),(16,'craft','m210809_124211_remove_superfluous_uids','2023-05-04 22:27:56','2023-05-04 22:27:56','2023-05-04 22:27:56','c935c2d2-bcf2-473a-ac02-1492e136d2f8'),(17,'craft','m210817_014201_universal_users','2023-05-04 22:27:56','2023-05-04 22:27:56','2023-05-04 22:27:56','c95945e5-87e7-4a19-902b-d17dc6ab679d'),(18,'craft','m210904_132612_store_element_source_settings_in_project_config','2023-05-04 22:27:56','2023-05-04 22:27:56','2023-05-04 22:27:56','1e5c1000-58b1-4662-bed3-732d9cc092ab'),(19,'craft','m211115_135500_image_transformers','2023-05-04 22:27:56','2023-05-04 22:27:56','2023-05-04 22:27:56','eb9f36ca-fafd-4a3b-8f49-2d5d0268b64f'),(20,'craft','m211201_131000_filesystems','2023-05-04 22:27:56','2023-05-04 22:27:56','2023-05-04 22:27:56','6abbf87d-cba6-4866-9f44-bff59687680d'),(21,'craft','m220103_043103_tab_conditions','2023-05-04 22:27:56','2023-05-04 22:27:56','2023-05-04 22:27:56','803b8631-23b7-49b5-ad31-ec4351b697a8'),(22,'craft','m220104_003433_asset_alt_text','2023-05-04 22:27:56','2023-05-04 22:27:56','2023-05-04 22:27:56','42345579-6156-412b-a386-61ab010b5c0f'),(23,'craft','m220123_213619_update_permissions','2023-05-04 22:27:56','2023-05-04 22:27:56','2023-05-04 22:27:56','49d91f2e-1141-41d1-a8f2-cc5f73fd3192'),(24,'craft','m220126_003432_addresses','2023-05-04 22:27:56','2023-05-04 22:27:56','2023-05-04 22:27:56','ff3eca13-07bd-46b1-ba63-b64b40469531'),(25,'craft','m220209_095604_add_indexes','2023-05-04 22:27:56','2023-05-04 22:27:56','2023-05-04 22:27:56','3b0833a2-8428-45c6-ab69-ae5f336be140'),(26,'craft','m220213_015220_matrixblocks_owners_table','2023-05-04 22:27:56','2023-05-04 22:27:56','2023-05-04 22:27:56','d25dd6cf-7e0d-4684-9ed7-3bde10bac741'),(27,'craft','m220214_000000_truncate_sessions','2023-05-04 22:27:56','2023-05-04 22:27:56','2023-05-04 22:27:56','e817bb88-b0d2-4758-8771-98bba443e8b2'),(28,'craft','m220222_122159_full_names','2023-05-04 22:27:56','2023-05-04 22:27:56','2023-05-04 22:27:56','52d7787f-68c2-4fd2-9d2e-5cacdcd4e1ba'),(29,'craft','m220223_180559_nullable_address_owner','2023-05-04 22:27:56','2023-05-04 22:27:56','2023-05-04 22:27:56','73927a0b-9e6d-47d6-856b-91d861f7a6ba'),(30,'craft','m220225_165000_transform_filesystems','2023-05-04 22:27:56','2023-05-04 22:27:56','2023-05-04 22:27:56','171b5c0c-1a75-4fa0-9e53-08c8ef27d83e'),(31,'craft','m220309_152006_rename_field_layout_elements','2023-05-04 22:27:56','2023-05-04 22:27:56','2023-05-04 22:27:56','7d1b3c7f-d582-4b76-b541-cad474e6fc9c'),(32,'craft','m220314_211928_field_layout_element_uids','2023-05-04 22:27:56','2023-05-04 22:27:56','2023-05-04 22:27:56','33b6b009-d060-4344-90ad-2b44ce60b970'),(33,'craft','m220316_123800_transform_fs_subpath','2023-05-04 22:27:56','2023-05-04 22:27:56','2023-05-04 22:27:56','90b3ed9b-baa9-4d97-8c19-9f694b907151'),(34,'craft','m220317_174250_release_all_jobs','2023-05-04 22:27:56','2023-05-04 22:27:56','2023-05-04 22:27:56','78ba8213-ef71-47bb-a208-d7e783046a46'),(35,'craft','m220330_150000_add_site_gql_schema_components','2023-05-04 22:27:56','2023-05-04 22:27:56','2023-05-04 22:27:56','a75b0ae9-5baa-434d-940d-29bd23b287b9'),(36,'craft','m220413_024536_site_enabled_string','2023-05-04 22:27:56','2023-05-04 22:27:56','2023-05-04 22:27:56','db8e62ce-6ac8-4ef8-ab01-1bbdb0fea2fd');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plugins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `licenseKeyStatus` enum('valid','trial','invalid','mismatched','astray','unknown') NOT NULL DEFAULT 'unknown',
  `licensedEdition` varchar(255) DEFAULT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hpmvglruepwroseemvwmslloduxgxvmadajf` (`handle`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
INSERT INTO `plugins` VALUES (1,'assetrev','7.0.0','1.0.0','unknown',NULL,'2023-05-04 22:27:54','2023-05-04 22:27:54','2023-05-04 23:30:43','a375baf5-5690-4719-a2ad-93177a7b4795'),(2,'blitz-recommendations','2.1.1','2.1.0','unknown',NULL,'2023-05-04 22:27:54','2023-05-04 22:27:54','2023-05-04 23:30:43','51b0674a-6488-4512-9f12-ddfd75ce16b5'),(3,'environment-label','4.0.2','1.0.0','unknown',NULL,'2023-05-04 22:27:54','2023-05-04 22:27:54','2023-05-04 23:30:43','635bb0fb-16dd-45bf-9381-fe93220f760d'),(4,'feed-me','5.0.4','4.4.0','unknown',NULL,'2023-05-04 22:27:55','2023-05-04 22:27:55','2023-05-04 23:30:43','f2893ac5-a0a9-459f-8936-6d02e3c40f74'),(5,'position-fieldtype','4.0.0-beta.3','1.0.0','unknown',NULL,'2023-05-04 22:27:55','2023-05-04 22:27:55','2023-05-04 23:30:43','f9cfb8db-d42b-4f03-a23c-329b2068065d'),(6,'redactor','3.0.3','2.3.0','unknown',NULL,'2023-05-04 22:27:55','2023-05-04 22:27:55','2023-05-04 23:30:43','bc9e573a-9e9a-4c1d-9dc4-54f053708459'),(7,'super-table','3.0.0','3.0.0','unknown',NULL,'2023-05-04 22:27:55','2023-05-04 22:27:55','2023-05-04 23:30:43','2f610308-9c69-4ece-b279-68e06fb2924b'),(8,'templatecomments','4.0.0','1.0.0','unknown',NULL,'2023-05-04 22:27:55','2023-05-04 22:27:55','2023-05-04 23:30:43','6fe50409-eac1-47d6-8b86-2c3dd292d9d6'),(9,'typedlinkfield','2.1.5','2.0.0','unknown',NULL,'2023-05-04 22:27:55','2023-05-04 22:27:55','2023-05-04 23:30:43','8826e303-d72c-4f75-bb23-4ed4c9689262');
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
INSERT INTO `projectconfig` VALUES ('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.defaultPlacement','\"end\"'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.fieldLayouts.a83364aa-6864-4cf7-a460-ebb621d1723a.tabs.0.elementCondition','null'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.fieldLayouts.a83364aa-6864-4cf7-a460-ebb621d1723a.tabs.0.elements.0.autocapitalize','true'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.fieldLayouts.a83364aa-6864-4cf7-a460-ebb621d1723a.tabs.0.elements.0.autocomplete','false'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.fieldLayouts.a83364aa-6864-4cf7-a460-ebb621d1723a.tabs.0.elements.0.autocorrect','true'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.fieldLayouts.a83364aa-6864-4cf7-a460-ebb621d1723a.tabs.0.elements.0.class','null'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.fieldLayouts.a83364aa-6864-4cf7-a460-ebb621d1723a.tabs.0.elements.0.disabled','false'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.fieldLayouts.a83364aa-6864-4cf7-a460-ebb621d1723a.tabs.0.elements.0.elementCondition','null'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.fieldLayouts.a83364aa-6864-4cf7-a460-ebb621d1723a.tabs.0.elements.0.id','null'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.fieldLayouts.a83364aa-6864-4cf7-a460-ebb621d1723a.tabs.0.elements.0.instructions','null'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.fieldLayouts.a83364aa-6864-4cf7-a460-ebb621d1723a.tabs.0.elements.0.label','null'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.fieldLayouts.a83364aa-6864-4cf7-a460-ebb621d1723a.tabs.0.elements.0.max','null'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.fieldLayouts.a83364aa-6864-4cf7-a460-ebb621d1723a.tabs.0.elements.0.min','null'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.fieldLayouts.a83364aa-6864-4cf7-a460-ebb621d1723a.tabs.0.elements.0.name','null'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.fieldLayouts.a83364aa-6864-4cf7-a460-ebb621d1723a.tabs.0.elements.0.orientation','null'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.fieldLayouts.a83364aa-6864-4cf7-a460-ebb621d1723a.tabs.0.elements.0.placeholder','null'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.fieldLayouts.a83364aa-6864-4cf7-a460-ebb621d1723a.tabs.0.elements.0.readonly','false'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.fieldLayouts.a83364aa-6864-4cf7-a460-ebb621d1723a.tabs.0.elements.0.requirable','false'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.fieldLayouts.a83364aa-6864-4cf7-a460-ebb621d1723a.tabs.0.elements.0.size','null'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.fieldLayouts.a83364aa-6864-4cf7-a460-ebb621d1723a.tabs.0.elements.0.step','null'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.fieldLayouts.a83364aa-6864-4cf7-a460-ebb621d1723a.tabs.0.elements.0.tip','null'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.fieldLayouts.a83364aa-6864-4cf7-a460-ebb621d1723a.tabs.0.elements.0.title','null'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.fieldLayouts.a83364aa-6864-4cf7-a460-ebb621d1723a.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\TitleField\"'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.fieldLayouts.a83364aa-6864-4cf7-a460-ebb621d1723a.tabs.0.elements.0.uid','\"5f0d708d-554f-44e4-a7b6-37b1092793f0\"'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.fieldLayouts.a83364aa-6864-4cf7-a460-ebb621d1723a.tabs.0.elements.0.userCondition','null'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.fieldLayouts.a83364aa-6864-4cf7-a460-ebb621d1723a.tabs.0.elements.0.warning','null'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.fieldLayouts.a83364aa-6864-4cf7-a460-ebb621d1723a.tabs.0.elements.0.width','100'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.fieldLayouts.a83364aa-6864-4cf7-a460-ebb621d1723a.tabs.0.name','\"Content\"'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.fieldLayouts.a83364aa-6864-4cf7-a460-ebb621d1723a.tabs.0.uid','\"c37d153c-5b46-4edb-86c5-0b5d4bdb2a04\"'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.fieldLayouts.a83364aa-6864-4cf7-a460-ebb621d1723a.tabs.0.userCondition','null'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.handle','\"buildingType\"'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.name','\"Building Type\"'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.siteSettings.f70b9a5b-18df-4c74-9883-5a97fbf5f7f4.hasUrls','false'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.siteSettings.f70b9a5b-18df-4c74-9883-5a97fbf5f7f4.template','null'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.siteSettings.f70b9a5b-18df-4c74-9883-5a97fbf5f7f4.uriFormat','null'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.structure.maxLevels','1'),('categoryGroups.90132f11-3bdb-456a-a01e-18653a2c7371.structure.uid','\"1e7fc618-201b-479e-8fdc-caae9f37615f\"'),('dateModified','1683239276'),('elementSources.craft\\elements\\Entry.0.key','\"*\"'),('elementSources.craft\\elements\\Entry.0.type','\"native\"'),('elementSources.craft\\elements\\Entry.1.key','\"singles\"'),('elementSources.craft\\elements\\Entry.1.type','\"native\"'),('elementSources.craft\\elements\\Entry.2.heading','\"Channels\"'),('elementSources.craft\\elements\\Entry.2.type','\"heading\"'),('elementSources.craft\\elements\\Entry.3.disabled','false'),('elementSources.craft\\elements\\Entry.3.key','\"section:30b9b0ce-bf0d-4512-af8e-7bbe939a1a01\"'),('elementSources.craft\\elements\\Entry.3.tableAttributes.0','\"postDate\"'),('elementSources.craft\\elements\\Entry.3.tableAttributes.1','\"expiryDate\"'),('elementSources.craft\\elements\\Entry.3.tableAttributes.2','\"link\"'),('elementSources.craft\\elements\\Entry.3.tableAttributes.3','\"field:fdee1828-1284-4336-bb56-c20cfc35bcb2\"'),('elementSources.craft\\elements\\Entry.3.type','\"native\"'),('email.fromEmail','\"rsenaultc@gmail.com\"'),('email.fromName','\"BiteRate\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elementCondition','null'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.0.autocapitalize','true'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.0.autocomplete','false'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.0.autocorrect','true'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.0.class','null'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.0.disabled','false'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.0.elementCondition','null'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.0.id','null'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.0.instructions','null'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.0.label','null'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.0.max','null'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.0.min','null'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.0.name','null'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.0.orientation','null'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.0.placeholder','null'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.0.readonly','false'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.0.requirable','false'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.0.size','null'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.0.step','null'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.0.tip','null'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.0.title','null'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.0.uid','\"70562311-a4e1-453d-aa41-608f6017aabe\"'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.0.userCondition','null'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.0.warning','null'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.0.width','100'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.1.elementCondition','null'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.1.fieldUid','\"27ec8eb2-b037-4427-b5de-ca356fb40a0e\"'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.1.instructions','null'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.1.label','null'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.1.required','false'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.1.tip','null'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.1.uid','\"829f8297-732f-482d-96c7-9f9ae47cf6b4\"'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.1.userCondition','null'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.1.warning','null'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.1.width','50'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.2.elementCondition','null'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.2.fieldUid','\"f0424f7b-3a3f-41b4-ba50-141dbb749a8e\"'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.2.instructions','null'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.2.label','null'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.2.required','false'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.2.tip','null'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.2.uid','\"2f47a457-3144-4cc3-ba1d-aa76a7094847\"'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.2.userCondition','null'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.2.warning','null'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.elements.2.width','50'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.name','\"Content\"'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.uid','\"bc3443e1-748d-41d2-9b32-b085552cb440\"'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.fieldLayouts.2aac7003-4ca0-4dae-89b8-45996b2c15b8.tabs.0.userCondition','null'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.handle','\"archiv\"'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.hasTitleField','false'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.name','\"Archiv\"'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.section','\"b373d66a-5a09-4164-a51a-bbbef0102a75\"'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.sortOrder','1'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.titleFormat','\"{section.name|raw}\"'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.titleTranslationKeyFormat','null'),('entryTypes.272d5a67-670b-4bfd-ba65-bbd133766256.titleTranslationMethod','\"site\"'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elementCondition','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.0.autocapitalize','true'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.0.autocomplete','false'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.0.autocorrect','true'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.0.class','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.0.disabled','false'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.0.elementCondition','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.0.id','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.0.instructions','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.0.label','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.0.max','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.0.min','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.0.name','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.0.orientation','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.0.placeholder','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.0.readonly','false'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.0.requirable','false'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.0.size','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.0.step','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.0.tip','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.0.title','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.0.uid','\"5b25ff50-7547-4fb0-ae39-d98f60cfd71f\"'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.0.userCondition','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.0.warning','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.0.width','100'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.1.elementCondition','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.1.fieldUid','\"086259da-3672-47af-a708-cf80ee82c01e\"'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.1.instructions','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.1.label','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.1.required','false'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.1.tip','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.1.uid','\"6a3416e6-0690-45d1-9842-c24edcaebed5\"'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.1.userCondition','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.1.warning','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.1.width','100'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.2.elementCondition','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.2.fieldUid','\"27ec8eb2-b037-4427-b5de-ca356fb40a0e\"'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.2.instructions','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.2.label','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.2.required','false'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.2.tip','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.2.uid','\"f4ac93f6-026c-4b15-b4fc-105bf53db005\"'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.2.userCondition','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.2.warning','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.2.width','100'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.3.elementCondition','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.3.heading','\"Featured Projects\"'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\Heading\"'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.3.uid','\"229da3bd-1eea-4dcf-8a82-a69ccc4d7341\"'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.3.userCondition','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.4.elementCondition','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.4.fieldUid','\"24f1ca91-8849-41c2-b4d9-f7e335886226\"'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.4.instructions','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.4.label','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.4.required','false'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.4.tip','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.4.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.4.uid','\"533fa4f7-0a44-4cbe-950a-2eceacd17c15\"'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.4.userCondition','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.4.warning','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.elements.4.width','100'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.name','\"Content\"'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.uid','\"7b1df43c-1bba-435b-8d56-1b4260d2efb9\"'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.fieldLayouts.97500b3a-619a-4d4f-af86-29050380fc7a.tabs.0.userCondition','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.handle','\"home\"'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.hasTitleField','false'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.name','\"Home\"'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.section','\"d03399df-cbbc-4519-949d-ae47810ffc53\"'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.sortOrder','1'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.titleFormat','\"{section.name|raw}\"'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.titleTranslationKeyFormat','null'),('entryTypes.73166065-2347-470c-829f-bccaa41283d6.titleTranslationMethod','\"site\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elementCondition','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.0.elementCondition','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.0.heading','\"Page Details\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\Heading\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.0.uid','\"5551721a-1bec-43ef-841a-c760afad9d78\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.0.userCondition','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.1.autocapitalize','true'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.1.autocomplete','false'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.1.autocorrect','true'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.1.class','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.1.disabled','false'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.1.elementCondition','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.1.id','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.1.instructions','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.1.label','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.1.max','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.1.min','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.1.name','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.1.orientation','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.1.placeholder','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.1.readonly','false'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.1.requirable','false'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.1.size','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.1.step','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.1.tip','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.1.title','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.1.uid','\"b19f08b2-8a4b-461a-a934-462a9e84d874\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.1.userCondition','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.1.warning','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.1.width','75'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.10.elementCondition.class','\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.10.elementCondition.conditionRules.0.class','\"craft\\\\fields\\\\conditions\\\\LightswitchFieldConditionRule\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.10.elementCondition.conditionRules.0.fieldUid','\"fdee1828-1284-4336-bb56-c20cfc35bcb2\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.10.elementCondition.conditionRules.0.uid','\"e36416f0-87e0-4b75-aaea-939b6c1b8a19\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.10.elementCondition.conditionRules.0.value','true'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.10.elementCondition.elementType','\"craft\\\\elements\\\\Entry\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.10.elementCondition.fieldContext','\"global\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.10.heading','\"Gallery\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.10.type','\"craft\\\\fieldlayoutelements\\\\Heading\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.10.uid','\"ef1bd697-7654-4bc9-9389-caecab954496\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.10.userCondition','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.11.elementCondition.class','\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.11.elementCondition.conditionRules.0.class','\"craft\\\\fields\\\\conditions\\\\LightswitchFieldConditionRule\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.11.elementCondition.conditionRules.0.fieldUid','\"fdee1828-1284-4336-bb56-c20cfc35bcb2\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.11.elementCondition.conditionRules.0.uid','\"6a01dfe1-fdac-4818-ace4-f5f8edd550c2\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.11.elementCondition.conditionRules.0.value','true'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.11.elementCondition.elementType','\"craft\\\\elements\\\\Entry\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.11.elementCondition.fieldContext','\"global\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.11.fieldUid','\"7fdab846-07ae-4e4a-92b5-b9f6e827f4d6\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.11.instructions','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.11.label','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.11.required','true'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.11.tip','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.11.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.11.uid','\"b2c126d1-ae43-4110-a35f-ce70a8e67921\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.11.userCondition','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.11.warning','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.11.width','100'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.12.elementCondition.class','\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.12.elementCondition.conditionRules.0.class','\"craft\\\\fields\\\\conditions\\\\LightswitchFieldConditionRule\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.12.elementCondition.conditionRules.0.fieldUid','\"fdee1828-1284-4336-bb56-c20cfc35bcb2\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.12.elementCondition.conditionRules.0.uid','\"37e25f02-1bb2-4894-9033-5e9ccc75abff\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.12.elementCondition.conditionRules.0.value','true'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.12.elementCondition.elementType','\"craft\\\\elements\\\\Entry\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.12.elementCondition.fieldContext','\"global\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.12.heading','\"Page Content\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.12.type','\"craft\\\\fieldlayoutelements\\\\Heading\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.12.uid','\"c974e290-c38a-4023-8add-1ce72ca4e5f4\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.12.userCondition','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.13.elementCondition.class','\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.13.elementCondition.conditionRules.0.class','\"craft\\\\fields\\\\conditions\\\\LightswitchFieldConditionRule\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.13.elementCondition.conditionRules.0.fieldUid','\"fdee1828-1284-4336-bb56-c20cfc35bcb2\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.13.elementCondition.conditionRules.0.uid','\"971a2998-c48a-49ed-ba99-ea3ea06140e5\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.13.elementCondition.conditionRules.0.value','true'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.13.elementCondition.elementType','\"craft\\\\elements\\\\Entry\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.13.elementCondition.fieldContext','\"global\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.13.fieldUid','\"4bf00f78-4885-4b6b-a6a1-dd68fb6436a7\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.13.instructions','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.13.label','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.13.required','true'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.13.tip','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.13.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.13.uid','\"ca004975-21fa-41c1-aa4e-ad28bbe1fbdb\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.13.userCondition','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.13.warning','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.13.width','50'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.14.elementCondition.class','\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.14.elementCondition.conditionRules.0.class','\"craft\\\\fields\\\\conditions\\\\LightswitchFieldConditionRule\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.14.elementCondition.conditionRules.0.fieldUid','\"fdee1828-1284-4336-bb56-c20cfc35bcb2\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.14.elementCondition.conditionRules.0.uid','\"440d248c-cf97-492f-b2f8-6f0d7f8c0325\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.14.elementCondition.conditionRules.0.value','true'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.14.elementCondition.elementType','\"craft\\\\elements\\\\Entry\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.14.elementCondition.fieldContext','\"global\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.14.fieldUid','\"54a7cbee-951b-4828-8c0e-8c767689e521\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.14.instructions','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.14.label','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.14.required','false'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.14.tip','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.14.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.14.uid','\"f6891dda-2328-4be1-b3ea-623036237ad1\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.14.userCondition','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.14.warning','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.14.width','50'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.2.elementCondition','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.2.fieldUid','\"ec4cd1bd-750d-47d2-b69d-59faca0bd560\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.2.instructions','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.2.label','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.2.required','true'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.2.tip','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.2.uid','\"8fc32df9-5b6a-4601-9f63-6faaa280bc1d\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.2.userCondition','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.2.warning','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.2.width','25'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.3.elementCondition','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.3.fieldUid','\"fdee1828-1284-4336-bb56-c20cfc35bcb2\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.3.instructions','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.3.label','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.3.required','false'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.3.tip','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.3.uid','\"88ebddad-8a2b-4424-9ed0-5fb7f45ef0ab\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.3.userCondition','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.3.warning','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.3.width','50'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.4.elementCondition','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.4.fieldUid','\"3fdbbee9-c12e-40a5-b535-ea81e8c9a194\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.4.instructions','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.4.label','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.4.required','false'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.4.tip','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.4.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.4.uid','\"e5bfaaf4-3fd8-46e0-9906-626fbaa9fe3c\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.4.userCondition','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.4.warning','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.4.width','50'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.5.elementCondition','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.5.type','\"craft\\\\fieldlayoutelements\\\\HorizontalRule\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.5.uid','\"877394a3-aecb-463d-a6a3-744563db1d18\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.5.userCondition','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.6.elementCondition.class','\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.6.elementCondition.conditionRules.0.class','\"craft\\\\fields\\\\conditions\\\\LightswitchFieldConditionRule\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.6.elementCondition.conditionRules.0.fieldUid','\"fdee1828-1284-4336-bb56-c20cfc35bcb2\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.6.elementCondition.conditionRules.0.uid','\"01d30094-fb26-420a-a613-1358da28d539\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.6.elementCondition.conditionRules.0.value','true'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.6.elementCondition.elementType','\"craft\\\\elements\\\\Entry\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.6.elementCondition.fieldContext','\"global\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.6.fieldUid','\"dd481797-f29b-408b-8b8d-500817d78742\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.6.instructions','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.6.label','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.6.required','false'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.6.tip','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.6.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.6.uid','\"63aa172a-e6ad-4cff-854e-ab3495e2420d\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.6.userCondition','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.6.warning','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.6.width','25'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.7.elementCondition','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.7.fieldUid','\"c808777b-1863-4f28-b9ba-658f7420314c\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.7.instructions','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.7.label','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.7.required','true'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.7.tip','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.7.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.7.uid','\"e8c44410-e834-48dd-8320-d2e71fa4ded5\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.7.userCondition','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.7.warning','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.7.width','25'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.8.elementCondition','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.8.fieldUid','\"91633e6e-a0ba-4081-9b36-a6abc77465b9\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.8.instructions','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.8.label','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.8.required','true'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.8.tip','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.8.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.8.uid','\"4b252659-95b2-4d43-825e-d47c617a5c63\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.8.userCondition','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.8.warning','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.8.width','25'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.9.elementCondition','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.9.fieldUid','\"1e72ce05-01c8-4865-b077-e1f0e99627b9\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.9.instructions','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.9.label','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.9.required','true'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.9.tip','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.9.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.9.uid','\"39774ed1-3ccb-466e-9f91-b50fe844ad3f\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.9.userCondition','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.9.warning','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.elements.9.width','25'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.name','\"Content\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.uid','\"c9e2d2cf-c3c2-4078-ac7e-f7a628a6eea0\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.fieldLayouts.d0c95995-92a4-4ba2-a8c3-4ec8ac3f1e89.tabs.0.userCondition','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.handle','\"default\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.hasTitleField','true'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.name','\"Default\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.section','\"30b9b0ce-bf0d-4512-af8e-7bbe939a1a01\"'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.sortOrder','1'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.titleFormat','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.titleTranslationKeyFormat','null'),('entryTypes.a8ebc45c-68de-46be-b5d2-c648a0a99aac.titleTranslationMethod','\"site\"'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elementCondition','null'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.0.autocapitalize','true'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.0.autocomplete','false'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.0.autocorrect','true'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.0.class','null'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.0.disabled','false'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.0.elementCondition','null'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.0.id','null'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.0.instructions','null'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.0.label','null'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.0.max','null'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.0.min','null'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.0.name','null'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.0.orientation','null'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.0.placeholder','null'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.0.readonly','false'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.0.requirable','false'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.0.size','null'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.0.step','null'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.0.tip','null'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.0.title','null'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.0.uid','\"cc8bf54d-6a68-4395-9720-94b967c23338\"'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.0.userCondition','null'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.0.warning','null'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.0.width','100'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.1.elementCondition','null'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.1.fieldUid','\"27ec8eb2-b037-4427-b5de-ca356fb40a0e\"'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.1.instructions','null'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.1.label','null'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.1.required','false'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.1.tip','null'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.1.uid','\"3d74770c-ee96-443a-92f8-33f2d58828f1\"'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.1.userCondition','null'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.1.warning','null'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.elements.1.width','100'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.name','\"Content\"'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.uid','\"27d94266-965f-4feb-9507-56282b8c732b\"'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.fieldLayouts.585e3ff0-b259-4bd3-a484-771c24d9a1ac.tabs.0.userCondition','null'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.handle','\"referenzen\"'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.hasTitleField','false'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.name','\"Referenzen\"'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.section','\"790d7e4e-f6e4-4009-b190-43462c745601\"'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.sortOrder','1'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.titleFormat','\"{section.name|raw}\"'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.titleTranslationKeyFormat','null'),('entryTypes.ba6a7105-5890-449d-90b3-9ca3a98f7da4.titleTranslationMethod','\"site\"'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elementCondition','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.0.autocapitalize','true'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.0.autocomplete','false'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.0.autocorrect','true'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.0.class','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.0.disabled','false'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.0.elementCondition','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.0.id','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.0.instructions','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.0.label','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.0.max','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.0.min','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.0.name','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.0.orientation','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.0.placeholder','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.0.readonly','false'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.0.requirable','false'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.0.size','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.0.step','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.0.tip','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.0.title','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.0.uid','\"27703a8d-54f0-4c5d-a62f-b533abaf64ce\"'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.0.userCondition','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.0.warning','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.0.width','100'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.1.elementCondition','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.1.fieldUid','\"27ec8eb2-b037-4427-b5de-ca356fb40a0e\"'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.1.instructions','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.1.label','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.1.required','false'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.1.tip','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.1.uid','\"1ce724fe-b599-479a-8d32-a12b2b1a1118\"'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.1.userCondition','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.1.warning','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.1.width','100'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.2.elementCondition','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.2.type','\"craft\\\\fieldlayoutelements\\\\HorizontalRule\"'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.2.uid','\"32a3237d-d6ef-4087-b582-2ab6d808c237\"'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.2.userCondition','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.3.elementCondition','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.3.fieldUid','\"8228b035-fb8e-4491-9498-eaa57ee42747\"'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.3.instructions','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.3.label','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.3.required','false'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.3.tip','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.3.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.3.uid','\"e24b86f1-1538-4af6-9ca2-534c84649c72\"'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.3.userCondition','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.3.warning','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.3.width','100'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.4.elementCondition','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.4.type','\"craft\\\\fieldlayoutelements\\\\HorizontalRule\"'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.4.uid','\"822bbc0c-2280-41a4-b450-5a3f97755f3e\"'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.4.userCondition','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.5.elementCondition','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.5.fieldUid','\"57640f4c-484c-49c4-a3f4-ec8694c65d42\"'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.5.instructions','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.5.label','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.5.required','false'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.5.tip','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.5.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.5.uid','\"9f6212ba-897b-4f16-b10a-cf3f1af423c6\"'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.5.userCondition','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.5.warning','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.5.width','75'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.6.elementCondition','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.6.fieldUid','\"c7d8a886-679a-4d74-bf86-5cc1593c54b1\"'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.6.instructions','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.6.label','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.6.required','false'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.6.tip','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.6.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.6.uid','\"56860896-c2eb-47fd-9f69-5613fd50e0cf\"'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.6.userCondition','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.6.warning','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.6.width','75'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.7.elementCondition','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.7.fieldUid','\"ad9cc240-0c67-4bf1-ad59-183dacc2169f\"'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.7.instructions','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.7.label','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.7.required','false'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.7.tip','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.7.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.7.uid','\"f4eca14b-8cb2-40ca-97bb-1c680d0a7ac9\"'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.7.userCondition','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.7.warning','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.elements.7.width','75'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.name','\"Content\"'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.uid','\"c3babd3c-ae64-40ab-9c19-3fc1ce1bb16e\"'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.fieldLayouts.ff6bfcc2-1c6c-421a-819d-4e8a98f311a8.tabs.0.userCondition','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.handle','\"uberuns\"'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.hasTitleField','false'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.name','\"Uber Uns\"'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.section','\"297a7304-ea06-4bfa-ab70-ceb7e2f8793c\"'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.sortOrder','1'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.titleFormat','\"{section.name|raw}\"'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.titleTranslationKeyFormat','null'),('entryTypes.f39bc8ac-e071-427f-a24c-643bf9ecaa71.titleTranslationMethod','\"site\"'),('fieldGroups.0404121f-3b43-4edf-8f91-484cf9e22e05.name','\"Project Fields\"'),('fieldGroups.1ae40c53-c8eb-45dc-8e4d-9ed6f3ea6d28.name','\"Home Page\"'),('fieldGroups.23dde92c-c4a7-41f2-ac8c-edec5fb2c991.name','\"Common\"'),('fieldGroups.70fb5bd9-06ba-44bc-ac8e-4d97f1340d05.name','\"Team Fields\"'),('fieldGroups.c01637ae-da9f-438b-b94f-9eb66079f9b5.name','\"Archiv Fields\"'),('fields.086259da-3672-47af-a708-cf80ee82c01e.columnSuffix','\"exofsswa\"'),('fields.086259da-3672-47af-a708-cf80ee82c01e.contentColumnType','\"text\"'),('fields.086259da-3672-47af-a708-cf80ee82c01e.fieldGroup','\"23dde92c-c4a7-41f2-ac8c-edec5fb2c991\"'),('fields.086259da-3672-47af-a708-cf80ee82c01e.handle','\"marqueeText\"'),('fields.086259da-3672-47af-a708-cf80ee82c01e.instructions','\"This is shown in the green marquee on the top of the Home page\"'),('fields.086259da-3672-47af-a708-cf80ee82c01e.name','\"Marquee Text\"'),('fields.086259da-3672-47af-a708-cf80ee82c01e.searchable','false'),('fields.086259da-3672-47af-a708-cf80ee82c01e.settings.byteLimit','null'),('fields.086259da-3672-47af-a708-cf80ee82c01e.settings.charLimit','null'),('fields.086259da-3672-47af-a708-cf80ee82c01e.settings.code','false'),('fields.086259da-3672-47af-a708-cf80ee82c01e.settings.columnType','null'),('fields.086259da-3672-47af-a708-cf80ee82c01e.settings.initialRows','4'),('fields.086259da-3672-47af-a708-cf80ee82c01e.settings.multiline','false'),('fields.086259da-3672-47af-a708-cf80ee82c01e.settings.placeholder','null'),('fields.086259da-3672-47af-a708-cf80ee82c01e.settings.uiMode','\"normal\"'),('fields.086259da-3672-47af-a708-cf80ee82c01e.translationKeyFormat','null'),('fields.086259da-3672-47af-a708-cf80ee82c01e.translationMethod','\"none\"'),('fields.086259da-3672-47af-a708-cf80ee82c01e.type','\"craft\\\\fields\\\\PlainText\"'),('fields.1e72ce05-01c8-4865-b077-e1f0e99627b9.columnSuffix','\"gnmzlvwh\"'),('fields.1e72ce05-01c8-4865-b077-e1f0e99627b9.contentColumnType','\"text\"'),('fields.1e72ce05-01c8-4865-b077-e1f0e99627b9.fieldGroup','\"0404121f-3b43-4edf-8f91-484cf9e22e05\"'),('fields.1e72ce05-01c8-4865-b077-e1f0e99627b9.handle','\"projectZeitdauer\"'),('fields.1e72ce05-01c8-4865-b077-e1f0e99627b9.instructions','null'),('fields.1e72ce05-01c8-4865-b077-e1f0e99627b9.name','\"Project Zeitdauer\"'),('fields.1e72ce05-01c8-4865-b077-e1f0e99627b9.searchable','false'),('fields.1e72ce05-01c8-4865-b077-e1f0e99627b9.settings.byteLimit','null'),('fields.1e72ce05-01c8-4865-b077-e1f0e99627b9.settings.charLimit','null'),('fields.1e72ce05-01c8-4865-b077-e1f0e99627b9.settings.code','false'),('fields.1e72ce05-01c8-4865-b077-e1f0e99627b9.settings.columnType','null'),('fields.1e72ce05-01c8-4865-b077-e1f0e99627b9.settings.initialRows','4'),('fields.1e72ce05-01c8-4865-b077-e1f0e99627b9.settings.multiline','false'),('fields.1e72ce05-01c8-4865-b077-e1f0e99627b9.settings.placeholder','null'),('fields.1e72ce05-01c8-4865-b077-e1f0e99627b9.settings.uiMode','\"normal\"'),('fields.1e72ce05-01c8-4865-b077-e1f0e99627b9.translationKeyFormat','null'),('fields.1e72ce05-01c8-4865-b077-e1f0e99627b9.translationMethod','\"none\"'),('fields.1e72ce05-01c8-4865-b077-e1f0e99627b9.type','\"craft\\\\fields\\\\PlainText\"'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.columnSuffix','null'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.contentColumnType','\"string\"'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.fieldGroup','\"1ae40c53-c8eb-45dc-8e4d-9ed6f3ea6d28\"'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.handle','\"featuredProjects\"'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.instructions','\"Select Projects to be shown on home page\"'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.name','\"Featured Projects\"'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.searchable','false'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.settings.allowSelfRelations','false'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.settings.localizeRelations','false'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.settings.maxRelations','null'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.settings.minRelations','null'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.settings.selectionCondition.__assoc__.0.0','\"elementType\"'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.settings.selectionCondition.__assoc__.0.1','\"craft\\\\elements\\\\Entry\"'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.settings.selectionCondition.__assoc__.1.0','\"fieldContext\"'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.settings.selectionCondition.__assoc__.1.1','\"global\"'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.settings.selectionCondition.__assoc__.2.0','\"class\"'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.settings.selectionCondition.__assoc__.2.1','\"craft\\\\elements\\\\conditions\\\\entries\\\\EntryCondition\"'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.settings.selectionCondition.__assoc__.3.0','\"conditionRules\"'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.settings.selectionCondition.__assoc__.3.1.0.__assoc__.0.0','\"class\"'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.settings.selectionCondition.__assoc__.3.1.0.__assoc__.0.1','\"craft\\\\fields\\\\conditions\\\\RelationalFieldConditionRule\"'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.settings.selectionCondition.__assoc__.3.1.0.__assoc__.1.0','\"uid\"'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.settings.selectionCondition.__assoc__.3.1.0.__assoc__.1.1','\"2549b14b-4420-49f1-802b-09bebfdd841b\"'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.settings.selectionCondition.__assoc__.3.1.0.__assoc__.2.0','\"operator\"'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.settings.selectionCondition.__assoc__.3.1.0.__assoc__.2.1','\"notempty\"'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.settings.selectionCondition.__assoc__.3.1.0.__assoc__.4.0','\"fieldUid\"'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.settings.selectionCondition.__assoc__.3.1.0.__assoc__.4.1','\"7fdab846-07ae-4e4a-92b5-b9f6e827f4d6\"'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.settings.selectionLabel','null'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.settings.showSiteMenu','false'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.settings.source','null'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.settings.sources.0','\"section:30b9b0ce-bf0d-4512-af8e-7bbe939a1a01\"'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.settings.targetSiteId','null'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.settings.validateRelatedElements','false'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.settings.viewMode','null'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.translationKeyFormat','null'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.translationMethod','\"site\"'),('fields.24f1ca91-8849-41c2-b4d9-f7e335886226.type','\"craft\\\\fields\\\\Entries\"'),('fields.27ec8eb2-b037-4427-b5de-ca356fb40a0e.columnSuffix','\"xdbaxwyo\"'),('fields.27ec8eb2-b037-4427-b5de-ca356fb40a0e.contentColumnType','\"text\"'),('fields.27ec8eb2-b037-4427-b5de-ca356fb40a0e.fieldGroup','\"23dde92c-c4a7-41f2-ac8c-edec5fb2c991\"'),('fields.27ec8eb2-b037-4427-b5de-ca356fb40a0e.handle','\"pageText\"'),('fields.27ec8eb2-b037-4427-b5de-ca356fb40a0e.instructions','\"This is the large text shown on the top of the page.\"'),('fields.27ec8eb2-b037-4427-b5de-ca356fb40a0e.name','\"Page Text\"'),('fields.27ec8eb2-b037-4427-b5de-ca356fb40a0e.searchable','false'),('fields.27ec8eb2-b037-4427-b5de-ca356fb40a0e.settings.byteLimit','null'),('fields.27ec8eb2-b037-4427-b5de-ca356fb40a0e.settings.charLimit','null'),('fields.27ec8eb2-b037-4427-b5de-ca356fb40a0e.settings.code','false'),('fields.27ec8eb2-b037-4427-b5de-ca356fb40a0e.settings.columnType','null'),('fields.27ec8eb2-b037-4427-b5de-ca356fb40a0e.settings.initialRows','4'),('fields.27ec8eb2-b037-4427-b5de-ca356fb40a0e.settings.multiline','true'),('fields.27ec8eb2-b037-4427-b5de-ca356fb40a0e.settings.placeholder','null'),('fields.27ec8eb2-b037-4427-b5de-ca356fb40a0e.settings.uiMode','\"normal\"'),('fields.27ec8eb2-b037-4427-b5de-ca356fb40a0e.translationKeyFormat','null'),('fields.27ec8eb2-b037-4427-b5de-ca356fb40a0e.translationMethod','\"none\"'),('fields.27ec8eb2-b037-4427-b5de-ca356fb40a0e.type','\"craft\\\\fields\\\\PlainText\"'),('fields.3fdbbee9-c12e-40a5-b535-ea81e8c9a194.columnSuffix','\"zdyxjjfg\"'),('fields.3fdbbee9-c12e-40a5-b535-ea81e8c9a194.contentColumnType','\"boolean\"'),('fields.3fdbbee9-c12e-40a5-b535-ea81e8c9a194.fieldGroup','\"0404121f-3b43-4edf-8f91-484cf9e22e05\"'),('fields.3fdbbee9-c12e-40a5-b535-ea81e8c9a194.handle','\"actuelleProject\"'),('fields.3fdbbee9-c12e-40a5-b535-ea81e8c9a194.instructions','null'),('fields.3fdbbee9-c12e-40a5-b535-ea81e8c9a194.name','\"Actuelle Project\"'),('fields.3fdbbee9-c12e-40a5-b535-ea81e8c9a194.searchable','false'),('fields.3fdbbee9-c12e-40a5-b535-ea81e8c9a194.settings.default','false'),('fields.3fdbbee9-c12e-40a5-b535-ea81e8c9a194.settings.offLabel','null'),('fields.3fdbbee9-c12e-40a5-b535-ea81e8c9a194.settings.onLabel','null'),('fields.3fdbbee9-c12e-40a5-b535-ea81e8c9a194.translationKeyFormat','null'),('fields.3fdbbee9-c12e-40a5-b535-ea81e8c9a194.translationMethod','\"none\"'),('fields.3fdbbee9-c12e-40a5-b535-ea81e8c9a194.type','\"craft\\\\fields\\\\Lightswitch\"'),('fields.4bf00f78-4885-4b6b-a6a1-dd68fb6436a7.columnSuffix','\"zqsmmabq\"'),('fields.4bf00f78-4885-4b6b-a6a1-dd68fb6436a7.contentColumnType','\"text\"'),('fields.4bf00f78-4885-4b6b-a6a1-dd68fb6436a7.fieldGroup','\"0404121f-3b43-4edf-8f91-484cf9e22e05\"'),('fields.4bf00f78-4885-4b6b-a6a1-dd68fb6436a7.handle','\"projectDetails\"'),('fields.4bf00f78-4885-4b6b-a6a1-dd68fb6436a7.instructions','\"Bauherrschaft, Erstellungszeit, etc\"'),('fields.4bf00f78-4885-4b6b-a6a1-dd68fb6436a7.name','\"Project Details\"'),('fields.4bf00f78-4885-4b6b-a6a1-dd68fb6436a7.searchable','false'),('fields.4bf00f78-4885-4b6b-a6a1-dd68fb6436a7.settings.availableTransforms','\"*\"'),('fields.4bf00f78-4885-4b6b-a6a1-dd68fb6436a7.settings.availableVolumes','\"*\"'),('fields.4bf00f78-4885-4b6b-a6a1-dd68fb6436a7.settings.columnType','\"text\"'),('fields.4bf00f78-4885-4b6b-a6a1-dd68fb6436a7.settings.configSelectionMode','\"choose\"'),('fields.4bf00f78-4885-4b6b-a6a1-dd68fb6436a7.settings.defaultTransform','\"\"'),('fields.4bf00f78-4885-4b6b-a6a1-dd68fb6436a7.settings.manualConfig','\"\"'),('fields.4bf00f78-4885-4b6b-a6a1-dd68fb6436a7.settings.purifierConfig','null'),('fields.4bf00f78-4885-4b6b-a6a1-dd68fb6436a7.settings.purifyHtml','true'),('fields.4bf00f78-4885-4b6b-a6a1-dd68fb6436a7.settings.redactorConfig','\"Simple.json\"'),('fields.4bf00f78-4885-4b6b-a6a1-dd68fb6436a7.settings.removeEmptyTags','false'),('fields.4bf00f78-4885-4b6b-a6a1-dd68fb6436a7.settings.removeInlineStyles','false'),('fields.4bf00f78-4885-4b6b-a6a1-dd68fb6436a7.settings.removeNbsp','false'),('fields.4bf00f78-4885-4b6b-a6a1-dd68fb6436a7.settings.showHtmlButtonForNonAdmins','false'),('fields.4bf00f78-4885-4b6b-a6a1-dd68fb6436a7.settings.showUnpermittedFiles','false'),('fields.4bf00f78-4885-4b6b-a6a1-dd68fb6436a7.settings.showUnpermittedVolumes','false'),('fields.4bf00f78-4885-4b6b-a6a1-dd68fb6436a7.settings.uiMode','\"enlarged\"'),('fields.4bf00f78-4885-4b6b-a6a1-dd68fb6436a7.translationKeyFormat','null'),('fields.4bf00f78-4885-4b6b-a6a1-dd68fb6436a7.translationMethod','\"none\"'),('fields.4bf00f78-4885-4b6b-a6a1-dd68fb6436a7.type','\"craft\\\\redactor\\\\Field\"'),('fields.54a7cbee-951b-4828-8c0e-8c767689e521.columnSuffix','\"rgnrudxv\"'),('fields.54a7cbee-951b-4828-8c0e-8c767689e521.contentColumnType','\"text\"'),('fields.54a7cbee-951b-4828-8c0e-8c767689e521.fieldGroup','\"0404121f-3b43-4edf-8f91-484cf9e22e05\"'),('fields.54a7cbee-951b-4828-8c0e-8c767689e521.handle','\"projectTextContent\"'),('fields.54a7cbee-951b-4828-8c0e-8c767689e521.instructions','\"This is where the project description will be put\"'),('fields.54a7cbee-951b-4828-8c0e-8c767689e521.name','\"Project Text Content\"'),('fields.54a7cbee-951b-4828-8c0e-8c767689e521.searchable','false'),('fields.54a7cbee-951b-4828-8c0e-8c767689e521.settings.availableTransforms','\"*\"'),('fields.54a7cbee-951b-4828-8c0e-8c767689e521.settings.availableVolumes','\"*\"'),('fields.54a7cbee-951b-4828-8c0e-8c767689e521.settings.columnType','\"text\"'),('fields.54a7cbee-951b-4828-8c0e-8c767689e521.settings.configSelectionMode','\"choose\"'),('fields.54a7cbee-951b-4828-8c0e-8c767689e521.settings.defaultTransform','\"\"'),('fields.54a7cbee-951b-4828-8c0e-8c767689e521.settings.manualConfig','\"\"'),('fields.54a7cbee-951b-4828-8c0e-8c767689e521.settings.purifierConfig','null'),('fields.54a7cbee-951b-4828-8c0e-8c767689e521.settings.purifyHtml','true'),('fields.54a7cbee-951b-4828-8c0e-8c767689e521.settings.redactorConfig','\"Simple.json\"'),('fields.54a7cbee-951b-4828-8c0e-8c767689e521.settings.removeEmptyTags','false'),('fields.54a7cbee-951b-4828-8c0e-8c767689e521.settings.removeInlineStyles','false'),('fields.54a7cbee-951b-4828-8c0e-8c767689e521.settings.removeNbsp','false'),('fields.54a7cbee-951b-4828-8c0e-8c767689e521.settings.showHtmlButtonForNonAdmins','false'),('fields.54a7cbee-951b-4828-8c0e-8c767689e521.settings.showUnpermittedFiles','false'),('fields.54a7cbee-951b-4828-8c0e-8c767689e521.settings.showUnpermittedVolumes','false'),('fields.54a7cbee-951b-4828-8c0e-8c767689e521.settings.uiMode','\"normal\"'),('fields.54a7cbee-951b-4828-8c0e-8c767689e521.translationKeyFormat','null'),('fields.54a7cbee-951b-4828-8c0e-8c767689e521.translationMethod','\"none\"'),('fields.54a7cbee-951b-4828-8c0e-8c767689e521.type','\"craft\\\\redactor\\\\Field\"'),('fields.57640f4c-484c-49c4-a3f4-ec8694c65d42.columnSuffix','\"ipwofvgv\"'),('fields.57640f4c-484c-49c4-a3f4-ec8694c65d42.contentColumnType','\"text\"'),('fields.57640f4c-484c-49c4-a3f4-ec8694c65d42.fieldGroup','\"70fb5bd9-06ba-44bc-ac8e-4d97f1340d05\"'),('fields.57640f4c-484c-49c4-a3f4-ec8694c65d42.handle','\"businessDetails\"'),('fields.57640f4c-484c-49c4-a3f4-ec8694c65d42.instructions','\"Caretta + Gitz AG\\t\\t\\t\\r\\nBaumanagement \\t\\t\\t\\t\\r\\nGesamtplanung\"'),('fields.57640f4c-484c-49c4-a3f4-ec8694c65d42.name','\"Business Details\"'),('fields.57640f4c-484c-49c4-a3f4-ec8694c65d42.searchable','false'),('fields.57640f4c-484c-49c4-a3f4-ec8694c65d42.settings.availableTransforms','\"*\"'),('fields.57640f4c-484c-49c4-a3f4-ec8694c65d42.settings.availableVolumes','\"*\"'),('fields.57640f4c-484c-49c4-a3f4-ec8694c65d42.settings.columnType','\"text\"'),('fields.57640f4c-484c-49c4-a3f4-ec8694c65d42.settings.configSelectionMode','\"choose\"'),('fields.57640f4c-484c-49c4-a3f4-ec8694c65d42.settings.defaultTransform','\"\"'),('fields.57640f4c-484c-49c4-a3f4-ec8694c65d42.settings.manualConfig','\"\"'),('fields.57640f4c-484c-49c4-a3f4-ec8694c65d42.settings.purifierConfig','null'),('fields.57640f4c-484c-49c4-a3f4-ec8694c65d42.settings.purifyHtml','true'),('fields.57640f4c-484c-49c4-a3f4-ec8694c65d42.settings.redactorConfig','\"Simple.json\"'),('fields.57640f4c-484c-49c4-a3f4-ec8694c65d42.settings.removeEmptyTags','false'),('fields.57640f4c-484c-49c4-a3f4-ec8694c65d42.settings.removeInlineStyles','false'),('fields.57640f4c-484c-49c4-a3f4-ec8694c65d42.settings.removeNbsp','false'),('fields.57640f4c-484c-49c4-a3f4-ec8694c65d42.settings.showHtmlButtonForNonAdmins','false'),('fields.57640f4c-484c-49c4-a3f4-ec8694c65d42.settings.showUnpermittedFiles','false'),('fields.57640f4c-484c-49c4-a3f4-ec8694c65d42.settings.showUnpermittedVolumes','false'),('fields.57640f4c-484c-49c4-a3f4-ec8694c65d42.settings.uiMode','\"enlarged\"'),('fields.57640f4c-484c-49c4-a3f4-ec8694c65d42.translationKeyFormat','null'),('fields.57640f4c-484c-49c4-a3f4-ec8694c65d42.translationMethod','\"none\"'),('fields.57640f4c-484c-49c4-a3f4-ec8694c65d42.type','\"craft\\\\redactor\\\\Field\"'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.columnSuffix','null'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.contentColumnType','\"string\"'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.fieldGroup','\"0404121f-3b43-4edf-8f91-484cf9e22e05\"'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.handle','\"projectGallery\"'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.instructions','null'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.name','\"Project Gallery\"'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.searchable','false'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.settings.allowedKinds','null'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.settings.allowSelfRelations','false'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.settings.allowSubfolders','false'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.settings.allowUploads','true'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.settings.defaultUploadLocationSource','\"volume:8427f64a-7a41-4982-9210-df04b8400923\"'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.settings.defaultUploadLocationSubpath','null'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.settings.localizeRelations','false'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.settings.maxRelations','null'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.settings.minRelations','0'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.settings.previewMode','\"full\"'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.settings.restrictedDefaultUploadSubpath','null'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.settings.restrictedLocationSource','\"volume:8427f64a-7a41-4982-9210-df04b8400923\"'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.settings.restrictedLocationSubpath','null'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.settings.restrictFiles','false'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.settings.restrictLocation','true'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.settings.selectionCondition.__assoc__.0.0','\"elementType\"'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.settings.selectionCondition.__assoc__.0.1','\"craft\\\\elements\\\\Asset\"'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.settings.selectionCondition.__assoc__.1.0','\"fieldContext\"'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.settings.selectionCondition.__assoc__.1.1','\"global\"'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.settings.selectionCondition.__assoc__.2.0','\"class\"'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.settings.selectionCondition.__assoc__.2.1','\"craft\\\\elements\\\\conditions\\\\assets\\\\AssetCondition\"'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.settings.selectionLabel','\"Add Image\"'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.settings.showSiteMenu','false'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.settings.showUnpermittedFiles','false'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.settings.showUnpermittedVolumes','false'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.settings.source','null'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.settings.sources','\"*\"'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.settings.targetSiteId','null'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.settings.validateRelatedElements','false'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.settings.viewMode','\"list\"'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.translationKeyFormat','null'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.translationMethod','\"site\"'),('fields.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6.type','\"craft\\\\fields\\\\Assets\"'),('fields.8228b035-fb8e-4491-9498-eaa57ee42747.columnSuffix','null'),('fields.8228b035-fb8e-4491-9498-eaa57ee42747.contentColumnType','\"string\"'),('fields.8228b035-fb8e-4491-9498-eaa57ee42747.fieldGroup','\"70fb5bd9-06ba-44bc-ac8e-4d97f1340d05\"'),('fields.8228b035-fb8e-4491-9498-eaa57ee42747.handle','\"teamMembers\"'),('fields.8228b035-fb8e-4491-9498-eaa57ee42747.instructions','null'),('fields.8228b035-fb8e-4491-9498-eaa57ee42747.name','\"Team Members\"'),('fields.8228b035-fb8e-4491-9498-eaa57ee42747.searchable','false'),('fields.8228b035-fb8e-4491-9498-eaa57ee42747.settings.blockTypeFields','0'),('fields.8228b035-fb8e-4491-9498-eaa57ee42747.settings.changedFieldIndicator','285505308'),('fields.8228b035-fb8e-4491-9498-eaa57ee42747.settings.columns.__assoc__.0.0','\"c899eea5-625d-430a-af64-94c6c79c05dc\"'),('fields.8228b035-fb8e-4491-9498-eaa57ee42747.settings.columns.__assoc__.0.1.__assoc__.0.0','\"width\"'),('fields.8228b035-fb8e-4491-9498-eaa57ee42747.settings.columns.__assoc__.0.1.__assoc__.0.1','\"49%\"'),('fields.8228b035-fb8e-4491-9498-eaa57ee42747.settings.columns.__assoc__.1.0','\"e92950dd-e385-4421-905f-63fab21d1afc\"'),('fields.8228b035-fb8e-4491-9498-eaa57ee42747.settings.columns.__assoc__.1.1.__assoc__.0.0','\"width\"'),('fields.8228b035-fb8e-4491-9498-eaa57ee42747.settings.columns.__assoc__.1.1.__assoc__.0.1','\"49%\"'),('fields.8228b035-fb8e-4491-9498-eaa57ee42747.settings.contentTable','\"{{%stc_teammembers}}\"'),('fields.8228b035-fb8e-4491-9498-eaa57ee42747.settings.fieldLayout','\"matrix\"'),('fields.8228b035-fb8e-4491-9498-eaa57ee42747.settings.maxRows','null'),('fields.8228b035-fb8e-4491-9498-eaa57ee42747.settings.minRows','null'),('fields.8228b035-fb8e-4491-9498-eaa57ee42747.settings.propagationKeyFormat','null'),('fields.8228b035-fb8e-4491-9498-eaa57ee42747.settings.propagationMethod','\"all\"'),('fields.8228b035-fb8e-4491-9498-eaa57ee42747.settings.selectionLabel','null'),('fields.8228b035-fb8e-4491-9498-eaa57ee42747.settings.staticField','null'),('fields.8228b035-fb8e-4491-9498-eaa57ee42747.translationKeyFormat','null'),('fields.8228b035-fb8e-4491-9498-eaa57ee42747.translationMethod','\"site\"'),('fields.8228b035-fb8e-4491-9498-eaa57ee42747.type','\"verbb\\\\supertable\\\\fields\\\\SuperTableField\"'),('fields.91633e6e-a0ba-4081-9b36-a6abc77465b9.columnSuffix','\"mnehzyjd\"'),('fields.91633e6e-a0ba-4081-9b36-a6abc77465b9.contentColumnType','\"text\"'),('fields.91633e6e-a0ba-4081-9b36-a6abc77465b9.fieldGroup','\"0404121f-3b43-4edf-8f91-484cf9e22e05\"'),('fields.91633e6e-a0ba-4081-9b36-a6abc77465b9.handle','\"projectBauherrschaft\"'),('fields.91633e6e-a0ba-4081-9b36-a6abc77465b9.instructions','null'),('fields.91633e6e-a0ba-4081-9b36-a6abc77465b9.name','\"Project Bauherrschaft\"'),('fields.91633e6e-a0ba-4081-9b36-a6abc77465b9.searchable','false'),('fields.91633e6e-a0ba-4081-9b36-a6abc77465b9.settings.byteLimit','null'),('fields.91633e6e-a0ba-4081-9b36-a6abc77465b9.settings.charLimit','null'),('fields.91633e6e-a0ba-4081-9b36-a6abc77465b9.settings.code','false'),('fields.91633e6e-a0ba-4081-9b36-a6abc77465b9.settings.columnType','null'),('fields.91633e6e-a0ba-4081-9b36-a6abc77465b9.settings.initialRows','4'),('fields.91633e6e-a0ba-4081-9b36-a6abc77465b9.settings.multiline','false'),('fields.91633e6e-a0ba-4081-9b36-a6abc77465b9.settings.placeholder','null'),('fields.91633e6e-a0ba-4081-9b36-a6abc77465b9.settings.uiMode','\"normal\"'),('fields.91633e6e-a0ba-4081-9b36-a6abc77465b9.translationKeyFormat','null'),('fields.91633e6e-a0ba-4081-9b36-a6abc77465b9.translationMethod','\"none\"'),('fields.91633e6e-a0ba-4081-9b36-a6abc77465b9.type','\"craft\\\\fields\\\\PlainText\"'),('fields.ad9cc240-0c67-4bf1-ad59-183dacc2169f.columnSuffix','\"eyxrfojc\"'),('fields.ad9cc240-0c67-4bf1-ad59-183dacc2169f.contentColumnType','\"text\"'),('fields.ad9cc240-0c67-4bf1-ad59-183dacc2169f.fieldGroup','\"70fb5bd9-06ba-44bc-ac8e-4d97f1340d05\"'),('fields.ad9cc240-0c67-4bf1-ad59-183dacc2169f.handle','\"businessContact\"'),('fields.ad9cc240-0c67-4bf1-ad59-183dacc2169f.instructions','\"Telefon: 043 222 31 80\\r\\nTelefax: 043 222 31 81\\r\\ninfo@caretta-gitz.ch\"'),('fields.ad9cc240-0c67-4bf1-ad59-183dacc2169f.name','\"Business Contact\"'),('fields.ad9cc240-0c67-4bf1-ad59-183dacc2169f.searchable','false'),('fields.ad9cc240-0c67-4bf1-ad59-183dacc2169f.settings.availableTransforms','\"*\"'),('fields.ad9cc240-0c67-4bf1-ad59-183dacc2169f.settings.availableVolumes','\"*\"'),('fields.ad9cc240-0c67-4bf1-ad59-183dacc2169f.settings.columnType','\"text\"'),('fields.ad9cc240-0c67-4bf1-ad59-183dacc2169f.settings.configSelectionMode','\"choose\"'),('fields.ad9cc240-0c67-4bf1-ad59-183dacc2169f.settings.defaultTransform','\"\"'),('fields.ad9cc240-0c67-4bf1-ad59-183dacc2169f.settings.manualConfig','\"\"'),('fields.ad9cc240-0c67-4bf1-ad59-183dacc2169f.settings.purifierConfig','null'),('fields.ad9cc240-0c67-4bf1-ad59-183dacc2169f.settings.purifyHtml','true'),('fields.ad9cc240-0c67-4bf1-ad59-183dacc2169f.settings.redactorConfig','\"Simple.json\"'),('fields.ad9cc240-0c67-4bf1-ad59-183dacc2169f.settings.removeEmptyTags','false'),('fields.ad9cc240-0c67-4bf1-ad59-183dacc2169f.settings.removeInlineStyles','false'),('fields.ad9cc240-0c67-4bf1-ad59-183dacc2169f.settings.removeNbsp','false'),('fields.ad9cc240-0c67-4bf1-ad59-183dacc2169f.settings.showHtmlButtonForNonAdmins','false'),('fields.ad9cc240-0c67-4bf1-ad59-183dacc2169f.settings.showUnpermittedFiles','false'),('fields.ad9cc240-0c67-4bf1-ad59-183dacc2169f.settings.showUnpermittedVolumes','false'),('fields.ad9cc240-0c67-4bf1-ad59-183dacc2169f.settings.uiMode','\"enlarged\"'),('fields.ad9cc240-0c67-4bf1-ad59-183dacc2169f.translationKeyFormat','null'),('fields.ad9cc240-0c67-4bf1-ad59-183dacc2169f.translationMethod','\"none\"'),('fields.ad9cc240-0c67-4bf1-ad59-183dacc2169f.type','\"craft\\\\redactor\\\\Field\"'),('fields.c7d8a886-679a-4d74-bf86-5cc1593c54b1.columnSuffix','\"umdvtzcr\"'),('fields.c7d8a886-679a-4d74-bf86-5cc1593c54b1.contentColumnType','\"text\"'),('fields.c7d8a886-679a-4d74-bf86-5cc1593c54b1.fieldGroup','\"70fb5bd9-06ba-44bc-ac8e-4d97f1340d05\"'),('fields.c7d8a886-679a-4d74-bf86-5cc1593c54b1.handle','\"businessAddress\"'),('fields.c7d8a886-679a-4d74-bf86-5cc1593c54b1.instructions','\"Seestrasse 96\\t\\r\\n8700 Küsnacht\"'),('fields.c7d8a886-679a-4d74-bf86-5cc1593c54b1.name','\"Business Address\"'),('fields.c7d8a886-679a-4d74-bf86-5cc1593c54b1.searchable','false'),('fields.c7d8a886-679a-4d74-bf86-5cc1593c54b1.settings.availableTransforms','\"*\"'),('fields.c7d8a886-679a-4d74-bf86-5cc1593c54b1.settings.availableVolumes','\"*\"'),('fields.c7d8a886-679a-4d74-bf86-5cc1593c54b1.settings.columnType','\"text\"'),('fields.c7d8a886-679a-4d74-bf86-5cc1593c54b1.settings.configSelectionMode','\"choose\"'),('fields.c7d8a886-679a-4d74-bf86-5cc1593c54b1.settings.defaultTransform','\"\"'),('fields.c7d8a886-679a-4d74-bf86-5cc1593c54b1.settings.manualConfig','\"\"'),('fields.c7d8a886-679a-4d74-bf86-5cc1593c54b1.settings.purifierConfig','null'),('fields.c7d8a886-679a-4d74-bf86-5cc1593c54b1.settings.purifyHtml','true'),('fields.c7d8a886-679a-4d74-bf86-5cc1593c54b1.settings.redactorConfig','\"Simple.json\"'),('fields.c7d8a886-679a-4d74-bf86-5cc1593c54b1.settings.removeEmptyTags','false'),('fields.c7d8a886-679a-4d74-bf86-5cc1593c54b1.settings.removeInlineStyles','false'),('fields.c7d8a886-679a-4d74-bf86-5cc1593c54b1.settings.removeNbsp','false'),('fields.c7d8a886-679a-4d74-bf86-5cc1593c54b1.settings.showHtmlButtonForNonAdmins','false'),('fields.c7d8a886-679a-4d74-bf86-5cc1593c54b1.settings.showUnpermittedFiles','false'),('fields.c7d8a886-679a-4d74-bf86-5cc1593c54b1.settings.showUnpermittedVolumes','false'),('fields.c7d8a886-679a-4d74-bf86-5cc1593c54b1.settings.uiMode','\"enlarged\"'),('fields.c7d8a886-679a-4d74-bf86-5cc1593c54b1.translationKeyFormat','null'),('fields.c7d8a886-679a-4d74-bf86-5cc1593c54b1.translationMethod','\"none\"'),('fields.c7d8a886-679a-4d74-bf86-5cc1593c54b1.type','\"craft\\\\redactor\\\\Field\"'),('fields.c808777b-1863-4f28-b9ba-658f7420314c.columnSuffix','\"pgchnaiv\"'),('fields.c808777b-1863-4f28-b9ba-658f7420314c.contentColumnType','\"text\"'),('fields.c808777b-1863-4f28-b9ba-658f7420314c.fieldGroup','\"0404121f-3b43-4edf-8f91-484cf9e22e05\"'),('fields.c808777b-1863-4f28-b9ba-658f7420314c.handle','\"projectArchitekt\"'),('fields.c808777b-1863-4f28-b9ba-658f7420314c.instructions','null'),('fields.c808777b-1863-4f28-b9ba-658f7420314c.name','\"Project Architekt\"'),('fields.c808777b-1863-4f28-b9ba-658f7420314c.searchable','false'),('fields.c808777b-1863-4f28-b9ba-658f7420314c.settings.byteLimit','null'),('fields.c808777b-1863-4f28-b9ba-658f7420314c.settings.charLimit','null'),('fields.c808777b-1863-4f28-b9ba-658f7420314c.settings.code','false'),('fields.c808777b-1863-4f28-b9ba-658f7420314c.settings.columnType','null'),('fields.c808777b-1863-4f28-b9ba-658f7420314c.settings.initialRows','4'),('fields.c808777b-1863-4f28-b9ba-658f7420314c.settings.multiline','false'),('fields.c808777b-1863-4f28-b9ba-658f7420314c.settings.placeholder','null'),('fields.c808777b-1863-4f28-b9ba-658f7420314c.settings.uiMode','\"normal\"'),('fields.c808777b-1863-4f28-b9ba-658f7420314c.translationKeyFormat','null'),('fields.c808777b-1863-4f28-b9ba-658f7420314c.translationMethod','\"none\"'),('fields.c808777b-1863-4f28-b9ba-658f7420314c.type','\"craft\\\\fields\\\\PlainText\"'),('fields.dd481797-f29b-408b-8b8d-500817d78742.columnSuffix','null'),('fields.dd481797-f29b-408b-8b8d-500817d78742.contentColumnType','\"string\"'),('fields.dd481797-f29b-408b-8b8d-500817d78742.fieldGroup','\"0404121f-3b43-4edf-8f91-484cf9e22e05\"'),('fields.dd481797-f29b-408b-8b8d-500817d78742.handle','\"projectBuildingType\"'),('fields.dd481797-f29b-408b-8b8d-500817d78742.instructions','null'),('fields.dd481797-f29b-408b-8b8d-500817d78742.name','\"Project Building Type\"'),('fields.dd481797-f29b-408b-8b8d-500817d78742.searchable','false'),('fields.dd481797-f29b-408b-8b8d-500817d78742.settings.allowLimit','false'),('fields.dd481797-f29b-408b-8b8d-500817d78742.settings.allowMultipleSources','false'),('fields.dd481797-f29b-408b-8b8d-500817d78742.settings.allowSelfRelations','false'),('fields.dd481797-f29b-408b-8b8d-500817d78742.settings.branchLimit','1'),('fields.dd481797-f29b-408b-8b8d-500817d78742.settings.localizeRelations','false'),('fields.dd481797-f29b-408b-8b8d-500817d78742.settings.maxRelations','null'),('fields.dd481797-f29b-408b-8b8d-500817d78742.settings.minRelations','null'),('fields.dd481797-f29b-408b-8b8d-500817d78742.settings.selectionLabel','null'),('fields.dd481797-f29b-408b-8b8d-500817d78742.settings.showSiteMenu','false'),('fields.dd481797-f29b-408b-8b8d-500817d78742.settings.source','\"group:90132f11-3bdb-456a-a01e-18653a2c7371\"'),('fields.dd481797-f29b-408b-8b8d-500817d78742.settings.sources','\"*\"'),('fields.dd481797-f29b-408b-8b8d-500817d78742.settings.targetSiteId','null'),('fields.dd481797-f29b-408b-8b8d-500817d78742.settings.validateRelatedElements','false'),('fields.dd481797-f29b-408b-8b8d-500817d78742.settings.viewMode','null'),('fields.dd481797-f29b-408b-8b8d-500817d78742.translationKeyFormat','null'),('fields.dd481797-f29b-408b-8b8d-500817d78742.translationMethod','\"site\"'),('fields.dd481797-f29b-408b-8b8d-500817d78742.type','\"craft\\\\fields\\\\Categories\"'),('fields.ec4cd1bd-750d-47d2-b69d-59faca0bd560.columnSuffix','\"bczznfzn\"'),('fields.ec4cd1bd-750d-47d2-b69d-59faca0bd560.contentColumnType','\"integer(10)\"'),('fields.ec4cd1bd-750d-47d2-b69d-59faca0bd560.fieldGroup','\"0404121f-3b43-4edf-8f91-484cf9e22e05\"'),('fields.ec4cd1bd-750d-47d2-b69d-59faca0bd560.handle','\"projectNumber\"'),('fields.ec4cd1bd-750d-47d2-b69d-59faca0bd560.instructions','\"ex: 2105 - the # will be added automatically\"'),('fields.ec4cd1bd-750d-47d2-b69d-59faca0bd560.name','\"Project Number\"'),('fields.ec4cd1bd-750d-47d2-b69d-59faca0bd560.searchable','false'),('fields.ec4cd1bd-750d-47d2-b69d-59faca0bd560.settings.decimals','0'),('fields.ec4cd1bd-750d-47d2-b69d-59faca0bd560.settings.defaultValue','null'),('fields.ec4cd1bd-750d-47d2-b69d-59faca0bd560.settings.max','null'),('fields.ec4cd1bd-750d-47d2-b69d-59faca0bd560.settings.min','0'),('fields.ec4cd1bd-750d-47d2-b69d-59faca0bd560.settings.prefix','null'),('fields.ec4cd1bd-750d-47d2-b69d-59faca0bd560.settings.previewCurrency','null'),('fields.ec4cd1bd-750d-47d2-b69d-59faca0bd560.settings.previewFormat','\"none\"'),('fields.ec4cd1bd-750d-47d2-b69d-59faca0bd560.settings.size','null'),('fields.ec4cd1bd-750d-47d2-b69d-59faca0bd560.settings.suffix','null'),('fields.ec4cd1bd-750d-47d2-b69d-59faca0bd560.translationKeyFormat','null'),('fields.ec4cd1bd-750d-47d2-b69d-59faca0bd560.translationMethod','\"none\"'),('fields.ec4cd1bd-750d-47d2-b69d-59faca0bd560.type','\"craft\\\\fields\\\\Number\"'),('fields.f0424f7b-3a3f-41b4-ba50-141dbb749a8e.columnSuffix','\"goanvaoh\"'),('fields.f0424f7b-3a3f-41b4-ba50-141dbb749a8e.contentColumnType','\"text\"'),('fields.f0424f7b-3a3f-41b4-ba50-141dbb749a8e.fieldGroup','\"c01637ae-da9f-438b-b94f-9eb66079f9b5\"'),('fields.f0424f7b-3a3f-41b4-ba50-141dbb749a8e.handle','\"actuelleProjectText\"'),('fields.f0424f7b-3a3f-41b4-ba50-141dbb749a8e.instructions','\"This text goes before the actuelle project section on the archiv page\"'),('fields.f0424f7b-3a3f-41b4-ba50-141dbb749a8e.name','\"Actuelle Project Text\"'),('fields.f0424f7b-3a3f-41b4-ba50-141dbb749a8e.searchable','false'),('fields.f0424f7b-3a3f-41b4-ba50-141dbb749a8e.settings.byteLimit','null'),('fields.f0424f7b-3a3f-41b4-ba50-141dbb749a8e.settings.charLimit','null'),('fields.f0424f7b-3a3f-41b4-ba50-141dbb749a8e.settings.code','false'),('fields.f0424f7b-3a3f-41b4-ba50-141dbb749a8e.settings.columnType','null'),('fields.f0424f7b-3a3f-41b4-ba50-141dbb749a8e.settings.initialRows','4'),('fields.f0424f7b-3a3f-41b4-ba50-141dbb749a8e.settings.multiline','true'),('fields.f0424f7b-3a3f-41b4-ba50-141dbb749a8e.settings.placeholder','null'),('fields.f0424f7b-3a3f-41b4-ba50-141dbb749a8e.settings.uiMode','\"normal\"'),('fields.f0424f7b-3a3f-41b4-ba50-141dbb749a8e.translationKeyFormat','null'),('fields.f0424f7b-3a3f-41b4-ba50-141dbb749a8e.translationMethod','\"none\"'),('fields.f0424f7b-3a3f-41b4-ba50-141dbb749a8e.type','\"craft\\\\fields\\\\PlainText\"'),('fields.fdee1828-1284-4336-bb56-c20cfc35bcb2.columnSuffix','\"khhktnju\"'),('fields.fdee1828-1284-4336-bb56-c20cfc35bcb2.contentColumnType','\"boolean\"'),('fields.fdee1828-1284-4336-bb56-c20cfc35bcb2.fieldGroup','\"0404121f-3b43-4edf-8f91-484cf9e22e05\"'),('fields.fdee1828-1284-4336-bb56-c20cfc35bcb2.handle','\"referenceProject\"'),('fields.fdee1828-1284-4336-bb56-c20cfc35bcb2.instructions','null'),('fields.fdee1828-1284-4336-bb56-c20cfc35bcb2.name','\"Reference Project\"'),('fields.fdee1828-1284-4336-bb56-c20cfc35bcb2.searchable','false'),('fields.fdee1828-1284-4336-bb56-c20cfc35bcb2.settings.default','false'),('fields.fdee1828-1284-4336-bb56-c20cfc35bcb2.settings.offLabel','\"Hidden\"'),('fields.fdee1828-1284-4336-bb56-c20cfc35bcb2.settings.onLabel','\"Shown\"'),('fields.fdee1828-1284-4336-bb56-c20cfc35bcb2.translationKeyFormat','null'),('fields.fdee1828-1284-4336-bb56-c20cfc35bcb2.translationMethod','\"none\"'),('fields.fdee1828-1284-4336-bb56-c20cfc35bcb2.type','\"craft\\\\fields\\\\Lightswitch\"'),('fs.project.hasUrls','true'),('fs.project.name','\"project\"'),('fs.project.settings.path','\"@webroot/images/project\"'),('fs.project.type','\"craft\\\\fs\\\\Local\"'),('fs.project.url','\"@web/images/project\"'),('fs.teamPhotos.hasUrls','true'),('fs.teamPhotos.name','\"team\"'),('fs.teamPhotos.settings.path','\"@webroot/images/team\"'),('fs.teamPhotos.type','\"craft\\\\fs\\\\Local\"'),('fs.teamPhotos.url','\"@web/images/team\"'),('imageTransforms.09ae9717-2b1a-45ee-aff1-34710fa649c1.format','null'),('imageTransforms.09ae9717-2b1a-45ee-aff1-34710fa649c1.handle','\"homeLowRes\"'),('imageTransforms.09ae9717-2b1a-45ee-aff1-34710fa649c1.height','1400'),('imageTransforms.09ae9717-2b1a-45ee-aff1-34710fa649c1.interlace','\"none\"'),('imageTransforms.09ae9717-2b1a-45ee-aff1-34710fa649c1.mode','\"crop\"'),('imageTransforms.09ae9717-2b1a-45ee-aff1-34710fa649c1.name','\"Home Low Res\"'),('imageTransforms.09ae9717-2b1a-45ee-aff1-34710fa649c1.position','\"center-center\"'),('imageTransforms.09ae9717-2b1a-45ee-aff1-34710fa649c1.quality','10'),('imageTransforms.09ae9717-2b1a-45ee-aff1-34710fa649c1.width','null'),('imageTransforms.30e76fa4-2995-473a-8120-166aafcb7e43.format','null'),('imageTransforms.30e76fa4-2995-473a-8120-166aafcb7e43.handle','\"aboutUs\"'),('imageTransforms.30e76fa4-2995-473a-8120-166aafcb7e43.height','1000'),('imageTransforms.30e76fa4-2995-473a-8120-166aafcb7e43.interlace','\"none\"'),('imageTransforms.30e76fa4-2995-473a-8120-166aafcb7e43.mode','\"crop\"'),('imageTransforms.30e76fa4-2995-473a-8120-166aafcb7e43.name','\"About Us\"'),('imageTransforms.30e76fa4-2995-473a-8120-166aafcb7e43.position','\"center-center\"'),('imageTransforms.30e76fa4-2995-473a-8120-166aafcb7e43.quality','82'),('imageTransforms.30e76fa4-2995-473a-8120-166aafcb7e43.width','null'),('imageTransforms.3aa103e0-9c7a-4938-9e99-b2cc95c894f6.format','null'),('imageTransforms.3aa103e0-9c7a-4938-9e99-b2cc95c894f6.handle','\"lowres\"'),('imageTransforms.3aa103e0-9c7a-4938-9e99-b2cc95c894f6.height','100'),('imageTransforms.3aa103e0-9c7a-4938-9e99-b2cc95c894f6.interlace','\"none\"'),('imageTransforms.3aa103e0-9c7a-4938-9e99-b2cc95c894f6.mode','\"crop\"'),('imageTransforms.3aa103e0-9c7a-4938-9e99-b2cc95c894f6.name','\"LowRes\"'),('imageTransforms.3aa103e0-9c7a-4938-9e99-b2cc95c894f6.position','\"center-center\"'),('imageTransforms.3aa103e0-9c7a-4938-9e99-b2cc95c894f6.quality','30'),('imageTransforms.3aa103e0-9c7a-4938-9e99-b2cc95c894f6.width','null'),('imageTransforms.6d028446-8fb7-40aa-b8c9-2262ba95b3c0.format','null'),('imageTransforms.6d028446-8fb7-40aa-b8c9-2262ba95b3c0.handle','\"homeImages\"'),('imageTransforms.6d028446-8fb7-40aa-b8c9-2262ba95b3c0.height','1400'),('imageTransforms.6d028446-8fb7-40aa-b8c9-2262ba95b3c0.interlace','\"none\"'),('imageTransforms.6d028446-8fb7-40aa-b8c9-2262ba95b3c0.mode','\"crop\"'),('imageTransforms.6d028446-8fb7-40aa-b8c9-2262ba95b3c0.name','\"Home Images\"'),('imageTransforms.6d028446-8fb7-40aa-b8c9-2262ba95b3c0.position','\"center-center\"'),('imageTransforms.6d028446-8fb7-40aa-b8c9-2262ba95b3c0.quality','null'),('imageTransforms.6d028446-8fb7-40aa-b8c9-2262ba95b3c0.width','null'),('imageTransforms.8e658642-a4e5-484c-920d-25db92a50da4.format','null'),('imageTransforms.8e658642-a4e5-484c-920d-25db92a50da4.handle','\"referenceImages\"'),('imageTransforms.8e658642-a4e5-484c-920d-25db92a50da4.height','800'),('imageTransforms.8e658642-a4e5-484c-920d-25db92a50da4.interlace','\"none\"'),('imageTransforms.8e658642-a4e5-484c-920d-25db92a50da4.mode','\"crop\"'),('imageTransforms.8e658642-a4e5-484c-920d-25db92a50da4.name','\"Reference Images\"'),('imageTransforms.8e658642-a4e5-484c-920d-25db92a50da4.position','\"center-center\"'),('imageTransforms.8e658642-a4e5-484c-920d-25db92a50da4.quality','null'),('imageTransforms.8e658642-a4e5-484c-920d-25db92a50da4.width','null'),('meta.__names__.0404121f-3b43-4edf-8f91-484cf9e22e05','\"Project Fields\"'),('meta.__names__.086259da-3672-47af-a708-cf80ee82c01e','\"Marquee Text\"'),('meta.__names__.09ae9717-2b1a-45ee-aff1-34710fa649c1','\"Home Low Res\"'),('meta.__names__.0b38a6f1-daaf-4fda-b567-2e966ecac3f5','\"C+G\"'),('meta.__names__.0e2e66d1-935a-4b1e-8360-06dcda59a613','\"Team Photos\"'),('meta.__names__.1ae40c53-c8eb-45dc-8e4d-9ed6f3ea6d28','\"Home Page\"'),('meta.__names__.1e72ce05-01c8-4865-b077-e1f0e99627b9','\"Project Zeitdauer\"'),('meta.__names__.23dde92c-c4a7-41f2-ac8c-edec5fb2c991','\"Common\"'),('meta.__names__.24f1ca91-8849-41c2-b4d9-f7e335886226','\"Featured Projects\"'),('meta.__names__.272d5a67-670b-4bfd-ba65-bbd133766256','\"Archiv\"'),('meta.__names__.27ec8eb2-b037-4427-b5de-ca356fb40a0e','\"Page Text\"'),('meta.__names__.297a7304-ea06-4bfa-ab70-ceb7e2f8793c','\"Uber Uns\"'),('meta.__names__.30b9b0ce-bf0d-4512-af8e-7bbe939a1a01','\"Projects\"'),('meta.__names__.30e76fa4-2995-473a-8120-166aafcb7e43','\"About Us\"'),('meta.__names__.3aa103e0-9c7a-4938-9e99-b2cc95c894f6','\"LowRes\"'),('meta.__names__.3fdbbee9-c12e-40a5-b535-ea81e8c9a194','\"Actuelle Project\"'),('meta.__names__.4bf00f78-4885-4b6b-a6a1-dd68fb6436a7','\"Project Details\"'),('meta.__names__.54a7cbee-951b-4828-8c0e-8c767689e521','\"Project Text Content\"'),('meta.__names__.57640f4c-484c-49c4-a3f4-ec8694c65d42','\"Business Details\"'),('meta.__names__.6d028446-8fb7-40aa-b8c9-2262ba95b3c0','\"Home Images\"'),('meta.__names__.70fb5bd9-06ba-44bc-ac8e-4d97f1340d05','\"Team Fields\"'),('meta.__names__.73166065-2347-470c-829f-bccaa41283d6','\"Home\"'),('meta.__names__.790d7e4e-f6e4-4009-b190-43462c745601','\"Referenzen\"'),('meta.__names__.7fdab846-07ae-4e4a-92b5-b9f6e827f4d6','\"Project Gallery\"'),('meta.__names__.8228b035-fb8e-4491-9498-eaa57ee42747','\"Team Members\"'),('meta.__names__.8427f64a-7a41-4982-9210-df04b8400923','\"Project Photos\"'),('meta.__names__.8e658642-a4e5-484c-920d-25db92a50da4','\"Reference Images\"'),('meta.__names__.90132f11-3bdb-456a-a01e-18653a2c7371','\"Building Type\"'),('meta.__names__.91633e6e-a0ba-4081-9b36-a6abc77465b9','\"Project Bauherrschaft\"'),('meta.__names__.a8ebc45c-68de-46be-b5d2-c648a0a99aac','\"Default\"'),('meta.__names__.ad9cc240-0c67-4bf1-ad59-183dacc2169f','\"Business Contact\"'),('meta.__names__.b373d66a-5a09-4164-a51a-bbbef0102a75','\"Archiv\"'),('meta.__names__.ba6a7105-5890-449d-90b3-9ca3a98f7da4','\"Referenzen\"'),('meta.__names__.c01637ae-da9f-438b-b94f-9eb66079f9b5','\"Archiv Fields\"'),('meta.__names__.c7d8a886-679a-4d74-bf86-5cc1593c54b1','\"Business Address\"'),('meta.__names__.c808777b-1863-4f28-b9ba-658f7420314c','\"Project Architekt\"'),('meta.__names__.c899eea5-625d-430a-af64-94c6c79c05dc','\"Name\"'),('meta.__names__.d03399df-cbbc-4519-949d-ae47810ffc53','\"Home\"'),('meta.__names__.dd481797-f29b-408b-8b8d-500817d78742','\"Project Building Type\"'),('meta.__names__.e92950dd-e385-4421-905f-63fab21d1afc','\"Photo\"'),('meta.__names__.ec4cd1bd-750d-47d2-b69d-59faca0bd560','\"Project Number\"'),('meta.__names__.f0424f7b-3a3f-41b4-ba50-141dbb749a8e','\"Actuelle Project Text\"'),('meta.__names__.f39bc8ac-e071-427f-a24c-643bf9ecaa71','\"Uber Uns\"'),('meta.__names__.f70b9a5b-18df-4c74-9883-5a97fbf5f7f4','\"BiteRate\"'),('meta.__names__.fdee1828-1284-4336-bb56-c20cfc35bcb2','\"Reference Project\"'),('plugins.assetrev.edition','\"standard\"'),('plugins.assetrev.enabled','true'),('plugins.assetrev.schemaVersion','\"1.0.0\"'),('plugins.blitz-recommendations.edition','\"standard\"'),('plugins.blitz-recommendations.enabled','true'),('plugins.blitz-recommendations.schemaVersion','\"2.1.0\"'),('plugins.environment-label.edition','\"standard\"'),('plugins.environment-label.enabled','true'),('plugins.environment-label.schemaVersion','\"1.0.0\"'),('plugins.feed-me.edition','\"standard\"'),('plugins.feed-me.enabled','true'),('plugins.feed-me.schemaVersion','\"4.4.0\"'),('plugins.position-fieldtype.edition','\"standard\"'),('plugins.position-fieldtype.enabled','true'),('plugins.position-fieldtype.schemaVersion','\"1.0.0\"'),('plugins.redactor.edition','\"standard\"'),('plugins.redactor.enabled','true'),('plugins.redactor.schemaVersion','\"2.3.0\"'),('plugins.super-table.edition','\"standard\"'),('plugins.super-table.enabled','true'),('plugins.super-table.schemaVersion','\"3.0.0\"'),('plugins.templatecomments.edition','\"standard\"'),('plugins.templatecomments.enabled','true'),('plugins.templatecomments.schemaVersion','\"1.0.0\"'),('plugins.typedlinkfield.edition','\"standard\"'),('plugins.typedlinkfield.enabled','true'),('plugins.typedlinkfield.schemaVersion','\"2.0.0\"'),('sections.297a7304-ea06-4bfa-ab70-ceb7e2f8793c.defaultPlacement','\"end\"'),('sections.297a7304-ea06-4bfa-ab70-ceb7e2f8793c.enableVersioning','true'),('sections.297a7304-ea06-4bfa-ab70-ceb7e2f8793c.handle','\"uberuns\"'),('sections.297a7304-ea06-4bfa-ab70-ceb7e2f8793c.name','\"Uber Uns\"'),('sections.297a7304-ea06-4bfa-ab70-ceb7e2f8793c.propagationMethod','\"all\"'),('sections.297a7304-ea06-4bfa-ab70-ceb7e2f8793c.siteSettings.f70b9a5b-18df-4c74-9883-5a97fbf5f7f4.enabledByDefault','true'),('sections.297a7304-ea06-4bfa-ab70-ceb7e2f8793c.siteSettings.f70b9a5b-18df-4c74-9883-5a97fbf5f7f4.hasUrls','true'),('sections.297a7304-ea06-4bfa-ab70-ceb7e2f8793c.siteSettings.f70b9a5b-18df-4c74-9883-5a97fbf5f7f4.template','null'),('sections.297a7304-ea06-4bfa-ab70-ceb7e2f8793c.siteSettings.f70b9a5b-18df-4c74-9883-5a97fbf5f7f4.uriFormat','\"uber-uns\"'),('sections.297a7304-ea06-4bfa-ab70-ceb7e2f8793c.type','\"single\"'),('sections.30b9b0ce-bf0d-4512-af8e-7bbe939a1a01.defaultPlacement','\"end\"'),('sections.30b9b0ce-bf0d-4512-af8e-7bbe939a1a01.enableVersioning','true'),('sections.30b9b0ce-bf0d-4512-af8e-7bbe939a1a01.handle','\"projects\"'),('sections.30b9b0ce-bf0d-4512-af8e-7bbe939a1a01.name','\"Projects\"'),('sections.30b9b0ce-bf0d-4512-af8e-7bbe939a1a01.propagationMethod','\"all\"'),('sections.30b9b0ce-bf0d-4512-af8e-7bbe939a1a01.siteSettings.f70b9a5b-18df-4c74-9883-5a97fbf5f7f4.enabledByDefault','true'),('sections.30b9b0ce-bf0d-4512-af8e-7bbe939a1a01.siteSettings.f70b9a5b-18df-4c74-9883-5a97fbf5f7f4.hasUrls','true'),('sections.30b9b0ce-bf0d-4512-af8e-7bbe939a1a01.siteSettings.f70b9a5b-18df-4c74-9883-5a97fbf5f7f4.template','null'),('sections.30b9b0ce-bf0d-4512-af8e-7bbe939a1a01.siteSettings.f70b9a5b-18df-4c74-9883-5a97fbf5f7f4.uriFormat','\"referenzen#{{slug}}\"'),('sections.30b9b0ce-bf0d-4512-af8e-7bbe939a1a01.type','\"channel\"'),('sections.790d7e4e-f6e4-4009-b190-43462c745601.defaultPlacement','\"end\"'),('sections.790d7e4e-f6e4-4009-b190-43462c745601.enableVersioning','true'),('sections.790d7e4e-f6e4-4009-b190-43462c745601.handle','\"referenzen\"'),('sections.790d7e4e-f6e4-4009-b190-43462c745601.name','\"Referenzen\"'),('sections.790d7e4e-f6e4-4009-b190-43462c745601.propagationMethod','\"all\"'),('sections.790d7e4e-f6e4-4009-b190-43462c745601.siteSettings.f70b9a5b-18df-4c74-9883-5a97fbf5f7f4.enabledByDefault','true'),('sections.790d7e4e-f6e4-4009-b190-43462c745601.siteSettings.f70b9a5b-18df-4c74-9883-5a97fbf5f7f4.hasUrls','true'),('sections.790d7e4e-f6e4-4009-b190-43462c745601.siteSettings.f70b9a5b-18df-4c74-9883-5a97fbf5f7f4.template','\"referenzen/_entry\"'),('sections.790d7e4e-f6e4-4009-b190-43462c745601.siteSettings.f70b9a5b-18df-4c74-9883-5a97fbf5f7f4.uriFormat','\"referenzen\"'),('sections.790d7e4e-f6e4-4009-b190-43462c745601.type','\"single\"'),('sections.b373d66a-5a09-4164-a51a-bbbef0102a75.defaultPlacement','\"end\"'),('sections.b373d66a-5a09-4164-a51a-bbbef0102a75.enableVersioning','true'),('sections.b373d66a-5a09-4164-a51a-bbbef0102a75.handle','\"archiv\"'),('sections.b373d66a-5a09-4164-a51a-bbbef0102a75.name','\"Archiv\"'),('sections.b373d66a-5a09-4164-a51a-bbbef0102a75.propagationMethod','\"all\"'),('sections.b373d66a-5a09-4164-a51a-bbbef0102a75.siteSettings.f70b9a5b-18df-4c74-9883-5a97fbf5f7f4.enabledByDefault','true'),('sections.b373d66a-5a09-4164-a51a-bbbef0102a75.siteSettings.f70b9a5b-18df-4c74-9883-5a97fbf5f7f4.hasUrls','true'),('sections.b373d66a-5a09-4164-a51a-bbbef0102a75.siteSettings.f70b9a5b-18df-4c74-9883-5a97fbf5f7f4.template','\"archiv/_entry\"'),('sections.b373d66a-5a09-4164-a51a-bbbef0102a75.siteSettings.f70b9a5b-18df-4c74-9883-5a97fbf5f7f4.uriFormat','\"archiv\"'),('sections.b373d66a-5a09-4164-a51a-bbbef0102a75.type','\"single\"'),('sections.d03399df-cbbc-4519-949d-ae47810ffc53.defaultPlacement','\"end\"'),('sections.d03399df-cbbc-4519-949d-ae47810ffc53.enableVersioning','true'),('sections.d03399df-cbbc-4519-949d-ae47810ffc53.handle','\"home\"'),('sections.d03399df-cbbc-4519-949d-ae47810ffc53.name','\"Home\"'),('sections.d03399df-cbbc-4519-949d-ae47810ffc53.propagationMethod','\"all\"'),('sections.d03399df-cbbc-4519-949d-ae47810ffc53.siteSettings.f70b9a5b-18df-4c74-9883-5a97fbf5f7f4.enabledByDefault','true'),('sections.d03399df-cbbc-4519-949d-ae47810ffc53.siteSettings.f70b9a5b-18df-4c74-9883-5a97fbf5f7f4.hasUrls','true'),('sections.d03399df-cbbc-4519-949d-ae47810ffc53.siteSettings.f70b9a5b-18df-4c74-9883-5a97fbf5f7f4.template','\"index.twig\"'),('sections.d03399df-cbbc-4519-949d-ae47810ffc53.siteSettings.f70b9a5b-18df-4c74-9883-5a97fbf5f7f4.uriFormat','\"__home__\"'),('sections.d03399df-cbbc-4519-949d-ae47810ffc53.type','\"single\"'),('siteGroups.0b38a6f1-daaf-4fda-b567-2e966ecac3f5.name','\"BiteRate\"'),('sites.f70b9a5b-18df-4c74-9883-5a97fbf5f7f4.baseUrl','\"$PRIMARY_SITE_URL\"'),('sites.f70b9a5b-18df-4c74-9883-5a97fbf5f7f4.enabled','true'),('sites.f70b9a5b-18df-4c74-9883-5a97fbf5f7f4.handle','\"default\"'),('sites.f70b9a5b-18df-4c74-9883-5a97fbf5f7f4.hasUrls','true'),('sites.f70b9a5b-18df-4c74-9883-5a97fbf5f7f4.language','\"en-US\"'),('sites.f70b9a5b-18df-4c74-9883-5a97fbf5f7f4.name','\"BiteRate\"'),('sites.f70b9a5b-18df-4c74-9883-5a97fbf5f7f4.primary','true'),('sites.f70b9a5b-18df-4c74-9883-5a97fbf5f7f4.siteGroup','\"0b38a6f1-daaf-4fda-b567-2e966ecac3f5\"'),('sites.f70b9a5b-18df-4c74-9883-5a97fbf5f7f4.sortOrder','1'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.field','\"8228b035-fb8e-4491-9498-eaa57ee42747\"'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fieldLayouts.4544de17-529c-4494-920d-9609dd4b8888.tabs.0.elementCondition','null'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fieldLayouts.4544de17-529c-4494-920d-9609dd4b8888.tabs.0.elements.0.elementCondition','null'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fieldLayouts.4544de17-529c-4494-920d-9609dd4b8888.tabs.0.elements.0.fieldUid','\"c899eea5-625d-430a-af64-94c6c79c05dc\"'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fieldLayouts.4544de17-529c-4494-920d-9609dd4b8888.tabs.0.elements.0.instructions','null'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fieldLayouts.4544de17-529c-4494-920d-9609dd4b8888.tabs.0.elements.0.label','null'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fieldLayouts.4544de17-529c-4494-920d-9609dd4b8888.tabs.0.elements.0.required','true'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fieldLayouts.4544de17-529c-4494-920d-9609dd4b8888.tabs.0.elements.0.tip','null'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fieldLayouts.4544de17-529c-4494-920d-9609dd4b8888.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fieldLayouts.4544de17-529c-4494-920d-9609dd4b8888.tabs.0.elements.0.uid','\"c3fa8902-0b9c-480e-9b47-c6c555c74e1f\"'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fieldLayouts.4544de17-529c-4494-920d-9609dd4b8888.tabs.0.elements.0.userCondition','null'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fieldLayouts.4544de17-529c-4494-920d-9609dd4b8888.tabs.0.elements.0.warning','null'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fieldLayouts.4544de17-529c-4494-920d-9609dd4b8888.tabs.0.elements.0.width','100'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fieldLayouts.4544de17-529c-4494-920d-9609dd4b8888.tabs.0.elements.1.elementCondition','null'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fieldLayouts.4544de17-529c-4494-920d-9609dd4b8888.tabs.0.elements.1.fieldUid','\"e92950dd-e385-4421-905f-63fab21d1afc\"'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fieldLayouts.4544de17-529c-4494-920d-9609dd4b8888.tabs.0.elements.1.instructions','null'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fieldLayouts.4544de17-529c-4494-920d-9609dd4b8888.tabs.0.elements.1.label','null'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fieldLayouts.4544de17-529c-4494-920d-9609dd4b8888.tabs.0.elements.1.required','true'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fieldLayouts.4544de17-529c-4494-920d-9609dd4b8888.tabs.0.elements.1.tip','null'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fieldLayouts.4544de17-529c-4494-920d-9609dd4b8888.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fieldLayouts.4544de17-529c-4494-920d-9609dd4b8888.tabs.0.elements.1.uid','\"09cf0238-6bd9-4f7b-bc7a-792c59dd6f14\"'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fieldLayouts.4544de17-529c-4494-920d-9609dd4b8888.tabs.0.elements.1.userCondition','null'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fieldLayouts.4544de17-529c-4494-920d-9609dd4b8888.tabs.0.elements.1.warning','null'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fieldLayouts.4544de17-529c-4494-920d-9609dd4b8888.tabs.0.elements.1.width','100'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fieldLayouts.4544de17-529c-4494-920d-9609dd4b8888.tabs.0.name','\"Content\"'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fieldLayouts.4544de17-529c-4494-920d-9609dd4b8888.tabs.0.uid','\"fe2ac5db-ea5c-461a-ac11-7c900d56cedb\"'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fieldLayouts.4544de17-529c-4494-920d-9609dd4b8888.tabs.0.userCondition','null'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.c899eea5-625d-430a-af64-94c6c79c05dc.columnSuffix','null'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.c899eea5-625d-430a-af64-94c6c79c05dc.contentColumnType','\"text\"'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.c899eea5-625d-430a-af64-94c6c79c05dc.fieldGroup','null'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.c899eea5-625d-430a-af64-94c6c79c05dc.handle','\"teamName\"'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.c899eea5-625d-430a-af64-94c6c79c05dc.instructions','null'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.c899eea5-625d-430a-af64-94c6c79c05dc.name','\"Name\"'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.c899eea5-625d-430a-af64-94c6c79c05dc.searchable','false'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.c899eea5-625d-430a-af64-94c6c79c05dc.settings.byteLimit','null'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.c899eea5-625d-430a-af64-94c6c79c05dc.settings.charLimit','null'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.c899eea5-625d-430a-af64-94c6c79c05dc.settings.code','false'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.c899eea5-625d-430a-af64-94c6c79c05dc.settings.columnType','null'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.c899eea5-625d-430a-af64-94c6c79c05dc.settings.initialRows','4'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.c899eea5-625d-430a-af64-94c6c79c05dc.settings.multiline','false'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.c899eea5-625d-430a-af64-94c6c79c05dc.settings.placeholder','null'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.c899eea5-625d-430a-af64-94c6c79c05dc.settings.uiMode','\"normal\"'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.c899eea5-625d-430a-af64-94c6c79c05dc.translationKeyFormat','null'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.c899eea5-625d-430a-af64-94c6c79c05dc.translationMethod','\"none\"'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.c899eea5-625d-430a-af64-94c6c79c05dc.type','\"craft\\\\fields\\\\PlainText\"'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.columnSuffix','null'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.contentColumnType','\"string\"'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.fieldGroup','null'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.handle','\"photo\"'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.instructions','null'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.name','\"Photo\"'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.searchable','false'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.settings.allowedKinds','null'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.settings.allowSelfRelations','false'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.settings.allowSubfolders','false'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.settings.allowUploads','true'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.settings.defaultUploadLocationSource','\"volume:0e2e66d1-935a-4b1e-8360-06dcda59a613\"'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.settings.defaultUploadLocationSubpath','null'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.settings.localizeRelations','false'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.settings.maxRelations','1'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.settings.minRelations','1'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.settings.previewMode','\"full\"'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.settings.restrictedDefaultUploadSubpath','null'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.settings.restrictedLocationSource','\"volume:0e2e66d1-935a-4b1e-8360-06dcda59a613\"'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.settings.restrictedLocationSubpath','null'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.settings.restrictFiles','false'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.settings.restrictLocation','true'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.settings.selectionCondition.__assoc__.0.0','\"elementType\"'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.settings.selectionCondition.__assoc__.0.1','\"craft\\\\elements\\\\Asset\"'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.settings.selectionCondition.__assoc__.1.0','\"fieldContext\"'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.settings.selectionCondition.__assoc__.1.1','\"global\"'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.settings.selectionCondition.__assoc__.2.0','\"class\"'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.settings.selectionCondition.__assoc__.2.1','\"craft\\\\elements\\\\conditions\\\\assets\\\\AssetCondition\"'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.settings.selectionLabel','null'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.settings.showSiteMenu','true'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.settings.showUnpermittedFiles','false'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.settings.showUnpermittedVolumes','false'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.settings.source','null'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.settings.sources','\"*\"'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.settings.targetSiteId','null'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.settings.validateRelatedElements','false'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.settings.viewMode','\"list\"'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.translationKeyFormat','null'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.translationMethod','\"site\"'),('superTableBlockTypes.82bed934-484a-4648-9a87-d49db048f5ae.fields.e92950dd-e385-4421-905f-63fab21d1afc.type','\"craft\\\\fields\\\\Assets\"'),('system.edition','\"solo\"'),('system.live','true'),('system.name','\"BiteRate\"'),('system.schemaVersion','\"4.0.0.9\"'),('system.timeZone','\"America/Los_Angeles\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.requireEmailVerification','true'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.fieldLayouts.e04a4836-39e5-469f-8904-a212522fb3b9.tabs.0.elementCondition','null'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.fieldLayouts.e04a4836-39e5-469f-8904-a212522fb3b9.tabs.0.elements.0.autocapitalize','true'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.fieldLayouts.e04a4836-39e5-469f-8904-a212522fb3b9.tabs.0.elements.0.autocomplete','false'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.fieldLayouts.e04a4836-39e5-469f-8904-a212522fb3b9.tabs.0.elements.0.autocorrect','true'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.fieldLayouts.e04a4836-39e5-469f-8904-a212522fb3b9.tabs.0.elements.0.class','null'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.fieldLayouts.e04a4836-39e5-469f-8904-a212522fb3b9.tabs.0.elements.0.disabled','false'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.fieldLayouts.e04a4836-39e5-469f-8904-a212522fb3b9.tabs.0.elements.0.elementCondition','null'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.fieldLayouts.e04a4836-39e5-469f-8904-a212522fb3b9.tabs.0.elements.0.id','null'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.fieldLayouts.e04a4836-39e5-469f-8904-a212522fb3b9.tabs.0.elements.0.instructions','null'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.fieldLayouts.e04a4836-39e5-469f-8904-a212522fb3b9.tabs.0.elements.0.label','null'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.fieldLayouts.e04a4836-39e5-469f-8904-a212522fb3b9.tabs.0.elements.0.max','null'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.fieldLayouts.e04a4836-39e5-469f-8904-a212522fb3b9.tabs.0.elements.0.min','null'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.fieldLayouts.e04a4836-39e5-469f-8904-a212522fb3b9.tabs.0.elements.0.name','null'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.fieldLayouts.e04a4836-39e5-469f-8904-a212522fb3b9.tabs.0.elements.0.orientation','null'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.fieldLayouts.e04a4836-39e5-469f-8904-a212522fb3b9.tabs.0.elements.0.placeholder','null'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.fieldLayouts.e04a4836-39e5-469f-8904-a212522fb3b9.tabs.0.elements.0.readonly','false'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.fieldLayouts.e04a4836-39e5-469f-8904-a212522fb3b9.tabs.0.elements.0.requirable','false'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.fieldLayouts.e04a4836-39e5-469f-8904-a212522fb3b9.tabs.0.elements.0.size','null'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.fieldLayouts.e04a4836-39e5-469f-8904-a212522fb3b9.tabs.0.elements.0.step','null'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.fieldLayouts.e04a4836-39e5-469f-8904-a212522fb3b9.tabs.0.elements.0.tip','null'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.fieldLayouts.e04a4836-39e5-469f-8904-a212522fb3b9.tabs.0.elements.0.title','null'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.fieldLayouts.e04a4836-39e5-469f-8904-a212522fb3b9.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\"'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.fieldLayouts.e04a4836-39e5-469f-8904-a212522fb3b9.tabs.0.elements.0.uid','\"392a6dd3-93e5-425b-9f38-05f37ba4dee0\"'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.fieldLayouts.e04a4836-39e5-469f-8904-a212522fb3b9.tabs.0.elements.0.userCondition','null'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.fieldLayouts.e04a4836-39e5-469f-8904-a212522fb3b9.tabs.0.elements.0.warning','null'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.fieldLayouts.e04a4836-39e5-469f-8904-a212522fb3b9.tabs.0.elements.0.width','100'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.fieldLayouts.e04a4836-39e5-469f-8904-a212522fb3b9.tabs.0.name','\"Content\"'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.fieldLayouts.e04a4836-39e5-469f-8904-a212522fb3b9.tabs.0.uid','\"b7a88148-999f-4771-af54-0674ea240304\"'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.fieldLayouts.e04a4836-39e5-469f-8904-a212522fb3b9.tabs.0.userCondition','null'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.fs','\"teamPhotos\"'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.handle','\"teamPhotos\"'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.name','\"Team Photos\"'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.sortOrder','2'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.titleTranslationKeyFormat','null'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.titleTranslationMethod','\"site\"'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.transformFs','\"\"'),('volumes.0e2e66d1-935a-4b1e-8360-06dcda59a613.transformSubpath','\"\"'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.fieldLayouts.b16c2f9d-8812-49b4-a121-9f07ef7432dd.tabs.0.elementCondition','null'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.fieldLayouts.b16c2f9d-8812-49b4-a121-9f07ef7432dd.tabs.0.elements.0.autocapitalize','true'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.fieldLayouts.b16c2f9d-8812-49b4-a121-9f07ef7432dd.tabs.0.elements.0.autocomplete','false'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.fieldLayouts.b16c2f9d-8812-49b4-a121-9f07ef7432dd.tabs.0.elements.0.autocorrect','true'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.fieldLayouts.b16c2f9d-8812-49b4-a121-9f07ef7432dd.tabs.0.elements.0.class','null'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.fieldLayouts.b16c2f9d-8812-49b4-a121-9f07ef7432dd.tabs.0.elements.0.disabled','false'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.fieldLayouts.b16c2f9d-8812-49b4-a121-9f07ef7432dd.tabs.0.elements.0.elementCondition','null'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.fieldLayouts.b16c2f9d-8812-49b4-a121-9f07ef7432dd.tabs.0.elements.0.id','null'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.fieldLayouts.b16c2f9d-8812-49b4-a121-9f07ef7432dd.tabs.0.elements.0.instructions','null'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.fieldLayouts.b16c2f9d-8812-49b4-a121-9f07ef7432dd.tabs.0.elements.0.label','null'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.fieldLayouts.b16c2f9d-8812-49b4-a121-9f07ef7432dd.tabs.0.elements.0.max','null'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.fieldLayouts.b16c2f9d-8812-49b4-a121-9f07ef7432dd.tabs.0.elements.0.min','null'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.fieldLayouts.b16c2f9d-8812-49b4-a121-9f07ef7432dd.tabs.0.elements.0.name','null'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.fieldLayouts.b16c2f9d-8812-49b4-a121-9f07ef7432dd.tabs.0.elements.0.orientation','null'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.fieldLayouts.b16c2f9d-8812-49b4-a121-9f07ef7432dd.tabs.0.elements.0.placeholder','null'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.fieldLayouts.b16c2f9d-8812-49b4-a121-9f07ef7432dd.tabs.0.elements.0.readonly','false'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.fieldLayouts.b16c2f9d-8812-49b4-a121-9f07ef7432dd.tabs.0.elements.0.requirable','false'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.fieldLayouts.b16c2f9d-8812-49b4-a121-9f07ef7432dd.tabs.0.elements.0.size','null'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.fieldLayouts.b16c2f9d-8812-49b4-a121-9f07ef7432dd.tabs.0.elements.0.step','null'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.fieldLayouts.b16c2f9d-8812-49b4-a121-9f07ef7432dd.tabs.0.elements.0.tip','null'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.fieldLayouts.b16c2f9d-8812-49b4-a121-9f07ef7432dd.tabs.0.elements.0.title','null'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.fieldLayouts.b16c2f9d-8812-49b4-a121-9f07ef7432dd.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\"'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.fieldLayouts.b16c2f9d-8812-49b4-a121-9f07ef7432dd.tabs.0.elements.0.uid','\"f99b1855-414d-435e-b0f8-89c78e6a3f7e\"'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.fieldLayouts.b16c2f9d-8812-49b4-a121-9f07ef7432dd.tabs.0.elements.0.userCondition','null'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.fieldLayouts.b16c2f9d-8812-49b4-a121-9f07ef7432dd.tabs.0.elements.0.warning','null'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.fieldLayouts.b16c2f9d-8812-49b4-a121-9f07ef7432dd.tabs.0.elements.0.width','100'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.fieldLayouts.b16c2f9d-8812-49b4-a121-9f07ef7432dd.tabs.0.name','\"Content\"'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.fieldLayouts.b16c2f9d-8812-49b4-a121-9f07ef7432dd.tabs.0.uid','\"9878f43e-8adb-4d60-80a0-df41f3c34fd9\"'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.fieldLayouts.b16c2f9d-8812-49b4-a121-9f07ef7432dd.tabs.0.userCondition','null'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.fs','\"project\"'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.handle','\"projectPhotos\"'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.name','\"Project Photos\"'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.sortOrder','1'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.titleTranslationKeyFormat','null'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.titleTranslationMethod','\"site\"'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.transformFs','\"\"'),('volumes.8427f64a-7a41-4982-9210-df04b8400923.transformSubpath','\"\"');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text DEFAULT NULL,
  `timePushed` int(11) NOT NULL,
  `ttr` int(11) NOT NULL,
  `delay` int(11) NOT NULL DEFAULT 0,
  `priority` int(11) unsigned NOT NULL DEFAULT 1024,
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int(11) DEFAULT NULL,
  `progress` smallint(6) NOT NULL DEFAULT 0,
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int(11) DEFAULT NULL,
  `fail` tinyint(1) DEFAULT 0,
  `dateFailed` datetime DEFAULT NULL,
  `error` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ywilviogbdumgifiifipqpeijwzspesripbd` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_eolpiewsoiljwdwoiphmftyybqoqbltccbqy` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `relations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `sourceId` int(11) NOT NULL,
  `sourceSiteId` int(11) DEFAULT NULL,
  `targetId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xptusdlgharuqffizpdhzvdzwvanlakofdzv` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_rxxmykezqyflgmiuiqcukuhxucvylwlwljye` (`sourceId`),
  KEY `idx_xkelrzjvvklywjmnngsgxjtzeiqbhtwbjgcm` (`targetId`),
  KEY `idx_srvbamxdgadotlahwsedbjowuucsrctpzaxq` (`sourceSiteId`),
  CONSTRAINT `fk_fzdbwhmveozpkxvkvznzonrlkiutazvqfkys` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_kmmtrixjnsvizqaqhgcmroqxxvudjaubjpme` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_yiqeopjjrjkqhkzmxixgzprxebtgagauqsot` FOREIGN KEY (`targetId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ykzqftcfwjvdynarkjngahlbdvdiqiatsejq` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resourcepaths`
--

LOCK TABLES `resourcepaths` WRITE;
/*!40000 ALTER TABLE `resourcepaths` DISABLE KEYS */;
INSERT INTO `resourcepaths` VALUES ('32fc3ffe','@craft/web/assets/feed/dist'),('383d6dc2','@craft/web/assets/jquerytouchevents/dist'),('386eb2a0','@craft/web/assets/jquerypayment/dist'),('3df9b017','@craft/web/assets/velocity/dist'),('435687e','@craft/web/assets/picturefill/dist'),('4bbf1935','@craft/web/assets/dashboard/dist'),('6427897e','@craft/web/assets/jqueryui/dist'),('6b200680','@craft/web/assets/elementresizedetector/dist'),('6ec01968','@bower/jquery/dist'),('71d47cbc','@craft/web/assets/prismjs/dist'),('726e4663','@craft/web/assets/updates/dist'),('7a5c5fd5','@craft/web/assets/fileupload/dist'),('8c0a2384','@craft/web/assets/axios/dist'),('94ffb6dd','@craft/web/assets/recententries/dist'),('99bd49f5','@craft/web/assets/findreplace/dist'),('9d3cf082','@craft/web/assets/updater/dist'),('a16f02dc','@craft/web/assets/iframeresizer/dist'),('aa0e0b6b','@craft/web/assets/d3/dist'),('aa45f4b3','@craft/web/assets/updateswidget/dist'),('b03b2d22','@craft/web/assets/cp/dist'),('bb663548','@craft/web/assets/tailwindreset/dist'),('bc738f6a','@craft/web/assets/selectize/dist'),('d251b4c1','@craft/web/assets/garnish/dist'),('de902ba','@craft/web/assets/craftsupport/dist'),('eac915e8','@craft/web/assets/utilities/dist'),('f8dd57e','@craft/web/assets/xregexp/dist'),('fae383d6','@craft/web/assets/fabric/dist');
/*!40000 ALTER TABLE `resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `revisions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `canonicalId` int(11) NOT NULL,
  `creatorId` int(11) DEFAULT NULL,
  `num` int(11) NOT NULL,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_nrzsesiphejnzxvuhtdzwndkjgodrjeucrcc` (`canonicalId`,`num`),
  KEY `fk_nsowmfydwvpavwcdmbkjutcyiwhmfakfidpk` (`creatorId`),
  CONSTRAINT `fk_nsowmfydwvpavwcdmbkjutcyiwhmfakfidpk` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_rwcqooqyqhbgmafsijqxohudgddepfmkrdzu` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
INSERT INTO `revisions` VALUES (1,1,NULL,1,NULL),(2,1,NULL,2,NULL),(3,4,NULL,1,NULL),(4,4,NULL,2,NULL),(5,7,NULL,1,NULL),(6,7,NULL,2,NULL),(7,10,NULL,1,NULL),(8,10,NULL,2,NULL),(9,1,NULL,3,NULL),(10,1,NULL,4,NULL),(11,4,NULL,3,NULL),(12,4,NULL,4,NULL),(13,7,NULL,3,NULL),(14,7,NULL,4,NULL),(15,10,NULL,3,NULL),(16,10,NULL,4,NULL),(17,1,21,5,NULL),(18,1,21,6,NULL),(19,4,21,5,NULL),(20,4,21,6,NULL),(21,7,21,5,NULL),(22,7,21,6,NULL),(23,10,21,5,NULL),(24,10,21,6,NULL),(25,4,21,7,NULL),(26,4,21,8,NULL),(27,7,21,7,NULL),(28,7,21,8,NULL),(29,10,21,7,NULL),(30,10,21,8,NULL);
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `searchindex` (
  `elementId` int(11) NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_ghigocusdrffckxlhpothiwvvnmnwdlfhcok` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
INSERT INTO `searchindex` VALUES (1,'slug',0,1,' archiv '),(1,'title',0,1,' archiv '),(4,'slug',0,1,' uber uns '),(4,'title',0,1,' uber uns '),(7,'slug',0,1,' home '),(7,'title',0,1,' home '),(10,'slug',0,1,' referenzen '),(10,'title',0,1,' referenzen '),(21,'email',0,1,' rsenaultc gmail com '),(21,'firstname',0,1,''),(21,'fullname',0,1,''),(21,'lastname',0,1,''),(21,'slug',0,1,''),(21,'username',0,1,' rsenaultc gmail com ');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT 0,
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xesgtbyrqxhnabddeygpzdtqsztknivxlgtq` (`handle`),
  KEY `idx_tsgfwwlpfzpobmjrchjdbavhdqsrjpnigubj` (`name`),
  KEY `idx_wdxjapkkbauregotqnjytbbfvxxvupvewyra` (`structureId`),
  KEY `idx_qrmlhpwweqbdxeloheyimpcxfhelgctgtllk` (`dateDeleted`),
  CONSTRAINT `fk_wkbtvkdqeqbyhbvjwuvewbjwfvpcelpgelbi` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,NULL,'Archiv','archiv','single',1,'all','end',NULL,'2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,'b373d66a-5a09-4164-a51a-bbbef0102a75'),(2,NULL,'Home','home','single',1,'all','end',NULL,'2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,'d03399df-cbbc-4519-949d-ae47810ffc53'),(3,NULL,'Referenzen','referenzen','single',1,'all','end',NULL,'2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,'790d7e4e-f6e4-4009-b190-43462c745601'),(4,NULL,'Uber Uns','uberuns','single',1,'all','end',NULL,'2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,'297a7304-ea06-4bfa-ab70-ceb7e2f8793c'),(5,NULL,'Projects','projects','channel',1,'all','end',NULL,'2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,'30b9b0ce-bf0d-4512-af8e-7bbe939a1a01');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sections_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sectionId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT 1,
  `uriFormat` text DEFAULT NULL,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT 1,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_amjxxlegeunwuyvaixllkxwjatblitagrxlb` (`sectionId`,`siteId`),
  KEY `idx_rzwkqmocodzmqvkkyhqrnrwprfldfchrjdky` (`siteId`),
  CONSTRAINT `fk_bindkfalpyzireexluccgfgylivyjoewiwal` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xyyaioakdhckoyohjbhyhafbupdadjmrluut` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
INSERT INTO `sections_sites` VALUES (1,1,1,1,'archiv','archiv/_entry',1,'2023-05-04 22:27:55','2023-05-04 22:27:55','7d7ac50c-c1d8-4842-91d9-bb8f81b4790e'),(2,2,1,1,'__home__','index.twig',1,'2023-05-04 22:27:55','2023-05-04 22:27:55','a8749586-37d9-4b56-bba6-296d75fb566c'),(3,3,1,1,'referenzen','referenzen/_entry',1,'2023-05-04 22:27:55','2023-05-04 22:27:55','c8f50d03-d96f-4136-8c37-04fa35b1ab0d'),(4,4,1,1,'uber-uns',NULL,1,'2023-05-04 22:27:55','2023-05-04 22:27:55','65025c61-6e09-4b93-acb6-1e7d7874bc0a'),(5,5,1,1,'referenzen#{{slug}}',NULL,1,'2023-05-04 22:27:55','2023-05-04 22:27:55','295d80ba-52f7-489f-a693-0221afbc0679');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int(11) unsigned NOT NULL DEFAULT 1,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_azoaqvajopfasyygbddxqzptbjsjlbeqbyku` (`uid`),
  KEY `idx_ygbxogcqwonmevrwrpvdyeheohefgbswcewv` (`token`),
  KEY `idx_bxlqounuthczdaufrkkixlmthzmjdgunwrdl` (`dateUpdated`),
  KEY `idx_aobemdzwoygsrwsbfmrxhjdyfdifhawtcgyr` (`userId`),
  CONSTRAINT `fk_adpboqnjllcifdpkessjbkjhishqgqpcjsmz` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES (2,21,'P0bwhLcrKU2pwABCHNvTOhb9JOk6Fp71dbvxorPmf9oF39eVHCfskH61-SILAiuPkMGw4diOMSKY9Ufn4EOwNgz2go7tsmsekOSV','2023-05-05 18:15:52','2023-05-05 18:43:26','1727c6a6-a62b-46dd-a14d-20817552e93e'),(3,21,'T-aimMKMuXrhsXNQcoMYzml-zN7CEfz-ZNSLei-NaT14iCCF_b8OBQsUkZZB-I6TJTUoHVheH3TDV35CecYDqXFDnEHCHHetWAVX','2023-06-12 19:41:44','2023-06-12 19:47:35','8d47abb3-7804-41de-824c-0cc9a997e2bd'),(4,21,'GIrSfDsRfUIGpej6ZJTC4Dn22DaSMHiWB0XptAiRQNuJCUDFaiP1AghXxrK1f3kWdluIbmoJp50cDna2pIo2XyaoYDGnb1pYG8nD','2023-06-12 19:47:35','2023-06-12 20:01:10','6c77aab8-60c4-403f-9249-f5c3806c2fa8');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shunnedmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_tlhvaxrvgvaywsqnztefrrrdmgdhtbhatqds` (`userId`,`message`),
  CONSTRAINT `fk_svdnpcuqiihzyblmtjxvnkvbyvxxciwmuccl` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sitegroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xbbkubcthpcdnkrccmnyzxcbeifuigzktfpu` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
INSERT INTO `sitegroups` VALUES (1,'BiteRate','2023-05-04 22:27:54','2023-05-04 23:26:17',NULL,'0b38a6f1-daaf-4fda-b567-2e966ecac3f5');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(12) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT 0,
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_kcxsjygjncsdkfdmicheuanpxbfvbwjhawly` (`dateDeleted`),
  KEY `idx_qsmiliyluebwjwlkgtkdofmdourxkgevjftp` (`handle`),
  KEY `idx_tkakglrumsvxzjoqwnjhqswwxmwsdqdjnzzy` (`sortOrder`),
  KEY `fk_loqifpzpqfcgppmfaynrhshtfyqcwexnrepm` (`groupId`),
  CONSTRAINT `fk_loqifpzpqfcgppmfaynrhshtfyqcwexnrepm` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
INSERT INTO `sites` VALUES (1,1,1,'1','BiteRate','default','en-US',1,'$PRIMARY_SITE_URL',1,'2023-05-04 22:27:54','2023-05-04 23:26:17',NULL,'f70b9a5b-18df-4c74-9883-5a97fbf5f7f4');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stc_teammembers`
--

DROP TABLE IF EXISTS `stc_teammembers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stc_teammembers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `elementId` int(11) NOT NULL,
  `siteId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  `field_teamName` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_cyjmypecmacgjzwiqozrbxrvjqwwaghtbvxl` (`elementId`,`siteId`),
  KEY `fk_uatixcssgvexaqkusqgbwefpravrnrfbeamb` (`siteId`),
  CONSTRAINT `fk_gsnoknzsqqjjuryfrhgqpehyaouhonusrplk` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uatixcssgvexaqkusqgbwefpravrnrfbeamb` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stc_teammembers`
--

LOCK TABLES `stc_teammembers` WRITE;
/*!40000 ALTER TABLE `stc_teammembers` DISABLE KEYS */;
/*!40000 ALTER TABLE `stc_teammembers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structureelements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `structureId` int(11) NOT NULL,
  `elementId` int(11) DEFAULT NULL,
  `root` int(11) unsigned DEFAULT NULL,
  `lft` int(11) unsigned NOT NULL,
  `rgt` int(11) unsigned NOT NULL,
  `level` smallint(6) unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_avtgrqhkdfiitngralsqqeimdhjoebtmyady` (`structureId`,`elementId`),
  KEY `idx_qtmppapoqgarpucnybbolshzzlpgskoetcdc` (`root`),
  KEY `idx_yffotukgeurcljeaprddrfdfnauidwaodmxa` (`lft`),
  KEY `idx_lbxmvjtdmjkathenwiimcceysgcbvoovvrdm` (`rgt`),
  KEY `idx_zrjmyerbqcwbrwslniguewcycavyrplayiqd` (`level`),
  KEY `idx_zyhwxfjnastgmdellwgmefzfehelqvxemrbs` (`elementId`),
  CONSTRAINT `fk_oedpyyjzzqrfeqnunfiinupvdhjjusszejpq` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_uvqhemvxicimngofkukycriydaqwpwocxstd` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `structures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dkujcoikvxijibmlgapuhjkaphklnfqiripz` (`dateDeleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
INSERT INTO `structures` VALUES (1,1,'2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,'1e7fc618-201b-479e-8fdc-caae9f37615f');
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supertableblocks`
--

DROP TABLE IF EXISTS `supertableblocks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supertableblocks` (
  `id` int(11) NOT NULL,
  `primaryOwnerId` int(11) NOT NULL,
  `fieldId` int(11) NOT NULL,
  `typeId` int(11) NOT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_iekyanmslsvzozoatabpyidwlvtfdgezzesw` (`primaryOwnerId`),
  KEY `idx_lwfimbpiulkvgwglugbqglbepvesgiujaors` (`fieldId`),
  KEY `idx_vhfwynebhdoqixfevukkndkmooqmpfbumufz` (`typeId`),
  CONSTRAINT `fk_boeesruhzjittaszjatgdibonucvgsammdel` FOREIGN KEY (`typeId`) REFERENCES `supertableblocktypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_cnwuqqndgzsmrzkzlghxnxebagawpamnnhhv` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_fbnfkbpznmlwyqrgimepqimnnafhoylipqei` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_slddigaqkfldxpwqkwkjdxbrhynnpqyhcows` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supertableblocks`
--

LOCK TABLES `supertableblocks` WRITE;
/*!40000 ALTER TABLE `supertableblocks` DISABLE KEYS */;
/*!40000 ALTER TABLE `supertableblocks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supertableblocks_owners`
--

DROP TABLE IF EXISTS `supertableblocks_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supertableblocks_owners` (
  `blockId` int(11) NOT NULL,
  `ownerId` int(11) NOT NULL,
  `sortOrder` smallint(6) unsigned NOT NULL,
  PRIMARY KEY (`blockId`,`ownerId`),
  KEY `fk_xreaommycxihnjnryobmrgqepjupnbdzcxck` (`ownerId`),
  CONSTRAINT `fk_ffauvjsagoakgnkeakeohzphhvievtcjkrmm` FOREIGN KEY (`blockId`) REFERENCES `supertableblocks` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_xreaommycxihnjnryobmrgqepjupnbdzcxck` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supertableblocks_owners`
--

LOCK TABLES `supertableblocks_owners` WRITE;
/*!40000 ALTER TABLE `supertableblocks_owners` DISABLE KEYS */;
/*!40000 ALTER TABLE `supertableblocks_owners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supertableblocktypes`
--

DROP TABLE IF EXISTS `supertableblocktypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `supertableblocktypes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldId` int(11) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_dcdagqeeenitmeyklwtjjknuxsttviudebrt` (`fieldId`),
  KEY `idx_jobnqwrhfyvvsvcglwhyekbfudpmrbyqnlrf` (`fieldLayoutId`),
  CONSTRAINT `fk_gpzccweghezhqgqznxrhyfyhngvfmogykean` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mybdckvdljkehkndmaxpqklfdwdcpnmjicbm` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supertableblocktypes`
--

LOCK TABLES `supertableblocktypes` WRITE;
/*!40000 ALTER TABLE `supertableblocktypes` DISABLE KEYS */;
INSERT INTO `supertableblocktypes` VALUES (1,5,3,'2023-05-04 22:27:55','2023-05-04 22:27:55','82bed934-484a-4648-9a87-d49db048f5ae');
/*!40000 ALTER TABLE `supertableblocktypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `systemmessages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kcikkvrysmorzipjqmnelicvvmwysyjdyjbb` (`key`,`language`),
  KEY `idx_fvizbnaogvywxppfxsyrmewyokskbcpxcavc` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `taggroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qvnpcoqrheonniofijuoxrhfnhnwxdfnhuhr` (`name`),
  KEY `idx_xydmrvxdifefcuzvlgnxkooghejxxtabqqdw` (`handle`),
  KEY `idx_edjrqlmdoknnyemrbrghtfwaltstocazcrjr` (`dateDeleted`),
  KEY `fk_eucutdvairqjkblrhoivdqzfzmnrkvkfvbkd` (`fieldLayoutId`),
  CONSTRAINT `fk_eucutdvairqjkblrhoivdqzfzmnrkvkfvbkd` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tags` (
  `id` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_wggdsdheosvccqsxethapchklaeztfboqvln` (`groupId`),
  CONSTRAINT `fk_jgydgcvcpwknrxwvbhwfofdmzoiakpkobivp` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wdyaywwmmwfwfheagctymrnpejyctlxkscnj` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tokens` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text DEFAULT NULL,
  `usageLimit` tinyint(3) unsigned DEFAULT NULL,
  `usageCount` tinyint(3) unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_dsdkzfjhldkpynspylrovvutfxjbvbvhyvyb` (`token`),
  KEY `idx_vsmbfaghiidjxurxaeqqqyggaptewretdhtf` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_yfgldhfxmhlafywmstczsnofbqtkqdeedfqc` (`handle`),
  KEY `idx_inghhuwohipemseafkaknwenfqxflkgoejoz` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xrzxmdwdixvirfasbrhccdqnkgmejmgrfvpu` (`groupId`,`userId`),
  KEY `idx_lbujgmrxaicktgdchrherkpzuwwybdnzxkxz` (`userId`),
  CONSTRAINT `fk_nrrzcnsvsufkabhjbpzlwwdhyewqpjvwyjwp` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_srmubmhzvnjjniqpmvcehohxydydjjqnlicm` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_hcebjttbcbwikyhbkhuvnzkrpjyceleytock` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `groupId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_vmmmvpeecnppimwezlwmfzzvbrdvdphqbjks` (`permissionId`,`groupId`),
  KEY `idx_zbfbpktainiwzdkhqbenndfzxsykdvmnkrfz` (`groupId`),
  CONSTRAINT `fk_szynbqbzhmgzxfxgidmvutceangaaazdlcmy` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zntkckxuvethupvmpcizgijcoudhinbmzkqo` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpermissions_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionId` int(11) NOT NULL,
  `userId` int(11) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_otnngakucdxedlplgsdpnvyybdjdribpqcgq` (`permissionId`,`userId`),
  KEY `idx_xguxlvjgnoimzcuywfxjjtnloqjmmocvzkxl` (`userId`),
  CONSTRAINT `fk_fmecorcynpwdalqdtiyflvyictxgxjhkhjzl` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gcmsrqxgdyjwujeszcikfmoiibeqrukgheyl` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userpreferences` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `preferences` text DEFAULT NULL,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_qjoifithcakwasklmuhbybaahdvqjbdbnxez` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
INSERT INTO `userpreferences` VALUES (21,'{\"language\":\"en-US\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `photoId` int(11) DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 0,
  `pending` tinyint(1) NOT NULL DEFAULT 0,
  `locked` tinyint(1) NOT NULL DEFAULT 0,
  `suspended` tinyint(1) NOT NULL DEFAULT 0,
  `admin` tinyint(1) NOT NULL DEFAULT 0,
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint(3) unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT 0,
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT 0,
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_gswlgljmgvdsjjqvhlyioalgedvrmvfwdivb` (`active`),
  KEY `idx_nuizkvlncrxdclspigjibxrannpvigwrealt` (`locked`),
  KEY `idx_dpyeflxafgxqdnhjikmyhikwyzaoxfjakxbg` (`pending`),
  KEY `idx_asnldvvnedvnliaqqebltfqqwnkgtpauqhjl` (`suspended`),
  KEY `idx_uwfclafwigcljxvuhzusexjvdqeyymwnxhbq` (`verificationCode`),
  KEY `idx_fchisemcbujopsmtycomtpcsxmfdoytphcjm` (`email`),
  KEY `idx_kinaxbpeyqlcsqmbbowksgrhdbcopxmqmvqx` (`username`),
  KEY `fk_idpmctbtyazwgdtiuetmcyjnfjzeybpogzug` (`photoId`),
  CONSTRAINT `fk_idpmctbtyazwgdtiuetmcyjnfjzeybpogzug` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_wjeblnzlgluqwrcsmvxwbcdseqpldublqrir` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (21,NULL,1,0,0,0,1,'rsenaultc@gmail.com',NULL,NULL,NULL,'rsenaultc@gmail.com','$2y$13$1pxxtTYtt49QHcGOJTXCY.Rr6qeiBJRS/gE5B.g0TzXxt4SKDhgsC','2023-06-12 19:47:35',NULL,NULL,NULL,'2023-06-12 19:42:07',NULL,1,NULL,NULL,NULL,0,'2023-05-04 22:27:56','2023-05-04 22:27:56','2023-06-12 19:47:35');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumefolders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) DEFAULT NULL,
  `volumeId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_dwslrelihlrfkbpeegmwmlicyouayruaunow` (`name`,`parentId`,`volumeId`),
  KEY `idx_djivovpixqipvyufkerbjoganeozonxwliky` (`parentId`),
  KEY `idx_ojxzgmgpmxujvfjdjcgrthbpgzgkdxnqixyv` (`volumeId`),
  CONSTRAINT `fk_dobfpsyquklpemnxvmzsufbwplkpyakqhzln` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_juryqfzfayopzjawpdkysxvjpbcysnrzgach` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
INSERT INTO `volumefolders` VALUES (1,NULL,1,'Project Photos',NULL,'2023-05-04 22:27:55','2023-05-04 22:27:55','aee92685-556e-4544-9b44-70849a744a8f'),(2,NULL,2,'Team Photos',NULL,'2023-05-04 22:27:55','2023-05-04 22:27:55','c06b39df-e5a9-48b0-9ab0-f244238e9c53'),(3,NULL,NULL,'Temporary filesystem',NULL,'2023-05-04 23:27:58','2023-05-04 23:27:58','9fc5f52f-17a0-4108-b8cd-f86078780fc8'),(4,3,NULL,'user_21','user_21/','2023-05-04 23:27:58','2023-05-04 23:27:58','f2fa3962-445b-49da-8379-d09ffd206b02');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `volumes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text DEFAULT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_qpdndkoovvtwduiqdwdyshczjgcjdepqmqhg` (`name`),
  KEY `idx_pdqharklnvqmeuxeccekuanbrpugrzbuqrrq` (`handle`),
  KEY `idx_otdenpqdccfkvrnuuzfykqzetetrvswbayij` (`fieldLayoutId`),
  KEY `idx_ynlxpkoxiqnrdxasgngxovxexdurjjlsffrf` (`dateDeleted`),
  CONSTRAINT `fk_yxmcqiveubxgbgcactiqgmcobcvmkjccrtiu` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
INSERT INTO `volumes` VALUES (1,8,'Project Photos','projectPhotos','project','','','site',NULL,1,'2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,'8427f64a-7a41-4982-9210-df04b8400923'),(2,9,'Team Photos','teamPhotos','teamPhotos','','','site',NULL,2,'2023-05-04 22:27:55','2023-05-04 22:27:55',NULL,'0e2e66d1-935a-4b1e-8360-06dcda59a613');
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `widgets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userId` int(11) NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint(6) unsigned DEFAULT NULL,
  `colspan` tinyint(3) DEFAULT NULL,
  `settings` text DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT 1,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_viezwzmtcchgtnlwzpofgbalptaemcvimuuq` (`userId`),
  CONSTRAINT `fk_pkudgjytsdhcjdciemcbpxhjmeezcrhbfogm` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
INSERT INTO `widgets` VALUES (1,21,'craft\\widgets\\RecentEntries',1,NULL,'{\"siteId\":1,\"section\":\"*\",\"limit\":10}',1,'2023-05-04 23:24:03','2023-05-04 23:24:03','35b4ab99-2ab1-4fa6-9c5b-088ebe677a88'),(2,21,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2023-05-04 23:24:03','2023-05-04 23:24:03','f742bb3f-4630-4fc3-820e-cd80cb029b58'),(3,21,'craft\\widgets\\Updates',3,NULL,'[]',1,'2023-05-04 23:24:03','2023-05-04 23:24:03','f55b8d0a-3fb0-49b9-a8db-b40967a926b2'),(4,21,'craft\\widgets\\Feed',4,NULL,'{\"url\":\"https://craftcms.com/news.rss\",\"title\":\"Craft News\",\"limit\":5}',1,'2023-05-04 23:24:03','2023-05-04 23:24:03','560cc727-888e-486a-8923-1af002ee4f1b');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-06-22 15:38:52
